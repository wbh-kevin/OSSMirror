// vue.config.js
module.exports = {
  transpileDependencies: true,
  publicPath: './',  // 确保路径是相对的
  devServer: {
    allowedHosts: 'all',  // 允许所有主机名访问
    proxy: {
      // 如果你需要配置代理，可以在这里设置
    },
  },
};
