<template>
  <div id="app" style="background-color: #efefef">
    <div id="title" style="background-color: #efefef">
      <!-- 监听 menu-clicked 事件 -->
      <HeadBar @menu-clicked="handleMenuClick" />
    </div>

    <!-- 根据选中的菜单项显示不同的组件 -->
    <keep-alive>
      <OverView v-if="selectedMenu === 'Overview'" @update-selected-value="handleSelectedValueFromChild"/>
    </keep-alive>
    <keep-alive>
      <CalPage v-if="selectedMenu === 'Analysis'" :receivedValue="selectedCom" :key="selectedCom" />
    </keep-alive>
    <keep-alive>
      <RiskCal v-if="selectedMenu === 'Risk'" />
    </keep-alive>
    <keep-alive>
      <AboutView v-if="selectedMenu === 'About'"/>
    </keep-alive>

    <FooterBar />
  </div>
</template>

<script>
// 导入需要的组件
// import CalPage from "./components/CalPage.vue";
import HeadBar from "./components/HeadBar.vue";
import RiskCal from "./components/RiskCal.vue";
import OverView from "./components/OverView.vue";
import FooterBar from "./components/FooterBar.vue";
import CalPage from "./components/CalPage2.vue";
import AboutView from "./components/AboutView.vue"

export default {
  name: "App",
  components: {
    CalPage,
    HeadBar,
    RiskCal,
    OverView,
    FooterBar,
    AboutView,
  },
  data() {
    return {
      selectedMenu: "Overview", // 用来存储当前选中的菜单项
      selectedCom: "",
    };
  },
  methods: {
    // 处理 HeadBar 传递的菜单项
    handleMenuClick(menuName) {
      this.selectedMenu = menuName; // 更新 selectedMenu，显示对应的页面
    },
    handleSelectedValueFromChild(selectedValue) {
      // alert(selectedValue)
      this.selectedCom = selectedValue
      console.log("Received selected value from child:", selectedValue);
      // 在这里你可以执行任何操作，比如将值保存到父组件的状态中
    },
  },
};
</script>

<style scoped>
#app {
  display: flex; /* 添加 flex 布局 */
  flex-direction: column; /* 纵向排列子元素 */
  min-height: 100vh; /* 确保最小高度为视口高度 */
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
}

#app > div {
  flex-grow: 1; /* 使内容区域占据剩余空间 */
}

.layout {
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 8px;
}

button {
  font-size: 16px;
  padding: 10px;
  margin: 0px;
  cursor: pointer;
  border: none;
  background-color: transparent; /* 去掉背景颜色 */
  color: #2c3e50;
  border-radius: 4px;
  position: relative;
}

button:hover {
  color: #34495e; /* 改变文字颜色 */
}

/* 选中按钮时添加下划线 */
button.active {
  color: #2c3e50; /* 保持文字颜色 */
  border-bottom: 2px solid #ffaaaa; /* 底部下划线 */
}

/* 去掉按钮的聚焦边框 */
button:focus {
  outline: none;
}
</style>
