<template>
  <div class="about-container">
    <header class="about-header">
      <h1>About Me</h1>
      <p>Hi, I'm Bohan – a passionate designer and developer.</p>
    </header>

    <section class="about-content">
      <!-- <h2>Introduction</h2>
      <p>
        I'm a creative thinker who loves designing smooth user experiences and developing responsive web applications.
        My journey in tech started with curiosity and has grown into a deep passion for creating impactful digital solutions.
      </p>

      <h2>Skills</h2>
      <ul class="skills-list">
        <li>🎨 UI/UX Design</li>
        <li>💻 Front-end Development (Vue, React, HTML/CSS/JS)</li>
        <li>🛠️ Prototyping & Wireframing</li>
        <li>🧠 Problem Solving & Teamwork</li>
      </ul> -->

      <h2>My Background</h2>
      <div class="profile-card">
        <!-- 可换成真实头像 -->
        <div class="avatar-placeholder">B</div>
        <h3>Bohan Wang</h3>
        <p>Designer & Developer</p>
        <p>Advisor: Yuxia Zhang</p>
        <a href="mailto:bohan@bit.edu.cn">bohan@bit.edu.cn</a>
        <br />
        <a href="https://yuxiazhang-bit.github.io/team.html" target="_blank">More about the lab</a>
      </div>

      <!-- <h2>Resume</h2>
      <p>
        Want to know more about my experience? 
        <a href="#" target="_blank">Download my resume</a>
      </p> -->
    </section>
  </div>
</template>

<script>
export default {
  name: "AboutView",
};
</script>

<style scoped>
.about-container {
  max-width: 800px;
  margin: 0 auto;
  padding: 40px 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #2c3e50;
}

.about-header {
  text-align: center;
  background: #f0f8ff;
  padding: 30px 20px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.05);
  margin-bottom: 40px;
}

.about-header h1 {
  font-size: 2.8em;
  color: #1565c0;
  margin-bottom: 10px;
}

.about-header p {
  font-size: 1.2em;
  color: #555;
}

.about-content h2 {
  font-size: 1.6em;
  color: #0d47a1;
  margin-top: 30px;
  margin-bottom: 10px;
  border-bottom: 2px solid #90caf9;
  display: inline-block;
}

.about-content p {
  font-size: 1.05em;
  color: #444;
  line-height: 1.8;
}

.skills-list {
  list-style: none;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin: 10px 0 20px 0;
}

.skills-list li {
  background: #e3f2fd;
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 0.95em;
  color: #0d47a1;
  box-shadow: 0 2px 5px rgba(0,0,0,0.05);
}

.profile-card {
  text-align: center;
  background-color: #f1f8ff;
  padding: 30px;
  border-radius: 16px;
  margin: 20px 0;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.avatar-placeholder {
  width: 90px;
  height: 90px;
  background-color: #90caf9;
  color: white;
  font-size: 2.5em;
  line-height: 90px;
  border-radius: 50%;
  margin: 0 auto 15px;
  font-weight: bold;
}

a {
  color: #1976d2;
  text-decoration: none;
}

a:hover {
  text-decoration: underline;
}
</style>
