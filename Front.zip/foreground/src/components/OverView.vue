<template>
  <div class="overview-container">
    <!-- 选择器部分 -->
    <div class="selector-wrapper">
      <!-- 新增的居中显示文本 -->
      <h1 v-if="showText" class="centered-text" style="font-size: 30px;">Choose or input, and then anylysis Github repo</h1>
      <SelectOverview
        :options="options"
        @selected-value="handleSelectedValueUpdate"
        @update:showStatus="updateStatusFromChild"
      />
    </div>

    <!-- 页面介绍部分 -->
    <div class="page-introduction" v-if="showText">
      <p>This website can analyze the Github repo by the repo name or the repo url.</p>
      <p>You can choose the repo from the dropdown list, or input the repo name or the repo url in the input box.</p>
      <p>After you choose or input the repo, you can click the "Submit" button to analysis the repo.</p>
    </div>

    <!-- 主要内容区域 -->
    <div class="main-content" v-if="status != 0" style="margin-left: -200px;">
      <!-- 侧边导航 -->
      <el-menu
        class="side-navigation"
        :default-active="activeNav"
        mode="vertical"
        background-color="#f7f7f7"
        text-color="#333"
        active-text-color="#409EFF"
      >
      <el-menu-item @click="scrollToTop" index="top">
        <el-tooltip effect="dark" :content="navTitle" placement="top">
          <div class="ellipsis-text">
            <i class="el-icon-arrow-up"></i> {{ navTitle }}
          </div>
        </el-tooltip>
      </el-menu-item>

        <el-menu-item
          v-for="(item, index) in getNavItems()"
          :key="index"
          :index="item.id"
          @click="scrollToSection(item.id)"
          style="margin-left: 40px;"
        >
          {{ item.name }}
        </el-menu-item>
      </el-menu>

      <!-- 图表展示区域 -->
      <el-scrollbar class="chart-scrollbar" id="chart-container">
        <div v-if="status != 0" class="charts-container">
          <div id="chartContainer0" class="chart-wrapper">
            <PieChart
              :chartData="chartData"
              :title="'Overview'"
              :tooltipFormatter="tooltipFormatter"
              hiddenText="This chart shows how much commit made by each company and public volunteers."
            />
          </div>

          <div id="chartContainer1" class="chart-wrapper">
            <BigCon
              :title="'Commits'"
              :displayContent="'This chart shows the total number of commits in the selected repo by year.'"
              :lineTitle="'Commits'"
              :value="value"
              @switch-changed="handleSwitchChanged"
            />
          </div>
          <!-- <div id="chartContainer2" class="chart-wrapper">
            <RankChart></RankChart>
          </div> -->
        </div>
      </el-scrollbar>
    </div>

        <el-button v-if="status != 0"  type="primary"  @click="downloadChartsAsImage" style="display: block; margin: 0 auto;">
          Download Charts
        </el-button>
    <el-button class="scroll-to-top" @click="scrollToTop" v-if="!isAtTop && status!=0" circle>
      <!-- <i class="el-icon-arrow-up"></i> -->
      <!-- <el-icon><Top /></el-icon> -->
      ▲
    </el-button>

  </div>
</template>

<script>
import { defineComponent } from "vue";
import PieChart from "@/components/PieChart.vue";
import BigCon from "@/components/BigCon.vue";
import SelectOverview from "@/components/SelectOverview.vue";
import html2canvas from 'html2canvas';
// import RankChart from "./RankChart.vue";
// import * as ElementPlusIconsVue from '@element-plus/icons-vue';


export default defineComponent({
  name: "OverView",
  components: {
    PieChart,
    BigCon,
    SelectOverview,
    // RankChart
    // ArrowUpIcon,
  },
  data() {
    return {
      navTitle: [],
      urlP: `http://30901d0b.r40.cpolar.top/getData/`,
      options: [], // 初始为空数组
      bigConTitle: "BrokenLine Title",
      chartTitle: "PieChart Title",
      chartData: {}, // 存储饼图数据
      chartDataKey: 0, // 强制刷新 chartContainer0
      chartContainer1Key: 0, // 强制刷新 chartContainer1
      selectedValue: "",
      title: "line",
      value: {
        xAxis: [], // x 轴数据（年份）
        yAxis: [], // y 轴数据（提交数）
      },
      status: 0, // 初始状态
      activeNav: "top", // 默认激活"顶部"
      showText: true, // 新增的状态变量
      isAtTop: true, // 新增的状态变量

      tooltipFormatter: (params) => {
        return `${params.name}: ${params.value} (${params.percent}%)`; // 定制 tooltip 格式
      },
    };
  },
  mounted() {
    // fetch("http://10.108.119.152:8888/getData/getRepoList")
    //   .then((response) => response.json())
    //   .then((data) => {
    //     this.options = data.map((item) => ({ label: item, value: item }));
    //     // alert(JSON.stringify(data))
    //   })
    //   .catch((error) => {
    //     console.error("获取数据失败:", error);
    //   });
    fetch(this.urlP + "getRepoList2")
      .then((response) => response.json())
      .then((data) => {
        this.options = data.map((item) => ({
          label: item.name + (item.id==1?` (Last updated: ${item.date})`:` (Calculating: ${item.date})`),
          value: item.name
        }));
      })
      .catch((error) => {
        console.error("获取数据失败:", error);
      });
    window.addEventListener('scroll', this.checkScrollPosition);
  },
  beforeUnmount() {
    window.removeEventListener('scroll', this.checkScrollPosition);
  },
  methods: {
    setStatus(value) {
      this.status = value;
    },
    scrollToSection(sectionId) {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    },
    scrollToTop() {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    },
    getNavItems() {
      const chartContainers = [];
      if (this.status !== 0) {
        chartContainers.push({ id: "chartContainer0", name: "Overview" });
        chartContainers.push({ id: "chartContainer1", name: "Commits" });
      }
      return chartContainers;
    },
    updateStatusFromChild(newStatus) {
      this.status = newStatus;
      this.showText = false; // 隐藏文本
    },
    async downloadChartsAsImage() {
      const container = document.getElementById('chart-container');
      if (!container) {
        alert('图表未加载完成');
        return;
      }

      try {
        const canvas = await html2canvas(container);
        const link = document.createElement('a');
        link.href = canvas.toDataURL('image/png');
        link.download = 'chart-image.png';
        link.click();
      } catch (err) {
        console.error('截图失败:', err);
        alert('截图失败，请稍后重试');
      }
    },

    async handleSelectedValueUpdate(selectedValue) {
      this.selectedValue = selectedValue;
      try {
        this.navTitle = 'General view of repo ' + this.selectedValue;
        // 1. 获取总数统计数据并更新 chartData
        const totalCountUrl = this.urlP + `getTotalCount?repo=${selectedValue}`;
        const totalCountResponse = await fetch(totalCountUrl);
        const totalCountText = await totalCountResponse.text(); // 直接获取文本格式
        let totalCountData = {};

        try {
          totalCountData = JSON.parse(totalCountText); // 解析 JSON
        } catch (e) {
          console.error("解析 JSON 失败:", totalCountText);
          alert(`返回的总数数据格式异常:\n${totalCountText}`);
          return;
        }

        this.chartData = totalCountData;
        this.chartDataKey++;

        // 2. 获取提交数量数据并更新 value
        const commitCountUrl = this.urlP + `getCommitCount?repo=${selectedValue}`;
        const commitCountResponse = await fetch(commitCountUrl);
        const commitCountText = await commitCountResponse.text();
        // alert(commitCountText)
        let commitCountData = [];

        try {
          commitCountData = JSON.parse(commitCountText);
        } catch (e) {
          console.error("解析 JSON 失败:", commitCountText);
          alert(`返回的提交数数据格式异常:\n${commitCountText}`);
          return;
        }

        // 解析 year 和 count 到 value 的 xAxis 和 yAxis
        this.value.xAxis = commitCountData.map((item) => item.time);
        this.value.yAxis = commitCountData.map((item) => item.count);
        // alert(JSON.stringify(this.value.xAxis))
        // 3. 强制刷新 chartContainer1
        this.chartContainer1Key++;
      } catch (error) {
        console.error("请求失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }

      this.$emit("update-selected-value", selectedValue);
    },
    async handleSwitchChanged(newValue) {
      // alert(`Switch changed: ${newValue}`);
      // if (newValue === "Month") {
      //   alert("The selected value is 'Month'");
      // } else {
      //   alert("The selected value is not 'Month'");
      // }
      const tail = newValue === "Month" ? 1 : 0;
      try {
        // 2. 获取提交数量数据并更新 value
        const commitCountUrl = this.urlP + `getCommitCount?repo=${this.selectedValue}&time=${tail}`;
        const commitCountResponse = await fetch(commitCountUrl);
        const commitCountText = await commitCountResponse.text();
        let commitCountData = [];

        try {
          commitCountData = JSON.parse(commitCountText);
        } catch (e) {
          console.error("解析 JSON 失败:", commitCountText);
          alert(`返回的提交数数据格式异常:\n${commitCountText}`);
          return;
        }
        // alert(commitCountData)
        // 解析 year 和 count 到 value 的 xAxis 和 yAxis
        this.value.xAxis = commitCountData.map((item) => item.time);
        this.value.yAxis = commitCountData.map((item) => item.count);
        // alert(JSON.stringify(this.value))
        // // 3. 强制刷新 chartContainer1
        // this.chartContainer1Key++;
      } catch (error) {
        console.error("请求失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }

      // this.$emit("update-selected-value", this.selectedValue);
    },
    checkScrollPosition() {
      this.isAtTop = window.scrollY === 0; // 判断是否在顶部
    },
  },
});
</script>

<style scoped>
.ellipsis-text {
  display: inline-block;
  max-width: 220px; /* 根据你菜单的宽度调整 */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  vertical-align: middle;
}

.overview-container {
  max-width: 1920px;
  margin: 0 auto;
  padding: 20px;
}

.selector-wrapper {
  max-width: 1200px;
  margin: 0 auto 20px;
  padding: 0 20px;
}

.main-content {
  display: flex;
  gap: 30px;
  position: relative;
}

.side-navigation {
  position: sticky;
  top: 20px;
  width: 250px;
  height: fit-content;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.chart-scrollbar {
  flex: 1;
  /* max-height: calc(100vh - 100px); */
  overflow-y: auto;
}

.charts-container {
  padding: 20px;
}

.chart-wrapper {
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 30px;
  min-height: 400px;
  display: flex;
  justify-content: center;
  align-items: center;
}


.el-menu-item {
  font-size: 15px;
  height: 50px;
  line-height: 50px;
  padding-left: 20px !important;
  white-space: normal;
  /* border-top: 1px solid #e0e0e0; */
  border-bottom: 2px solid #e0e0e0;
}

.el-menu-item i+span,
.el-menu-item:has(.el-icon-arrow-up) {
  padding-left: 0px !important;
}

.el-menu-item:not(:has(.el-icon-arrow-up)) {
  padding-left: 20px !important;
}

.el-menu-item:hover {
  background-color: #e6f1fe !important;
}

@media (max-width: 1400px) {
  .main-content {
    flex-direction: column;
  }

  .side-navigation {
    width: 100%;
    position: static;
    margin-bottom: 20px;
  }

  .chart-scrollbar {
    max-height: none;
  }
}

.centered-text {
  text-align: center; /* 居中对齐 */
  font-size: 18px; /* 字体大小 */
  color: #409EFF; /* 字体颜色 */
  margin-bottom: 10px; /* 下边距 */
}

.scroll-to-top {
  position: fixed;
  bottom: 100px;
  right: 80px;
  background-color: #409EFF;
  color: white;
  /* border: none;
  border-radius: 5px;
  padding: 10px 15px;
  cursor: pointer; */
  /* box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); */
  /* z-index: 1000; 确保按钮在其他元素之上 */
}
.scroll-to-top .el-icon-arrow-up {
  color: #409EFF; /* 设置图标颜色 */
  font-size: 20px;
}


.scroll-to-top:hover {
  background-color: #66b1ff; /* 悬停时的背景颜色 */
}
</style>
