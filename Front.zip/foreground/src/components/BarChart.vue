<template>
  <div>
    <div ref="barChart" style="width: 100%; height: 400px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts';

export default {
  name: 'BarChart',
  props: {
    data1: {
      type: Array,
      default: () => [0.2, 0.2, 0.2, 0.2, 0.2]
    },
    data2: {
      type: Array,
      default: () => [0.2, 0.2, 0.2, 0.2, 0.2]
    }
  },
  data() {
    return {
      myChart: null // 存储图表实例
    };
  },
  mounted() {
    this.initChart();
  },
  watch: {
    data1: {
      handler() {
        this.updateChart();
      },
      deep: true
    },
    data2: {
      handler() {
        this.updateChart();
      },
      deep: true
    }
  },
  methods: {
    initChart() {
      const chartDom = this.$refs.barChart;
      this.myChart = echarts.init(chartDom);
      this.setChartOption();
      this.myChart.on('click', (params) => {
        if (params.componentType === 'series') {
          this.$emit('bar-clicked', { selectedBar: params.name, seriesName: params.seriesName });
        }
      });
    },
    setChartOption() {
      if (!this.myChart) return;
      this.myChart.setOption({
        title: { text: '' },
        tooltip: {},
        legend: {
          data: ['Departure Risk', 'Risk of dependency on single supplier']
        },
        xAxis: {
          type: 'category',
          data: ['0-0.2', '0.2-0.4', '0.4-0.6', '0.6-0.8', '0.8-1']
        },
        yAxis: { type: 'value' },
        series: [
          {
            name: 'Departure Risk',
            type: 'bar',
            data: this.data1,
            emphasis: { focus: 'series' },
            label: {
              show: true,
              position: 'top',
              formatter: '{c}'
            }
          },
          {
            name: 'Risk of dependency on single supplier',
            type: 'bar',
            data: this.data2,
            emphasis: { focus: 'series' },
            label: {
              show: true,
              position: 'top',
              formatter: '{c}'
            }
          }
        ]
      });
    },
    updateChart() {
      console.log("更新图表数据:", this.data1, this.data2);
      this.setChartOption();
    }
  }
};
</script>

<style scoped>
/* 可添加样式 */
</style>
