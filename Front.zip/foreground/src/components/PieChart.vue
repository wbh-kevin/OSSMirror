<template>
  <div class="pie-chart-container" style="width: 800px; height: 400px; display: flex; flex-direction: column;">
    <!-- 顶部标题栏 -->
    <div class="header-bar" style="padding: 15px; text-align: center; justify-content:space-between; display: flex; margin-top: 5px">
      <div style="margin-left: 30px">
        {{ title }}
      </div>

      <!-- 切换显示状态的按钮 -->
      <el-button 
        type="primary" 
        @click="toggleChartVisibility" 
        style="margin-left: 10px; margin-right: 20px"
      >
        {{ isChartVisible ? 'How does it works' : 'Back to graph' }}
      </el-button>
    </div>

    <div style="display: flex; flex-grow: 1;">
      <!-- 左侧图例 -->
      <div v-if="isChartVisible" class="legend-container" style="width: 300px; padding: 10px; overflow-y: auto;">
        <!-- 添加搜索框 -->
        <div class="search-box" style="margin-bottom: 10px; margin-left: 50px; width: 200px;">
          <el-input
            v-model="searchQuery"
            placeholder="Search..."
            clearable
            @clear="clearSearch"
          />
        </div>
        
        <div v-for="item in filteredLegend" :key="item.name" class="legend-item">
          <div :style="{ backgroundColor: item.color }" class="legend-color" style="margin-left: 50px;"></div>
          <div class="legend-text">
            <span>{{ item.name }}</span>: {{ item.value }}
          </div>
        </div>
        <!-- 保留翻页控件 -->
        <div style="display: flex; justify-content: space-between; width: 280px; margin-top: 15px;">
          <el-button round @click="prevPage" :disabled="currentPage === 1" type="primary">Prev</el-button>
          <div style="display: flex; align-items: center;">
            <el-input
              v-model="inputPage"
              @keyup.enter="handlePageJump"
              style="width: 60px;"
              size="small"
            />
            <span style="margin-left: 5px;"> / {{ totalPages }}</span>
          </div>
          <el-button round @click="nextPage" :disabled="currentPage === totalPages" type="primary">Next</el-button>
        </div>
      </div>

      <!-- 右侧饼图 -->
      <div v-if="isChartVisible" class="chart-container" style="flex-grow: 1; height: 350px; padding: 10px;">
        <div ref="pieChart" style="height: 100%"></div>
      </div>

      <!-- 如果隐藏了图表，展示父组件传递进来的文本 -->
      <div v-if="!isChartVisible" class="hidden-text" style="flex-grow: 1; display: flex; justify-content: center; align-items: center; font-size: 20px;">
        <span>{{ hiddenText }}</span>
      </div>
    </div>
  </div>
</template>

<script>
import { ElButton, ElInput } from 'element-plus';
import { onMounted, ref, watch, nextTick, computed } from 'vue';
import * as echarts from 'echarts';

export default {
  components: { ElButton, ElInput },
  name: 'PieChart',
  props: {
    chartData: {
      type: Object,
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    hiddenText: {
      type: String,
      default: '图表已被隐藏。点击按钮恢复显示。',
    },
    // 新增的 prop，用于接收父组件传递的 tooltipFormatter 函数
    tooltipFormatter: {
      type: Function,
      required: false,
      default: (params) => `${params.name}: ${params.value.toLocaleString()} (${params.percent}%)`, // 默认格式
    },
  },
  setup(props) {
    const pieChart = ref(null);
    const chartInstance = ref(null);
    const currentPage = ref(1);
    const itemsPerPage = 8;
    const isChartVisible = ref(true);
    const legendData = ref([]);
    const totalPages = ref(1);
    const paginatedLegend = ref([]);
    const inputPage = ref('1');
    const searchQuery = ref('');

    // 修改过滤逻辑，保持分页功能
    const filteredLegend = computed(() => {
      const filtered = searchQuery.value
        ? legendData.value.filter(item =>
            item.name.toLowerCase().includes(searchQuery.value.toLowerCase())
          )
        : legendData.value;
      
      const startIndex = (currentPage.value - 1) * itemsPerPage;
      const endIndex = startIndex + itemsPerPage;
      return filtered.slice(startIndex, endIndex);
    });

    const clearSearch = () => {
      searchQuery.value = '';
    };

    const renderChart = () => {
      if (pieChart.value) {
        chartInstance.value = echarts.init(pieChart.value);

        const data = Object.entries(props.chartData)
          .map(([name, value]) => ({ name, value }))
          .sort((a, b) => b.value - a.value);

        // 计算总和
        const total = data.reduce((sum, item) => sum + item.value, 0);

        const top8Data = data.slice(0, 8);
        const otherData = data.slice(8);

        if (otherData.length > 0) {
          const otherValue = otherData.reduce((sum, item) => sum + item.value, 0);
          top8Data.push({ name: 'Other', value: otherValue });
        }

        const option = {
          tooltip: {
            trigger: 'item',
            formatter: props.tooltipFormatter, // 使用父组件传递的 tooltipFormatter
          },
          legend: {
            show: false,
            left: 'left',
            top: 'center',
            orient: 'vertical',
            data: data.map((item) => item.name),
          },
          series: [
            {
              type: 'pie',
              radius: '80%',
              data: top8Data,
              emphasis: {
                itemStyle: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)',
                },
              },
            },
          ],
        };

        chartInstance.value.setOption(option);

        // 修改图例数据的格式，添加百分比
        legendData.value = data.map((item, index) => ({
          name: item.name,
          value: `${item.value.toLocaleString()} (${(item.value / total * 100).toFixed(1)}%)`,
          color: index < 8 ? chartInstance.value.getOption().color[index] : null,
        }));

        totalPages.value = Math.ceil(legendData.value.length / itemsPerPage);
        updatePaginatedLegend();

        window.addEventListener('resize', () => {
          chartInstance.value.resize();
        });
      }
    };

    const updatePaginatedLegend = () => {
      const startIndex = (currentPage.value - 1) * itemsPerPage;
      const endIndex = startIndex + itemsPerPage;
      paginatedLegend.value = legendData.value.slice(startIndex, endIndex);
    };

    const prevPage = () => {
      if (currentPage.value > 1) {
        currentPage.value--;
        updatePaginatedLegend();
      }
    };

    const nextPage = () => {
      if (currentPage.value < totalPages.value) {
        currentPage.value++;
        updatePaginatedLegend();
      }
    };

    const handlePageJump = () => {
      const pageNum = parseInt(inputPage.value);
      if (!isNaN(pageNum) && pageNum >= 1 && pageNum <= totalPages.value) {
        currentPage.value = pageNum;
        updatePaginatedLegend();
      } else {
        inputPage.value = currentPage.value.toString();
      }
    };

    onMounted(() => {
      renderChart();
    });

    watch(
      () => props.chartData,
      () => {
        renderChart();
      },
      { deep: true }
    );

    watch(currentPage, (newVal) => {
      inputPage.value = newVal.toString();
    });

    const toggleChartVisibility = () => {
      if (isChartVisible.value && chartInstance.value) {
        chartInstance.value.dispose();
        chartInstance.value = null;
      }

      isChartVisible.value = !isChartVisible.value;

      if (isChartVisible.value) {
        nextTick(() => {
          renderChart();
        });
      }
    };

    // 修改总页数计算逻辑
    watch([searchQuery, legendData], () => {
      const filtered = searchQuery.value
        ? legendData.value.filter(item =>
            item.name.toLowerCase().includes(searchQuery.value.toLowerCase())
          )
        : legendData.value;
      totalPages.value = Math.ceil(filtered.length / itemsPerPage);
      
      // 如果当前页超出新的总页数，重置到第一页
      if (currentPage.value > totalPages.value) {
        currentPage.value = 1;
      }
    });

    return {
      pieChart,
      prevPage,
      nextPage,
      currentPage,
      totalPages,
      paginatedLegend,
      isChartVisible,
      toggleChartVisibility,
      inputPage,
      handlePageJump,
      searchQuery,
      filteredLegend,
      clearSearch,
    };
  },
};
</script>

<style>
.pie-chart-container {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
}

.header-bar {
  padding: 15px;
  text-align: center;
  font-size: 20px;
  font-weight: bold;
  margin-top: 5px;
}

.legend-container {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  height: 320px; /* 减小高度以适应400px的限制 */
  overflow-y: auto;
  margin-top: 10px; /* 减小顶部边距 */
  width: 280px;
  margin-left: 30px;
}

.legend-item {
  display: flex;
  align-items: center;
  margin: 6px 0; /* 减小垂直间距 */
  width: 100%;
}

.legend-color {
  width: 12px;
  height: 12px;
  margin-right: 12px;
  border-radius: 50%;
}

.legend-text {
  font-size: 14px;
  font-weight: 500;
}

.pagination {
  margin-top: 10px;
  text-align: center;
}
.pagination button {
  margin: 0 10px;
}

.hidden-text {
  font-size: 20px;
  text-align: center;
  color: #333;
}

.search-box {
  margin-bottom: 10px; /* 减小底部边距 */
  width: 100%;
}

.search-box .el-input__inner {
  border-radius: 20px;
}
</style>