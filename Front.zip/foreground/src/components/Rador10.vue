<template>
    <div style="position: relative; text-align: center; justify-content: center;">
        <div style="display: flex; align-items: center;">
            <h2>Task Preference</h2>
            <el-button @click="toggleText" class="toggle-button" type="primary">How does it works</el-button>
        </div>
        <div style="width: 650px; height: 300px; margin: auto; display: flex; justify-content: center;">
        <div v-if="showText" class="info-text" style="max-width: 650px; max-height: 300px; margin: auto;">
            This classification is based on a large language model. The commit information is sent to the trained model via a prompt, and the model determines which category the commit belongs to.<br>
      View more information about this work, related website: https://huggingface.co/0x404/ccs-code-llama-7b
        </div>
        <div v-show="!showText" ref="radarChart" style="width: 650px; height: 300px;"></div>

        </div>
    </div>
</template>

<script>
import * as echarts from 'echarts';

export default {
  name: 'RadarChart',
  props: {
    chartData: {
      type: Array,
      default: () => Array(10).fill(1) // 默认数据全为1
    }
  },
  data() {
    return {
      radarChartInstance: null, // 存储 ECharts 实例
      maxIndicatorValue: 1, // 初始最大值
      showText: false // 控制文本显示状态
    };
  },
  watch: {
    chartData: {
      handler(newData) {
        this.updateChart(newData);
      },
      deep: true
    }
  },
  mounted() {
    this.initRadarChart();
  },
  methods: {
    toggleText() {
      this.showText = !this.showText; // 切换文本显示状态
      if (!this.showText) {
        this.$nextTick(() => {
          this.initRadarChart(); // 确保图表重新渲染
        });
      }
    },
    initRadarChart() {
      if (!this.$refs.radarChart) return; // 确保 DOM 存在

      if (!this.radarChartInstance) {
        this.radarChartInstance = echarts.init(this.$refs.radarChart);
      }

      this.updateChart(this.chartData);
    },
    updateChart(newData) {
      if (!this.radarChartInstance) return; // 防止异常情况

      this.maxIndicatorValue = Math.max(...newData, 1);

      const option = {
        tooltip: {
          formatter: (params) => {
            const data = params.data.value;
            return data.map((value, index) => {
              const indicatorName = [
                'fix', 'style', 'ci', 'perf', 'refactor', 
                'feat', 'docs', 'test', 'chore', 'build'
              ][index];
              return `<div style="display: flex; justify-content: space-between;">
                        <span>${indicatorName}</span>
                        <span style="margin-left: 1em;">${value}</span>
                      </div>`;
            }).join('');
          }
        },
        radar: {
          indicator: [
            { name: 'fix', max: this.maxIndicatorValue },
            { name: 'style', max: this.maxIndicatorValue },
            { name: 'ci', max: this.maxIndicatorValue },
            { name: 'perf', max: this.maxIndicatorValue },
            { name: 'refactor', max: this.maxIndicatorValue },
            { name: 'feat', max: this.maxIndicatorValue },
            { name: 'docs', max: this.maxIndicatorValue },
            { name: 'test', max: this.maxIndicatorValue },
            { name: 'chore', max: this.maxIndicatorValue },
            { name: 'build', max: this.maxIndicatorValue }
          ]
        },
        series: [{
          type: 'radar',
          data: [{
            value: newData,
            name: '数据'
          }]
        }]
      };

      this.radarChartInstance.setOption(option, true);
    }
  }
}
</script>

<style scoped>
.toggle-button {
  margin-left: 400px;
}
</style>
