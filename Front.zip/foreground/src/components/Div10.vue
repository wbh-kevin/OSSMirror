<template>
  <div class="table-container" style="position: relative; width: 800px; height: 200px;">
    <h2>Commit types</h2>
    <el-button @click="toggleText" class="toggle-button" type="primary">How does it works</el-button>
    <div v-if="showText" class="info-text">This classification is based on a large language model. The commit information is sent to the trained model via a prompt, and the model determines which category the commit belongs to.
      View more information about this work, related website: https://huggingface.co/0x404/ccs-code-llama-7b
    </div>
    <el-row v-if="!showText" :gutter="2" class="item-row" style="width: 800px;">
      <el-col :span="2" v-for="(item, index) in tableData" :key="index" style="width: 800px;">
        <div class="item" style="width: 60px;">
          <div class="category">{{ item.name }}</div>
          <div class="value">{{ item.value }}</div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  name: 'CustomList',
  props: {
    values: {
      type: Array,
      required: true,
      validator: arr => arr.length === 10 && arr.every(val => typeof val === 'number'),
    },
  },
  data() {
    return {
      showText: false, // 控制文本显示的状态
    };
  },
  computed: {
    tableData() {
      const categories = ['fix', 'style', 'ci', 'perf', 'refactor', 'feat', 'docs', 'test', 'chore', 'build'];
      return categories.map((category, index) => ({
        name: category,
        value: this.values[index],
      }));
    },
  },
  methods: {
    toggleText() {
      this.showText = !this.showText; // 切换文本显示状态
    },
  },
};
</script>

<style scoped>
.table-container {
  display: flex;
  flex-direction: column;
  flex-wrap: wrap; /* 允许换行 */
  justify-content: center;
  padding: 20px;
  background-color: #f0f2f5; /* 添加背景颜色 */
  border-radius: 10px; /* 添加圆角 */
}

.item-row {
  display: flex;
  justify-content: center; /* 修改为左对齐 */
  /* flex-wrap: nowrap; */ /* 移除此行 */
}

.item {
  text-align: center;
  padding: 2px; /* 减少内边距 */
  border: 1px solid #dcdfe6; /* 边框 */
  border-radius: 5px; /* 圆角 */
  background-color: #ffffff; /* 内部填充颜色 */
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15); /* 增加阴影 */
  transition: transform 0.2s; /* 添加过渡效果 */
  white-space: nowrap; /* 确保内容不换行 */
  flex: 0 0 auto; /* 修改为自动宽度 */
  margin: 25px; /* 修改间隔为5px */
}

.item:hover {
  transform: scale(1.05); /* 悬停时放大效果 */
}

.category {
  font-weight: bold;
  margin-bottom: 5px; /* 减少分类和数值之间的间距 */
  font-size: 1em; /* 减少字体大小 */
}

.value {
  color: #409EFF;
  font-size: 1.2em; /* 减少字体大小 */
}

.el-row {
  width: 100%;
}

.el-col {
  display: flex;
  justify-content: center;
  margin-bottom: 15px;
}

.toggle-button {
  position: absolute; /* 绝对定位 */
  top: 10px; /* 距离顶部10px */
  right: 10px; /* 距离右侧10px */
  /* 添加按钮样式 */
}

.info-text {
  margin-top: 20px; /* 文本与按钮之间的间距 */
  /* 添加文本样式 */
}
</style>
