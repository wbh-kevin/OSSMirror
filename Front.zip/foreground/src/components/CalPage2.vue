<template>
    <div class="calpage-container">
        <div class="selector-wrapper">
            <SelectBar2 :options="options" :initialSelectedValue="receivedValue"
                @update:showStatus="updateStatusFromChild" :key="initialSelectedValue"
                @submit-data="handleSubmitData" />
        </div>

        <div class="main-content" v-if="status !== 0" style="margin-left: -200px;">
            <el-menu class="side-navigation" :default-active="activeNav" mode="vertical" background-color="#f7f7f7"
                text-color="#333" active-text-color="#409EFF">
                <!-- <el-menu-item @click="scrollToTop" index="top"> -->
                    <!-- <i class="el-icon-arrow-up"></i> {{ status === 4 ? 'General view' :
                        status === 1 ? 'View of module' : status === 2 ? 'View of company' :
                            status === 3 ? 'View of company and module' : 'Top' }} -->
                    <!-- <i class="el-icon-arrow-up"></i> {{ navTitle }} -->
                <!-- </el-menu-item> -->
                <el-menu-item @click="scrollToTop" index="top">
                    <el-tooltip effect="dark" :content="navTitle" placement="top">
                        <div class="ellipsis-text">
                        <i class="el-icon-arrow-up"></i> {{ navTitle }}
                        </div>
                    </el-tooltip>
                </el-menu-item>

                <el-menu-item v-for="(item, index) in getNavItems()" :key="index" :index="item.id"
                    @click="scrollToSection(item.id)" style="margin-left: 40px;">
                    <p
                        style="max-width: 200px; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; line-height: 1.2;">
                        {{ item.name }}
                    </p>

                </el-menu-item>
            </el-menu>

            <el-scrollbar class="chart-scrollbar">
                <div v-if="status === 4" class="charts-container">
                    <div id="chartContainer0" class="chart-wrapper">
                        <PieChart :chartData="chartData0" :title="'Overview'"
                            hiddenText="This chart shows how much commit made by each company and public volunteers." />
                    </div>
                    <div id="chartContainer1" class="chart-wrapper">
                        <BigCon :title="'Commits'"
                            :displayContent="'This chart shows the total number of commits in the selected repo by year.'"
                            :lineTitle="'Commits'" :value="value0" @switch-changed="handleSwitchChanged1" />
                    </div>
                </div>

                <div v-if="status === 1" class="charts-container">
                    <!-- 模块 -->
                    <div id="chartContainer0" class="chart-wrapper">
                        <BigCon :title="'Contribution Frequency'"
                            :displayContent="'This chart displays the trend of repository commits over time by showing the total number of commits within each time period. The time scale can be switched between year and month using the buttons at the top.'"
                            :lineTitle="'Commits'" :value="value1" @switch-changed="handleSwitchChanged2" />
                    </div>
                    <div id="chartContainer1" class="chart-wrapper">
                        <PieChart :chartData="chartData1" :title="'Company Ratio'"
                            hidden-text="This chart illustrates the proportion of commits made by different companies within the selected module of the repository, based on the account ownership information." />
                    </div>
                    <div id="chartContainer2" class="chart-wrapper">
                        <PieChart :chartData="chartData2" :title="'LOC'"
                            hidden-text="This chart shows the proportion of modified lines contributed by different companies within the selected module of the repository, based on the account ownership information." />
                    </div>
                </div>

                <div v-if="status === 2" class="charts-container">
                    <!-- 公司 -->
                    <!-- <div id="chartContainer0" class="chart-wrapper">
                        <BigCon :title="'Commit intensity'"
                            :displayContent="'This chart shows how the number of company contributions to the repository has changed over time'"
                            :lineTitle="'Commit intensity'" :value="value3" @switch-changed="handleSwitchChanged3" />
                    </div> -->

                    <div id="chartContainer0" class="chart-wrapper">
                        <BigCon4 :title="'Commit intensity'" :displayContent="'This chart shows how the number of company contributions to the repository has changed over time'"
                            :lineTitle="'Commit intensity'" @switch-changed="updateData5_1" :yearData="data5_1" />
                    </div>
                    <!-- <div id="chartContainer1" class="chartContainer">
              <BigCon
                :title="'Commit extension by time'"
                :displayContent="displayContent"
                :lineTitle="'Commit extension by time'"
                :value="value"
              />
            </div> -->
                    <!-- <div id="chartContainer2" class="chart-wrapper">
                        <BigCon :title="'Commit extension'"
                            :displayContent="'This chart shows how the number of modules the company contributed to the repository changed over time'"
                            :lineTitle="'Commit extension'" :value="value4" @switch-changed="handleSwitchChanged4" />
                    </div> -->
                    <div id="chartContainer2" class="chart-wrapper">
                        <BigCon4 :title="'Commit extension'" 
                            :displayContent="'This chart shows how the number of modules the company contributed to the repository changed over time'"
                            :lineTitle="'Commit extension'" @switch-changed="updateData5_2" :yearData="data5_2" />
                    </div>
                    <!-- <div id="chartContainer3" class="chartContainer">
              <PieChart
                :chartData="chartData3"
                :title="'Dependency on committers'"
              />
            </div> -->
                    <div id="chartContainer4" class="chart-wrapper" v-if="!String(this.selectedDropdown).includes(',')">
                        <PieChart :chartData="chartData4" :title="'Focused modules'"
                            hidden-text="This chart shows the percentage of contribution effort that the company allocates to different modules in the repository" />
                    </div>

                    <div id="chartContainer5" class="chart-wrapper" v-if=false>
                        <Div10 :values="numbers" />
                    </div>
                    <div id="chartContainer5" class="chart-wrapper" v-if="!String(this.selectedDropdown).includes(',')">
                        <Rador10  :chartData="radorData"/>
                    </div>
                </div>

                <div v-if="status === 3" class="charts-container">
                    <div id="chartContainer0" class="chart-wrapper">
                        <BigCon :title="'Commits'" :lineTitle="'Commits'" :value="value6"
                            :displayContent="'This chart shows how the number of modules the company contributed to the specific module in repository changed over time'"
                            @switch-changed="handleSwitchChanged6" />
                    </div>
                    <!-- <div id="chartContainer1" class="chartContainer">
              <PieChart
                :chartData="chartData"
                :title="'Cooperation with other companies'"
              />
            </div> -->
                </div>

                <div v-if="status === 5" style="margin-top: 10px; margin-bottom: 10px">
                    <WantMore />
                </div>
            </el-scrollbar>
        </div>
        <!-- <button class="scroll-to-top" v-if="isVisible" @click="scrollToTop">Top</button> -->
        <el-button class="scroll-to-top" @click="scrollToTop" v-if="isVisible" circle>
            <!-- <i class="el-icon-arrow-up"></i> -->
            <!-- <el-icon><Top /></el-icon> -->
            ▲
        </el-button>
    </div>
</template>

<script>
import { defineComponent } from "vue";
import PieChart from "@/components/PieChart.vue";
import BigCon from "@/components/BigCon.vue";
import BigCon4 from "@/components/BigCon4.vue";
import SelectBar2 from "@/components/SelectBar2.vue";
import WantMore from "@/components/WantMore.vue";
import Div10 from "./Div10.vue";
import Rador10 from "./Rador10.vue"

export default defineComponent({
    name: "App",
    components: {
        PieChart,
        BigCon,
        SelectBar2,
        WantMore,
        Div10,
        BigCon4,
        Rador10,
    },
    props: {
        receivedValue: {
            type: String,
            required: true,
        },
    },
    data() {
        return {
            radorData: [1.8, 0.6, 0.7, 0.5, 0.9, 0.4, 0.3, 1.0, 0.2, 0.7],
            customYearData: {
                xAxis: ["Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                series: [
                    { name: "Product A", data: [30, 40, 35, 50, 45, 60] },
                    { name: "Product B", data: [25, 35, 30, 45, 40, 55] },
                    { name: "Product C", data: [40, 50, 45, 60, 55, 70] },
                    { name: "Product D", data: [35, 45, 40, 55, 50, 65] },
                ],
            },
            urlP: `http://30901d0b.r40.cpolar.top/getData/`,
            options: [],
            selectedValue: "",
            bigConTitle: "BrokenLine Title",
            displayContent: "Information about chart",
            chartTitle: "PieChart Title",
            module: "",
            submodule: "",
            subsubmodule: "",
            selectedDropdown: "",
            data: {},
            data5_1: {},
            data5_2: {},
            chartData0: {},
            chartData3: {},
            chartData4: {},
            value0: {},
            value3: {},
            value4: {},
            value5: {},
            value6: {},
            chartData1: {},
            chartData2: {},
            chartData: {},
            tripleOptions: [],
            title: "line",
            value1: {},
            value: {
                xAxis: [],
                yAxis: [],
            },
            status: 0,
            activeNav: "top",
            numbers: [],
            isVisible: false,
            navTitle: '',
        };
    },
    mounted() {
        // 弹出传递的值
        console.log("Received value from parent:", this.receivedValue);

        fetch(this.urlP + "getRepoList2")
            .then((response) => response.json())
            .then((data) => {
                this.options = data.map((item) => ({
                label: item.name + (item.id==1?` (Last updated: ${item.date})`:` (Calculating: ${item.date})`),
                value: item.name
                }));
            })
        // 获取数据的逻辑
        // fetch("http://10.108.119.152:8888/getData/getRepoList")
        //     .then((response) => response.json())
        //     .then((data) => {
        //         this.options = data.map((item) => ({ label: item, value0: item }));
        //     })
        //     .catch((error) => console.error("获取数据失败:", error));

        window.addEventListener('scroll', this.handleScroll);
    },
    beforeUnmount() {
        window.removeEventListener('scroll', this.handleScroll);
    },
    methods: {
        async handleSwitchChanged1(newValue) {
            const tail = newValue === "Month" ? 1 : 0;
            // alert(tail)
            try {
                // 2. 获取提交数量数据并更新 value
                const commitCountUrl = this.urlP + `getCommitCount?repo=${this.selectedValue}&time=${tail}`;
                // alert(commitCountUrl)
                const commitCountResponse = await fetch(commitCountUrl);
                const commitCountText = await commitCountResponse.text();
                let commitCountData = [];

                try {
                    commitCountData = JSON.parse(commitCountText);
                } catch (e) {
                    console.error("解析 JSON 失败:", commitCountText);
                    alert(`返回的提交数数据格式异常:\n${commitCountText}`);
                    return;
                }
                this.value0.xAxis = commitCountData.map((item) => item.time);
                this.value0.yAxis = commitCountData.map((item) => item.count);
            } catch (error) {
                console.error("请求失败:", error);
                alert("获取数据失败，请检查 API 服务是否正常。");
            }
        },
        async handleSwitchChanged2(newValue) {

            var suburl = this.module;
            var type = 1;

            if (this.submodule !== "" && this.submodule !== "view_all") {
                suburl = suburl + "/" + this.submodule;
                type = 2;
            }

            if (this.subsubmodule !== "" && this.subsubmodule !== "view_all") {
                suburl = suburl + "/" + this.subsubmodule;
                type = 3;
            }

            // 对 URL 进行编码处理
            suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
            suburl = encodeURIComponent(suburl);
            if (newValue !== "Month") {
                type += 3;
            }
            // 构造最终的 URL
            var url = this.urlP + `getModule?repo=${this.selectedValue}&prefix=${suburl}&type=${type}`;
            // alert(url)
            // 用 fetch 获取 URL 的数据
            try {
                // 获取 URL 的数据
                const response = await fetch(url);
                const responseText1 = await response.text(); // 获取返回的文本数据
                const responseText = responseText1.slice(
                    1,
                    responseText1.length - 1
                );
                // 解析返回的字符串数据
                const rawData = {};

                // 按照逗号分割字符串，得到每一对 'key=value'
                const items = responseText.split(",");

                items.forEach((item) => {
                    // 按等号分割每个 'key=value' 字符串
                    const [key, value] = item.split("=");
                    if (key && value) {
                        rawData[key.trim()] = parseInt(value.trim(), 10); // 转换 value 为数字
                    }
                });

                // 提取 xAxis 和 yAxis
                const xAxis = Object.keys(rawData); // 获取所有的日期（年份-月份）
                const yAxis = Object.values(rawData); // 获取对应的值
                // 格式化 value1
                this.value1 = {
                    xAxis: xAxis,
                    yAxis: yAxis,
                };
            } catch (error) {
                console.error("获取数据失败:", error);
                alert("获取数据失败，请检查 API 服务是否正常。");
            }
        },
        async handleSwitchChanged3(newValue) {
            var t = 0;
            if (newValue !== "Month") {
                t = 1;
            }
            var url = this.urlP + `getCI?repo=${this.selectedValue}&company=${this.selectedDropdown}&type=${t}`;
            // alert(url);
            try {
                // 获取 URL 的数据
                const response = await fetch(url);
                const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                // alert(JSON.stringify(responseData))
                // this.value = responseData
                const xAxis = Object.keys(responseData);
                const yAxis = Object.values(responseData);
                this.value3 = { xAxis: xAxis, yAxis: yAxis };
                // 将返回的数据存入 this.chartData1
                // this.chartData2 = responseData;
            } catch (error) {
                console.error("获取数据失败:", error);
                alert("获取数据失败，请检查 API 服务是否正常。");
            }
        },
        async handleSwitchChanged4(newValue) {
            var t = 0;
            if (newValue !== "Month") {
                t = 1;
            }
            var url = this.urlP + `getCE?repo=${this.selectedValue}&company=${this.selectedDropdown}&type=${t}`;
            // alert(url);
            try {
                // 获取 URL 的数据
                const response = await fetch(url);
                const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                // alert(JSON.stringify(responseData))
                // this.value = responseData
                const xAxis = Object.keys(responseData);
                const yAxis = Object.values(responseData);
                this.value4 = { xAxis: xAxis, yAxis: yAxis };
                // 将返回的数据存入 this.chartData1
                // this.chartData2 = responseData;
            } catch (error) {
                console.error("获取数据失败:", error);
                alert("获取数据失败，请检查 API 服务是否正常。");
            }
        },
        async updateData5_1(newValue) {
            var t = 0;
            const selectedDropdownString = String(this.selectedDropdown); // 或者使用 this.selectedDropdown.toString()

                // 使用转换后的字符串进行后续操作
                const dropdownItems = selectedDropdownString.split(',');
                const allYAxisData = []; // 用于存储所有的 yAxis 数据
                const allXAxisData = [];
                t = 0;
                if (newValue !== "Month") {
                    t = 1;
                }
                for (const item of dropdownItems) {
                    // alert(item)
                    const url = this.urlP + `getCI?repo=${this.selectedValue}&company=${item}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        const xAxis = Object.keys(responseData);
                        // 修改 yAxis 的结构
                        const yAxis = {
                            name: item,
                            data: Object.values(responseData)
                        };
                        // alert(JSON.stringify(Object.values))
                        allXAxisData.push(xAxis)
                        allYAxisData.push(yAxis); // 将每个 yAxis 数据添加到数组中
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常_5_1。");
                    }
                }
                const finalXAxis = []
                for (const xAxis of allXAxisData) {
                    for (const item of xAxis) {
                        if (!finalXAxis.includes(item)) {
                            finalXAxis.push(item); // 添加不重复的元素
                        }
                    }
                }

                // 在这里对 finalXAxis 进行字典序升序排列
                finalXAxis.sort(); // 按字典序升序排列

                const finalYAxis = []
                // 检查并填充 allYAxisData
                for (let i = 0; i < allXAxisData.length; i++) {
                    const yAxis = {
                        name: dropdownItems[i],
                        data: []
                    };
                    for (const x of finalXAxis) {
                        if (allXAxisData[i].includes(x)) {
                            yAxis.data.push(allYAxisData[i].data[allXAxisData[i].indexOf(x)]); // 添加对应的值
                        } else {
                            yAxis.data.push(0); // 添加0
                        }
                    }
                    finalYAxis.push(yAxis); // 将 yAxis 添加到 allYAxisData
                }
                this.data5_1 = { xAxis: finalXAxis, series: finalYAxis }; // 更新 data5_1
                // alert(JSON.stringify(this.data5_1))
                // url = this.urlP + `getCE?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        },
        async updateData5_2(newValue) {
            var t = 0;
            const selectedDropdownString = String(this.selectedDropdown); // 或者使用 this.selectedDropdown.toString()

                // 使用转换后的字符串进行后续操作
                const dropdownItems = selectedDropdownString.split(',');
                const allYAxisData = []; // 用于存储所有的 yAxis 数据
                const allXAxisData = [];
                t = 0;
                if (newValue !== "Month") {
                    t = 1;
                }
                for (const item of dropdownItems) {
                    // alert(item)
                    const url = this.urlP + `getCE?repo=${this.selectedValue}&company=${item}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        const xAxis = Object.keys(responseData);
                        // 修改 yAxis 的结构
                        const yAxis = {
                            name: item,
                            data: Object.values(responseData)
                        };
                        // alert(JSON.stringify(Object.values))
                        allXAxisData.push(xAxis)
                        allYAxisData.push(yAxis); // 将每个 yAxis 数据添加到数组中
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常_5_1。");
                    }
                }
                const finalXAxis = []
                for (const xAxis of allXAxisData) {
                    for (const item of xAxis) {
                        if (!finalXAxis.includes(item)) {
                            finalXAxis.push(item); // 添加不重复的元素
                        }
                    }
                }

                // 在这里对 finalXAxis 进行字典序升序排列
                finalXAxis.sort(); // 按字典序升序排列

                const finalYAxis = []
                // 检查并填充 allYAxisData
                for (let i = 0; i < allXAxisData.length; i++) {
                    const yAxis = {
                        name: dropdownItems[i],
                        data: []
                    };
                    for (const x of finalXAxis) {
                        if (allXAxisData[i].includes(x)) {
                            yAxis.data.push(allYAxisData[i].data[allXAxisData[i].indexOf(x)]); // 添加对应的值
                        } else {
                            yAxis.data.push(0); // 添加0
                        }
                    }
                    finalYAxis.push(yAxis); // 将 yAxis 添加到 allYAxisData
                }
                this.data5_2 = { xAxis: finalXAxis, series: finalYAxis }; // 更新 data5_1
        },
        async handleSwitchChanged6(newValue) {
            // alert(newValue)

            var suburl = this.module;
            var type = 1;

            if (this.submodule !== "" && this.submodule !== "view_all") {
                suburl = suburl + "/" + this.submodule;
                type = 2;
            }

            if (this.subsubmodule !== "" && this.subsubmodule !== "view_all") {
                suburl = suburl + "/" + this.subsubmodule;
                type = 3;
            }
            if (newValue !== "Month") {
                type += 3;
            }
            // alert(suburl)
            // 对 URL 进行编码处理
            suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
            suburl = encodeURIComponent(suburl);
            var url = this.urlP + `getCF?repo=${this.selectedValue}&company=${this.selectedDropdown}&type=${type}&prefix=${suburl}`;
            // alert(url);
            try {
                // 获取 URL 的数据
                const response = await fetch(url);
                const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                // alert(JSON.stringify(responseData))
                // this.value = responseData
                const xAxis = Object.keys(responseData);
                const yAxis = Object.values(responseData);
                this.value6 = { xAxis: xAxis, yAxis: yAxis };
                // 将返回的数据存入 this.chartData1
                // this.chartData2 = responseData;
            } catch (error) {
                console.error("获取数据失败:", error);
                alert("获取数据失败，请检查 API 服务是否正常。");
            }
        },
        async handleSubmitData(data) {
            // alert(data.showStatus)
            // alert(JSON.stringify(data))
            const selectedValue = data.selectedValue;
            this.selectedValue = selectedValue;
            if (data.showStatus === 4) {
                try {
                    // 1. 获取总数统计数据并更新 chartData
                    const totalCountUrl = this.urlP + `getTotalCount?repo=${selectedValue}`;
                    const totalCountResponse = await fetch(totalCountUrl);
                    const totalCountText = await totalCountResponse.text(); // 直接获取文本格式
                    let totalCountData = {};

                    try {
                        totalCountData = JSON.parse(totalCountText); // 解析 JSON
                    } catch (e) {
                        console.error("解析 JSON 失败:", totalCountText);
                        alert(`返回的总数数据格式异常:\n${totalCountText}`);
                        return;
                    }

                    this.chartData0 = totalCountData;
                    this.chartDataKey++;

                    // 2. 获取提交数量数据并更新 value
                    const commitCountUrl = this.urlP + `getCommitCount?repo=${selectedValue}`;
                    const commitCountResponse = await fetch(commitCountUrl);
                    const commitCountText = await commitCountResponse.text();
                    let commitCountData = [];

                    try {
                        commitCountData = JSON.parse(commitCountText);
                    } catch (e) {
                        console.error("解析 JSON 失败:", commitCountText);
                        alert(`返回的提交数数据格式异常:\n${commitCountText}`);
                        return;
                    }

                    // 解析 year 和 count 到 value 的 xAxis 和 yAxis
                    this.value0.xAxis = commitCountData.map((item) => item.time);
                    this.value0.yAxis = commitCountData.map((item) => item.count);

                    // 3. 强制刷新 chartContainer1
                    this.chartContainer1Key++;

                    // 更新侧栏部分的标题为 data.selectedValue
                    this.$nextTick(() => {
                        this.navTitle = 'General view of repo '+ data.selectedValue
                    });
                } catch (error) {
                    console.error("请求失败:", error);
                    alert("获取数据失败，请检查 API 服务是否正常。");
                }
            } else if (data.showStatus === 1) {
                    // this.$nextTick(() => {
                    //     this.navTitle = 'General view of repo '+ data.selectedValue
                    // });
                if (!isNaN(Number(data.module))) {
                    this.navTitle = 'Module view: '
                    var suburl = data.module;
                    suburl = data.tri[Number(data.module)].name;
                    this.module = data.tri[Number(data.module)].name;
                    var type = 1;

                    if (data.submodule !== "" && data.submodule !== "view_all") {
                        suburl = suburl + "/" + data.tri[Number(data.submodule)].name;
                        this.submodule = data.tri[Number(data.submodule)].name;
                        type = 2;
                    }

                    if (data.subsubmodule !== "" && data.subsubmodule !== "view_all") {
                        suburl = suburl + "/" + data.tri[Number(data.subsubmodule)].name;
                        this.subsubmodule = data.tri[Number(data.subsubmodule)].name;
                        type = 3;
                    }

                    if (data.selectedRadio === "Option 1") {
                        type += 3;
                    }

                    this.navTitle += suburl

                    // 对 URL 进行编码处理
                    suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
                    suburl = encodeURIComponent(suburl);

                    // 构造最终的 URL
                    var url = this.urlP + `getModule?repo=${data.selectedValue}&prefix=${suburl}&type=${type}`;
                    // alert(url)
                    // 用 fetch 获取 URL 的数据
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseText1 = await response.text(); // 获取返回的文本数据
                        const responseText = responseText1.slice(
                            1,
                            responseText1.length - 1
                        );
                        // 解析返回的字符串数据
                        const rawData = {};

                        // 按照逗号分割字符串，得到每一对 'key=value'
                        const items = responseText.split(",");

                        items.forEach((item) => {
                            // 按等号分割每个 'key=value' 字符串
                            const [key, value] = item.split("=");
                            if (key && value) {
                                rawData[key.trim()] = parseInt(value.trim(), 10); // 转换 value 为数字
                            }
                        });

                        // 提取 xAxis 和 yAxis
                        const xAxis = Object.keys(rawData); // 获取所有的日期（年份-月份）
                        const yAxis = Object.values(rawData); // 获取对应的值

                        // 格式化 value1
                        this.value1 = {
                            xAxis: xAxis,
                            yAxis: yAxis,
                        };
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。");
                    }
                    var t = type % 3;
                    // 用 fetch 获取 URL 的数据
                    url = this.urlP + `getModuleC?repo=${data.selectedValue}&prefix=${suburl}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        // alert(responseData)
                        // 将返回的数据存入 this.chartData1
                        this.chartData1 = responseData;

                        // console.log("chartData:", this.chartData); // 打印返回的数据，查看是否正确存入
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。");
                    }
                    url = this.urlP + `getModuleCL?repo=${data.selectedValue}&prefix=${suburl}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        // alert(responseData)
                        // 将返回的数据存入 this.chartData1
                        this.chartData2 = responseData;
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。");
                    }
                }
            } else if (data.showStatus === 2) {
                
                this.navTitle = 'Company view: ' + data.selectedDropdown;
                this.selectedDropdown = data.selectedDropdown;
                // 将 selectedDropdown 转换为字符串
                const selectedDropdownString = String(this.selectedDropdown); // 或者使用 this.selectedDropdown.toString()

                // 使用转换后的字符串进行后续操作
                const dropdownItems = selectedDropdownString.split(',');
                var allYAxisData = []; // 用于存储所有的 yAxis 数据
                var allXAxisData = [];
                t = 0;
                if (data.selectedRadio === "Option 1") {
                    t = 1;
                }
                for (const item of dropdownItems) {
                    // alert(item)
                    const url = this.urlP + `getCI?repo=${data.selectedValue}&company=${item}&type=${t}`;
                    //alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        const xAxis = Object.keys(responseData);
                        // 修改 yAxis 的结构
                        const yAxis = {
                            name: item,
                            data: Object.values(responseData)
                        };
                        // alert(JSON.stringify(Object.values))
                        allXAxisData.push(xAxis)
                        allYAxisData.push(yAxis); // 将每个 yAxis 数据添加到数组中
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常_CI");
                    }
                }
                
                var finalXAxis = []
                for (const xAxis of allXAxisData) {
                    for (const item of xAxis) {
                        if (!finalXAxis.includes(item)) {
                            finalXAxis.push(item); // 添加不重复的元素
                        }
                    }
                }

                // 在这里对 finalXAxis 进行字典序升序排列
                finalXAxis.sort(); // 按字典序升序排列

                var finalYAxis = []
                // 检查并填充 allYAxisData
                for (let i = 0; i < allXAxisData.length; i++) {
                    const yAxis = {
                        name: dropdownItems[i],
                        data: []
                    };
                    for (const x of finalXAxis) {
                        if (allXAxisData[i].includes(x)) {
                            yAxis.data.push(allYAxisData[i].data[allXAxisData[i].indexOf(x)]); // 添加对应的值
                        } else {
                            yAxis.data.push(0); // 添加0
                        }
                    }
                    finalYAxis.push(yAxis); // 将 yAxis 添加到 allYAxisData
                }
                this.data5_1 = { xAxis: finalXAxis, series: finalYAxis }; // 更新 data5_1

                allXAxisData = []
                allYAxisData = []
                for (const item of dropdownItems) {
                    // alert(item)
                    const url = this.urlP + `getCE?repo=${data.selectedValue}&company=${item}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        const xAxis = Object.keys(responseData);
                        // 修改 yAxis 的结构
                        const yAxis = {
                            name: item,
                            data: Object.values(responseData)
                        };
                        // alert(JSON.stringify(Object.values))
                        allXAxisData.push(xAxis)
                        allYAxisData.push(yAxis); // 将每个 yAxis 数据添加到数组中
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常_CI");
                    }
                }
                finalXAxis = []
                for (const xAxis of allXAxisData) {
                    for (const item of xAxis) {
                        if (!finalXAxis.includes(item)) {
                            finalXAxis.push(item); // 添加不重复的元素
                        }
                    }
                }

                // 在这里对 finalXAxis 进行字典序升序排列
                finalXAxis.sort(); // 按字典序升序排列

                finalYAxis = []
                // 检查并填充 allYAxisData
                for (let i = 0; i < allXAxisData.length; i++) {
                    const yAxis = {
                        name: dropdownItems[i],
                        data: []
                    };
                    for (const x of finalXAxis) {
                        if (allXAxisData[i].includes(x)) {
                            yAxis.data.push(allYAxisData[i].data[allXAxisData[i].indexOf(x)]); // 添加对应的值
                        } else {
                            yAxis.data.push(0); // 添加0
                        }
                    }
                    finalYAxis.push(yAxis); // 将 yAxis 添加到 allYAxisData
                }
                this.data5_2 = { xAxis: finalXAxis, series: finalYAxis }; // 更新 data5_1
                // alert(JSON.stringify(this.data5_1))
                // url = this.urlP + `getCE?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
                // // alert(url)
                // try {
                //     // 获取 URL 的数据
                //     const response = await fetch(url);
                //     const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                //     // alert(JSON.stringify(responseData))
                //     // this.value = responseData
                //     const xAxis = Object.keys(responseData);
                //     // 修改 yAxis 的结构
                //     const yAxis = [{
                //         name: this.selectedDropdown,
                //         data: Object.values(responseData)
                //     }];
                //     this.data5_2 = { xAxis: xAxis, series: yAxis };
                //     // 将返回的数据存入 this.chartData1
                //     // this.chartData2 = responseData;
                // } catch (error) {
                //     console.error("获取数据失败:", error);
                //     alert("获取数据失败，请检查 API 服务是否正常。_52");
                // }
                
                // 检查 selectedDropdown 是否包含逗号

                if (!String(data.selectedDropdown).includes(',')) {
                    url = this.urlP + `getDep?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        // alert(JSON.stringify(responseData))
                        this.chartData3 = responseData;
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。_pie");
                    }
                    url = this.urlP + `getMF?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        // alert(JSON.stringify(responseData))
                        this.chartData4 = responseData;
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。_div");
                    }
                    url = this.urlP + `getDiv?repo=${data.selectedValue}&company=${data.selectedDropdown}`;
                    // alert(url);

                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);

                        // 获取返回的字符串数据
                        const responseData = await response.text(); // 使用 text() 而不是 json()
                        // alert(responseData.split("\n")[0])
                        // alert(responseData); // 直接显示返回的字符串
                        this.radorData = responseData.split("\n").map(Number).slice(0, 10);
                        // 检查 radorData 是否全为 0
                        // const total = this.radorData.reduce((acc, val) => acc + val, 0);
                        // if (total > 0) {
                        //     this.radorData = this.radorData.map(value => (value / total) * 100); // 转换为占比值
                        // }
                        // alert(JSON.stringify(this.radorData))
                        this.numbers = responseData.split("\n").map(Number);
                        // this.chartData4 = responseData; // 如果你需要在图表中使用它
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。");
                    }
                }
            } else if (data.showStatus === 3) {
                    this.navTitle ='Company: ' + data.selectedDropdown + ' Module: ';
                // alert(data.showStatus)
                // alert(data.selectedDropdown)
                this.selectedDropdown = data.selectedDropdown;
                if (!isNaN(Number(data.module))) {
                    suburl = data.module;
                    suburl = data.tri[Number(data.module)].name;
                    type = 1;

                    if (data.submodule !== "" && data.submodule !== "view_all") {
                        suburl = suburl + "/" + data.tri[Number(data.submodule)].name;
                        type = 2;
                    }

                    if (data.subsubmodule !== "" && data.subsubmodule !== "view_all") {
                        suburl = suburl + "/" + data.tri[Number(data.subsubmodule)].name;
                        type = 3;
                    }

                    if (data.selectedRadio === "Option 1") {
                        type += 3;
                    }
                    this.navTitle +=  suburl
                    suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
                    suburl = encodeURIComponent(suburl);
                    url = this.urlP + `getCF?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${type}&prefix=${suburl}`;
                    // alert(url)
                    try {
                        // 获取 URL 的数据
                        const response = await fetch(url);
                        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
                        // alert(JSON.stringify(responseData))
                        const xAxis = Object.keys(responseData);
                        const yAxis = Object.values(responseData);
                        this.value6 = { xAxis: xAxis, yAxis: yAxis };
                    } catch (error) {
                        console.error("获取数据失败:", error);
                        alert("获取数据失败，请检查 API 服务是否正常。");
                    }
                }
            }

            // Emit 更新选中的值
            this.$emit("update-selected-value", selectedValue);
        },
        setStatus(value0) {
            this.status = value0;
        },
        scrollToSection(sectionId) {
            const element = document.getElementById(sectionId);
            if (element) {
                element.scrollIntoView({
                    behavior: "smooth",
                    block: "start",
                });
            }
        },
        scrollToTop() {
            window.scrollTo({
                top: 0,
                behavior: "smooth",
            });
        },
        getNavItems() {
            const chartContainers = [];
            if (this.status === 4) {
                chartContainers.push({ id: "chartContainer0", name: "Overview" });
                chartContainers.push({ id: "chartContainer1", name: "Commits" });
            } else if (this.status === 1) {
                chartContainers.push({
                    id: "chartContainer0",
                    name: "Contribution Frequency",
                });
                chartContainers.push({
                    id: "chartContainer1",
                    name: "Company Ratio",
                });
                chartContainers.push({
                    id: "chartContainer2",
                    name: "LOC",
                });
            } else if (this.status === 2) {
                chartContainers.push({
                    id: "chartContainer0",
                    name: "Commit intensity",
                });
                chartContainers.push({
                    id: "chartContainer2",
                    name: "Commit extension",
                });
                if (!String(this.selectedDropdown).includes(',')){
                    chartContainers.push({
                        id: "chartContainer4",
                        name: "Focused modules",
                    });
                    chartContainers.push({
                        id: "chartContainer5",
                        name: "Task preference",
                    });
                }
            }
            // 更多状态条件...
            return chartContainers;
        },
        updateStatusFromChild(newStatus) {
            this.status = newStatus;
        },
        handleScroll() {
            this.isVisible = window.scrollY > 100;
        },
    },
});
</script>
<style scoped>
.calpage-container {
    max-width: 1920px;
    margin: 0 auto;
    padding: 20px;
}

.selector-wrapper {
    max-width: 1200px;
    margin: 0 auto 20px;
    padding: 0 20px;
}

.main-content {
    display: flex;
    gap: 30px;
    position: relative;
}

.side-navigation {
    position: sticky;
    top: 20px;
    width: 250px;
    height: fit-content;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.chart-scrollbar {
    flex: 1;
    /* max-height: calc(100vh - 100px); */
    overflow-y: auto;
    overflow-x: hidden;
}

.charts-container {
    padding: 20px;
    /* width: 1050px; */
    overflow-x: hidden;
}

.chart-wrapper {
    width: 100%;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 30px;
    min-height: 400px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.el-menu-item {
    font-size: 15px;
    height: 50px;
    line-height: 50px;
    padding-left: 20px !important;
    white-space: normal;
    /* border-top: 1px solid #e0e0e0; */
    border-bottom: 2px solid #e0e0e0;
}

.el-menu-item i+span,
.el-menu-item:has(.el-icon-arrow-up) {
    padding-left: 0px !important;
}

.el-menu-item:not(:has(.el-icon-arrow-up)) {
    padding-left: 20px !important;
}

.el-menu-item:hover {
    background-color: #e6f1fe !important;
}

@media (max-width: 1400px) {
    .main-content {
        flex-direction: column;
    }

    .side-navigation {
        width: 100%;
        position: static;
        margin-bottom: 20px;
    }

    .chart-scrollbar {
        max-height: none;
    }
}

.scroll-to-top {
    position: fixed;
    bottom: 100px;
    right: 80px;
    background-color: #409EFF;
    color: white;
    /* border: none;
    border-radius: 5px;
    padding: 10px 15px;
    cursor: pointer;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.2);
    z-index: 1000; */
    /* 确保按钮在其他元素之上 */
}

.scroll-to-top:hover {
    background-color: #66b1ff;
}
.ellipsis-text {
  display: inline-block;
  max-width: 220px; /* 根据你菜单的宽度调整 */
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  vertical-align: middle;
}
</style>