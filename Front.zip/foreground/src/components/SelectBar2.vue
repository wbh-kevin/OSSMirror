<template>
  <div class="selectbar-wrapper">
    <div class="selectbar-container">
      <!-- 左侧下拉框 -->
      <el-select
        v-model="selectedValue"
        placeholder="Select or input github repo"
        class="repo-select"
        filterable
        allow-create
        :options="options"
        @change="handleSelectionChange"
        clearable
      >
        <template #prefix>
          <i class="el-icon-search"></i>
        </template>
        <el-option
          v-for="item in options"
          :key="item.value"
          :label="item.label"
          :value="item.value"
        />
      </el-select>

      <!-- 右侧按钮 -->
      <el-button
        type="primary"
        class="submit-button"
        @click="handleButtonClick"
        :loading="loading"
      >
        <i class="el-icon-upload2 mr-2"></i>
        SUBMIT
      </el-button>
    </div>

    <!-- 展开区域 -->
    <div v-if="isExpanded" class="expanded-options" style="margin-left: 0px;">
      <!-- 三联下拉框 -->
      <div class="triple-select" style="margin-left: 20px;">
        <el-select
          v-model="selectedTriple[0]"
          @change="handleModuleChange"
          placeholder="Module"
          :disabled="isDisabled(0)"
        >
          <el-option label="view all" value="view_all" />
          <el-option
            v-for="item in moduleRange"
            :key="item"
            :label="tripleOptions[item].name|| '\\'"
            :value="item"
          />
        </el-select>

        <el-select
          v-model="selectedTriple[1]"
          @change="handleSubmoduleChange"
          placeholder="Submodule"
          :disabled="isDisabled(1)"
        >
          <el-option label="view all" value="view_all" />
          <el-option
            v-for="item in submoduleRange"
            :key="item"
            :label="tripleOptions[item].name|| '\\'"
            :value="item"
          />
        </el-select>

        <el-select
          v-model="selectedTriple[2]"
          @change="handleSelectionChange"
          placeholder="SubSubmodule"
          :disabled="isDisabled(2)"
        >
          <el-option label="view all" value="view_all" />
          <el-option
            v-for="item in subsubmoduleRange"
            :key="item"
            :label="tripleOptions[item].name|| '\\'"
            :value="item"
          />
        </el-select>
      </div>

      <!-- 单选框 -->
      <div class="radio-group" v-if="false">
        <el-radio-group v-model="selectedRadio" @change="handleSelectionChange">
          <el-radio label="Option 1">Year</el-radio>
          <el-radio label="Option 2">Month</el-radio>
        </el-radio-group>
      </div>

      <!-- <div style="width: 300px; height: 100px;" /> -->

      <!-- 下拉框 -->
      <div class="select-container" style="margin-left: 100px;">
        <el-select
          v-model="selectedDropdown"
          @change="handleSelectionChange"
          placeholder="Choose one Company"
          clearable
          @clear="handleClear"
          multiple
          :collapse-tags="true"
          :tag-type="'success'"
          :max-tags="4"
        >
          <el-option
            v-for="item in selectedDropdownOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
    </div>

    <!-- 加载动画 -->
    <el-loading v-if="loading" :fullscreen="true"></el-loading>
  </div>
</template>

<script>
export default {
  name: "SelectBar",
  props: {
    options: {
      type: Array,
      required: true,
    },
    dropdownOptions: {
      type: Array,
      required: true,
    },
    initialSelectedValue: {
      type: String,
      default: "", // 默认值为空字符串
    },
  },
  data() {
    return {
      selectedValue: this.initialSelectedValue, // 使用传递的初始值
      isExpanded: false,
      selectedTriple: ["view_all", "", ""],
      selectedRadio: "Option 1",
      selectedDropdown: "",
      selectedDropdownOptions: [],
      tripleOptions: [
        { name: "Option 0", start: 1, end: 3 },
        { name: "Option 1", start: 4, end: 4 },
        { name: "Option 2", start: 5, end: 6 },
        { name: "Option 3", start: 7, end: 7 },
        { name: "Option 4", start: 8, end: 8 },
        { name: "Option 5", start: 9, end: 9 },
        { name: "Option 6", start: 10, end: 10 },
        { name: "Option 7", start: 11, end: 11 },
        { name: "Option 8", start: 0, end: 0 },
        { name: "Option 9", start: 0, end: 0 },
        { name: "Option 10", start: 0, end: 0 },
        { name: "Option 11", start: 0, end: 0 },
      ],
      urlP: `http://30901d0b.r40.cpolar.top/getData/`,
      moduleRange: [],  // 用于存储模块范围
      submoduleRange: [], // 用于存储Submodule范围
      subsubmoduleRange: [], // 用于存储SubSubmodule范围
      showStatus: 0,
      loading: false,
    };
  },
  mounted() {
    // 初始化时，计算moduleRange
    this.initializeModuleRange();

    // 当 initialSelectedValue 不为空时，自动触发按钮点击事件
    if (this.initialSelectedValue) {
      this.handleButtonClick();
    }
  },
  watch: {
    selectedValue(newValue) {
      if (newValue) {
        this.handleButtonClick(); // 当 selectedValue 发生变化时触发按钮点击
        this.showStatus = 1; // 设置 showStatus 为 1
      }
    },
    selectedTriple: {
      handler() {
        this.updateShowStatus();
      },
      deep: true,
    },
    selectedDropdown(newVal) {
      if (Array.isArray(newVal) && newVal.length === 0) {
        this.selectedDropdown = ""; // 强制设为空字符串
      }
      this.updateShowStatus();
    },
    tripleOptions: {
      handler(newVal) {
        if (newVal.length > 0) {
          this.initializeModuleRange();
        }
      },
      deep: true,
      immediate: true,
    },

  },
  methods: {
    isDisabled(index) {
      return this.selectedTriple[index - 1] === "view_all" || this.selectedTriple[index - 2] === "view_all";
    },

    updateShowStatus() {
      // alert(this.selectedDropdown==="")
      const firstTriple = this.selectedTriple[0];
      const isDropdownSelected = this.selectedDropdown !== "";

      if (firstTriple === "view_all" && !isDropdownSelected) {
        this.showStatus = 4;
      } else if (firstTriple === "view_all" && isDropdownSelected) {
        this.showStatus = 2;
      } else if (firstTriple !== "view_all" && isDropdownSelected) {
        this.showStatus = 3;
      } else if (this.selectedTriple.some((item) => item !== "")) {
        this.showStatus = 1;
      }

      this.$nextTick(() => {
        // alert(`Company: ${this.selectedDropdown}`)
        this.$emit("update:showStatus", this.showStatus);
        this.$emit("submit-data", {
          selectedValue: this.selectedValue,
          module: this.selectedTriple[0],
          submodule: this.selectedTriple[1],
          subsubmodule: this.selectedTriple[2],
          selectedRadio: this.selectedRadio,
          selectedDropdown: this.selectedDropdown,
          showStatus: this.showStatus,
          tri: this.tripleOptions,
        });
        // alert(
        //   `Submitted Data:\n` +
        //   `Repo: ${this.selectedValue}\n` +
        //   `Module: ${this.selectedTriple[0]}\n` +
        //   `Submodule: ${this.selectedTriple[1]}\n` +
        //   `SubSubmodule: ${this.selectedTriple[2]}\n` +
        //   `Radio: ${this.selectedRadio}\n` +
        //   `Company: ${this.selectedDropdown}\n` +
        //   `Status: ${this.showStatus}`
        // );
      });
    },

    async handleButtonClick() {
      if (!this.selectedValue) {
        alert("Please select a repository!");
        return;
      }
      this.loading = true;
      this.updateShowStatus();
      //
      const url2 = this.urlP + `getFileStru?repo=${this.selectedValue}`;
      
      try {
        const response = await fetch(url2);
        const data = await response.json();
        // alert(JSON.stringify(this.tripleOptions, null, 2))
        this.tripleOptions = data; // 直接赋值给 tripleOptions
      } catch (error) {
        console.error("请求失败:", error);
        this.unToggleExpand();
        alert("Failed to fetch data. Please try again.");
      } finally {
        this.loading = false;
      }

      //

      const url = this.urlP + `getCompanyList?repo=${this.selectedValue}`;
      
      try {
        const response = await fetch(url);
        const data = await response.json();
        
        this.toggleExpand();
        this.selectedDropdownOptions = data.map((item) => ({
          label: item,
          value: item,
        }));
      } catch (error) {
        console.error("请求失败:", error);
        this.unToggleExpand();
        alert("Failed to fetch data. Please try again.");
      } finally {
        this.loading = false;
        this.updateShowStatus();
      }
      // alert(Number(this.selectedTriple[0]))
      this.$emit("submit-data", {
        selectedValue: this.selectedValue,
        module: this.selectedTriple[0],
        submodule: this.selectedTriple[1],
        subsubmodule: this.selectedTriple[2],
        selectedRadio: this.selectedRadio,
        selectedDropdown: this.selectedDropdown,
        showStatus: this.showStatus,
        tri: this.tripleOptions,
      });
      // alert(
      //   `Submitted Data:\n` +
      //   `Repo: ${this.selectedValue}\n` +
      //   `Module: ${this.selectedTriple[0]}\n` +
      //   `Submodule: ${this.selectedTriple[1]}\n` +
      //   `SubSubmodule: ${this.selectedTriple[2]}\n` +
      //   `Radio: ${this.selectedRadio}\n` +
      //   `Company: ${this.selectedDropdown}\n` +
      //   `Status: ${this.showStatus}`
      // );
    },

    toggleExpand() {
      this.isExpanded = true;
    },

    unToggleExpand() {
      this.isExpanded = false;
    },

    handleClear() {
      this.selectedDropdown = "";  // 显式设置为空字符串
    },

    initializeModuleRange() {
      const start = parseInt(this.tripleOptions[0].start);
      const end = parseInt(this.tripleOptions[0].end);
      
      // 生成从start到end的数组
      this.moduleRange = Array.from({ length: end - start + 1 }, (_, index) => start + index);
      // alert(this.moduleRange)
    },

    handleModuleChange(selectedModule) {
      // alert(this.selectedModule)
      // 找到与当前选择的Module对应的tripleOptions对象
      const selectedOption = this.tripleOptions[selectedModule]
      // 更新Submodule下拉框的范围
      if (selectedOption){
        // const { start, end } = selectedOption; 
        const start = parseInt(selectedOption.start, 10);  // 强制转换为数字
        const end = parseInt(selectedOption.end, 10);      // 强制转换为数字
        if (start<0){
          this.subsubmoduleRange = 0
          return
        }
        // alert(start+" "+end)
        // 创建submodule的范围，从start到end
        // this.submoduleRange = this.tripleOptions.slice(start, end + 1);
        this.submoduleRange = Array.from({ length: end - start + 1 }, (_, index) => start + index);
        // 清空Submodule和SubSubmodule选择
        this.selectedTriple[1] = ""; // 重置Submodule
        this.selectedTriple[2] = ""; // 重置SubSubmodule
        // alert(this.submoduleRange)

      }
    },

    handleSubmoduleChange(selectedSubmodule) {
      // alert(selectedSubmodule)
      // 根据选中的Submodule，更新SubSubmodule的范围
      const selectedSubmoduleOption = this.tripleOptions[selectedSubmodule]

      if (selectedSubmoduleOption) {
        const start = parseInt(selectedSubmoduleOption.start, 10);  // 强制转换为数字
        const end = parseInt(selectedSubmoduleOption.end, 10);      // 强制转换为数字
        if (start<0){
          this.subsubmoduleRange = 0
          return
        }
        // const { start, end } = selectedSubmoduleOption;

        // 更新SubSubmodule的范围
        // this.subsubmoduleRange = this.tripleOptions.slice(start, end + 1);
        this.subsubmoduleRange = Array.from({ length: end - start + 1 }, (_, index) => start + index);
        // alert(this.subsubmoduleRange)
        // 清空当前SubSubmodule的选择
        this.selectedTriple[2] = ""; 
      }
    },
  },
};
</script>

<style scoped>
.selectbar-wrapper {
  max-width: 1200px;
  margin: 20px auto;
  padding: 20px;
  /* background: #3a5bef; */
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.selectbar-container {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
}

.repo-select {
  width: 780px;
  transition: all 0.3s ease;
  background-color: #f8f9fa;  /* 修改为浅灰色 */
  border: 1px solid #007bff;  /* 修改为蓝色边框 */
  border-radius: 6px;  /* 新增代码：添加圆角 */
}

.repo-select:hover {
  transform: translateY(-2px);
}

.submit-button {
  margin-left: 16px;
  padding: 12px 24px;
  font-weight: 600;
  border-radius: 6px;
  transition: all 0.3s ease;
  background-color: #007bff;  /* 修改为蓝色 */
  border-color: #007bff;
}

.submit-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
  background-color: #0056b3;  /* 修改为更深的蓝色 */
  border-color: #0056b3;
}

.expanded-options {
  display: flex;
  margin-top: 20px;
  margin-left: 125px; /* 确保与第一排左侧对齐 */
}

.triple-select {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  width: 500px;
  background-color: #f8f9fa;  /* 修改为浅灰色 */
  border: 1px solid #007bff;  /* 修改为蓝色边框 */
  border-radius: 6px;  /* 新增代码：添加圆角 */
}

.radio-group {
  margin-bottom: 20px;
  width: 300px;
}

.select-container {
  margin-bottom: 20px;
  width: 300px;
  background-color: #f8f9fa;  /* 修改为浅灰色 */
  border: 1px solid #007bff;  /* 修改为蓝色边框 */
  border-radius: 6px;  /* 新增代码：添加圆角 */
}

/* Element UI 组件样式覆盖 */
:deep(.el-select-dropdown__item) {
  padding: 12px 20px;
}

:deep(.el-select-dropdown__item.selected) {
  background-color: #f0f7ff;
}

:deep(.el-select__input) {
  margin-left: 8px;
}

.mr-2 {
  margin-right: 8px;
}
</style>
