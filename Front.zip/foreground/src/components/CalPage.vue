<template>
  <div>
    <div style="margin-left: 300px">
      <!-- 监听子组件的更新事件，传递 receivedValue 给 SelectBar -->
      <SelectBar
        :options="options"
        :initialSelectedValue="receivedValue"
        @update:showStatus="updateStatusFromChild"
        :key="initialSelectedValue"
        @submit-data="handleSubmitData"
      />
    </div>

    <div style="display: flex">
      <el-menu
        style="
          width: 350px;
          background-color: #f7f7f7;
          margin-left: 110px;
          margin-top: 10px;
        "
        :default-active="activeNav"
        mode="vertical"
        background-color="#f7f7f7"
        text-color="#333"
        active-text-color="#409EFF"
      >
        <el-menu-item @click="scrollToTop" index="top">
          <i class="el-icon-arrow-up"></i> Top
        </el-menu-item>
        <el-menu-item
          v-for="(item, index) in getNavItems()"
          :key="index"
          :index="item.id"
          @click="scrollToSection(item.id)"
        >
          {{ item.name }}
        </el-menu-item>
      </el-menu>

      <el-scrollbar
        style="
          margin-left: 30px;
          max-height: 100vh;
          overflow-y: auto;
          margin-top: 10px;
        "
      >
        <div v-if="status === 4">
          <!-- 概览 -->
          <div id="chartContainer0" class="chartContainer">
            <PieChart :chartData="chartData0" :title="'Overview'" />
          </div>
          <div id="chartContainer1" class="chartContainer">
            <BigCon
              :title="'Commits'"
              :displayContent="displayContent"
              :lineTitle="'Commits'"
              :value="value0"
            />
          </div>
        </div>

        <div v-if="status === 1">
          <!-- 模块 -->
          <div id="chartContainer0" class="chartContainer">
            <BigCon
              :title="'Commits in module'"
              :displayContent="displayContent"
              :lineTitle="'Commits'"
              :value="value1"
            />
          </div>
          <div id="chartContainer1" class="chartContainer">
            <PieChart
              :chartData="chartData1"
              :title="'Commits sorted by company'"
            />
          </div>
          <div id="chartContainer2" class="chartContainer">
            <PieChart
              :chartData="chartData2"
              :title="'Edited lines sorted by company'"
            />
          </div>
        </div>

        <div v-if="status === 2">
          <!-- 公司 -->
          <div id="chartContainer0" class="chartContainer">
            <BigCon
              :title="'Commit intensity'"
              :displayContent="displayContent"
              :lineTitle="'Commit intensity'"
              :value="value3"
            />
          </div>
          <!-- <div id="chartContainer1" class="chartContainer">
            <BigCon
              :title="'Commit extension by time'"
              :displayContent="displayContent"
              :lineTitle="'Commit extension by time'"
              :value="value"
            />
          </div> -->
          <div id="chartContainer2" class="chartContainer">
            <BigCon
              :title="'Commit extension by modules'"
              :displayContent="displayContent"
              :lineTitle="'Commit extension by modules'"
              :value="value4"
            />
          </div>
          <!-- <div id="chartContainer3" class="chartContainer">
            <PieChart
              :chartData="chartData3"
              :title="'Dependency on committers'"
            />
          </div> -->
          <div id="chartContainer4" class="chartContainer">
            <PieChart :chartData="chartData4" :title="'Modules focusing'" />
          </div>

          <div id="chartContainer5" class="chartContainer">
            <div style="margin-top: 20px; margin-left: 10px">Commit types</div>
            <Div10 :values="numbers" />
          </div>
        </div>

        <div v-if="status === 3">
          <div id="chartContainer0" class="chartContainer">
            <BigCon
              :title="'Commits'"
              :displayContent="displayContent"
              :lineTitle="'Commits'"
              :value="value6"
            />
          </div>
          <!-- <div id="chartContainer1" class="chartContainer">
            <PieChart
              :chartData="chartData"
              :title="'Cooperation with other companies'"
            />
          </div> -->
        </div>

        <div v-if="status === 5" style="margin-top: 10px; margin-bottom: 10px">
          <WantMore />
        </div>
      </el-scrollbar>
    </div>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import PieChart from "@/components/PieChart.vue";
import BigCon from "@/components/BigCon.vue";
import SelectBar from "@/components/SelectBar.vue";
import WantMore from "@/components/WantMore.vue";
import Div10 from "./Div10.vue";

export default defineComponent({
  name: "App",
  components: {
    PieChart,
    BigCon,
    SelectBar,
    WantMore,
    Div10,
  },
  props: {
    receivedValue: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      options: [],
      bigConTitle: "BrokenLine Title",
      displayContent: "Information about chart",
      chartTitle: "PieChart Title",
      chartData0: {},
      chartData3: {},
      chartData4: {},
      value0: {},
      value3: {},
      value4: {},
      value5: {},
      value6: {},
      chartData1: {},
      chartData2: {},
      chartData: {
        JavaScript: 50,
        Python: 30,
        Ruby: 20,
        114: 50,
        514: 30,
        1919: 20,
        810: 50,
        1145: 30,
        114514: 20,
        1919810: 20,
        homo: 1145,
        beast: 514,
        tiansuo: 810,
      },
      tripleOptions: [],
      title: "line",
      value1: {},
      value: {
        xAxis: [
          "2024-01-01",
          "2024-01-02",
          "2024-01-03",
          "2024-01-04",
          "2024-01-05",
        ],
        yAxis: [20, 50, 80, 60, 90],
      },
      status: 0,
      activeNav: "top",
      numbers: [12, 34, 56, 78, 90],
    };
  },
  mounted() {
    // 弹出传递的值
    console.log("Received value from parent:", this.receivedValue);

    // 获取数据的逻辑
    fetch("http://localhost:8888/getData/getRepoList")
    //fetch("http://localhost:8888/getData/getRepoList")
      .then((response) => response.json())
      .then((data) => {
        this.options = data.map((item) => ({ label: item, value0: item }));
      })
      .catch((error) => console.error("获取数据失败:", error));
  },
  methods: {
    async handleSubmitData(data) {
      // alert(JSON.stringify(data))
      const selectedValue = data.selectedValue;

      if (data.showStatus === 4) {
        try {
          // 1. 获取总数统计数据并更新 chartData
          const totalCountUrl = `http://localhost:8888/getData/getTotalCount?repo=${selectedValue}`;
          const totalCountResponse = await fetch(totalCountUrl);
          const totalCountText = await totalCountResponse.text(); // 直接获取文本格式
          let totalCountData = {};

          try {
            totalCountData = JSON.parse(totalCountText); // 解析 JSON
          } catch (e) {
            console.error("解析 JSON 失败:", totalCountText);
            alert(`返回的总数数据格式异常:\n${totalCountText}`);
            return;
          }

          this.chartData0 = totalCountData;
          this.chartDataKey++;

          // 2. 获取提交数量数据并更新 value
          const commitCountUrl = `http://localhost:8888/getData/getCommitCount?repo=${selectedValue}`;
          const commitCountResponse = await fetch(commitCountUrl);
          const commitCountText = await commitCountResponse.text();
          let commitCountData = [];

          try {
            commitCountData = JSON.parse(commitCountText);
          } catch (e) {
            console.error("解析 JSON 失败:", commitCountText);
            alert(`返回的提交数数据格式异常:\n${commitCountText}`);
            return;
          }

          // 解析 year 和 count 到 value 的 xAxis 和 yAxis
          this.value0.xAxis = commitCountData.map((item) => item.year);
          this.value0.yAxis = commitCountData.map((item) => item.count);

          // 3. 强制刷新 chartContainer1
          this.chartContainer1Key++;
        } catch (error) {
          console.error("请求失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
      } else if (data.showStatus === 1) {
        if (!isNaN(Number(data.module))) {
          var suburl = data.module;
          suburl = data.tri[Number(data.module)].name;
          var type = 1;

          if (data.submodule !== "" && data.submodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.submodule)].name;
            type = 2;
          }

          if (data.subsubmodule !== "" && data.subsubmodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.subsubmodule)].name;
            type = 3;
          }

          if (data.selectedRadio === "Option 1") {
            type += 3;
          }

          // 对 URL 进行编码处理
          suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
          suburl = encodeURIComponent(suburl);

          // 构造最终的 URL
          var url = `http://localhost:8888/getData/getModule?repo=${data.selectedValue}&prefix=${suburl}&type=${type}`;

          // 用 fetch 获取 URL 的数据
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseText1 = await response.text(); // 获取返回的文本数据
            const responseText = responseText1.slice(
              1,
              responseText1.length - 1
            );
            // 解析返回的字符串数据
            const rawData = {};

            // 按照逗号分割字符串，得到每一对 'key=value'
            const items = responseText.split(",");

            items.forEach((item) => {
              // 按等号分割每个 'key=value' 字符串
              const [key, value] = item.split("=");
              if (key && value) {
                rawData[key.trim()] = parseInt(value.trim(), 10); // 转换 value 为数字
              }
            });

            // 提取 xAxis 和 yAxis
            const xAxis = Object.keys(rawData); // 获取所有的日期（年份-月份）
            const yAxis = Object.values(rawData); // 获取对应的值

            // 格式化 value1
            this.value1 = {
              xAxis: xAxis,
              yAxis: yAxis,
            };
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
          var t = type % 3;
          // 用 fetch 获取 URL 的数据
          url = `http://localhost:8888/getData/getModuleC?repo=${data.selectedValue}&prefix=${suburl}&type=${t}`;
          // alert(url)
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseData = await response.json(); // 将返回的文本数据转换为 JSON
            // alert(responseData)
            // 将返回的数据存入 this.chartData1
            this.chartData1 = responseData;

            // console.log("chartData:", this.chartData); // 打印返回的数据，查看是否正确存入
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
          url = `http://localhost:8888/getData/getModuleCL?repo=${data.selectedValue}&prefix=${suburl}&type=${t}`;
          // alert(url)
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseData = await response.json(); // 将返回的文本数据转换为 JSON
            // alert(responseData)
            // 将返回的数据存入 this.chartData1
            this.chartData2 = responseData;
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
        }
      } else if (data.showStatus === 2) {
        // alert(data.selectedDropdown)
        t = 0;
        if (data.selectedRadio === "Option 1") {
          t = 1;
        }
        url = `http://localhost:8888/getData/getCI?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          // this.value = responseData
          const xAxis = Object.keys(responseData);
          const yAxis = Object.values(responseData);
          this.value3 = { xAxis: xAxis, yAxis: yAxis };
          // 将返回的数据存入 this.chartData1
          // this.chartData2 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getCE?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          // this.value = responseData
          const xAxis = Object.keys(responseData);
          const yAxis = Object.values(responseData);
          this.value4 = { xAxis: xAxis, yAxis: yAxis };
          // 将返回的数据存入 this.chartData1
          // this.chartData2 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getDep?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          this.chartData3 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getMF?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          this.chartData4 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getDiv?repo=${data.selectedValue}&company=${data.selectedDropdown}`;
        // alert(url);

        try {
          // 获取 URL 的数据
          const response = await fetch(url);

          // 获取返回的字符串数据
          const responseData = await response.text(); // 使用 text() 而不是 json()
          // alert(responseData.split("\n")[0])
          // alert(responseData); // 直接显示返回的字符串
          this.numbers = responseData.split("\n").map(Number);
          // this.chartData4 = responseData; // 如果你需要在图表中使用它
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
      } else if (data.showStatus === 3) {
        if (!isNaN(Number(data.module))) {
          suburl = data.module;
          suburl = data.tri[Number(data.module)].name;
          type = 1;

          if (data.submodule !== "" && data.submodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.submodule)].name;
            type = 2;
          }

          if (data.subsubmodule !== "" && data.subsubmodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.subsubmodule)].name;
            type = 3;
          }

          if (data.selectedRadio === "Option 1") {
            type += 3;
          }
          suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
          suburl = encodeURIComponent(suburl);
          url = `http://localhost:8888/getData/getCF?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${type}&prefix=${suburl}`;
          // alert(url)
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseData = await response.json(); // 将返回的文本数据转换为 JSON
            // alert(JSON.stringify(responseData))
            const xAxis = Object.keys(responseData);
            const yAxis = Object.values(responseData);
            this.value6 = { xAxis: xAxis, yAxis: yAxis };
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
        }
      }

      // Emit 更新选中的值
      this.$emit("update-selected-value", selectedValue);
    },

    // 监听子组件的submit-data事件，并弹出接收到的信息
    // handleSubmitData(data) {
    //   alert(JSON.stringify(data))

    //   // alert("接收到子组件的数据: " + JSON.stringify(data));
    // },
    setStatus(value0) {
      this.status = value0;
    },
    scrollToSection(sectionId) {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    },
    scrollToTop() {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    },
    getNavItems() {
      const chartContainers = [];
      if (this.status === 4) {
        chartContainers.push({ id: "chartContainer0", name: "Overview" });
        chartContainers.push({ id: "chartContainer1", name: "Commits" });
      } else if (this.status === 1) {
        chartContainers.push({
          id: "chartContainer0",
          name: "Commits in module",
        });
        chartContainers.push({
          id: "chartContainer1",
          name: "Commits sorted by company",
        });
        chartContainers.push({
          id: "chartContainer2",
          name: "Edited lines sorted by company",
        });
      }
      else if (this.status === 2) {
        chartContainers.push({
          id: "chartContainer0",
          name: "Commits intensity",
        });
        chartContainers.push({
          id: "chartContainer2",
          name: "Commit extension by modules",
        });
        chartContainers.push({
          id: "chartContainer4",
          name: "Modules focusing",
        });
        chartContainers.push({
          id: "chartContainer5",
          name: "Commit types",
        });
      }
      // 更多状态条件...
      return chartContainers;
    },
    updateStatusFromChild(newStatus) {
      this.status = newStatus;
    },
  },
});
</script>

<style scoped>
.chartContainer {
  height: 400px;
  width: 800px;
  background-color: white;
  margin-top: 10px;
  margin-bottom: 10px;
}
.el-menu {
  margin-top: 10px;
  padding: 0;
}
.el-menu-item {
  font-size: 16px;
}
.el-menu-item:hover {
  color: #409eff;
}
.floating-buttons {
  position: fixed;
  top: 50%;
  right: 20px;
  transform: translateY(-50%);
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.floating-btn {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  font-size: 18px;
}
.floating-btn:hover {
  background-color: #4caf50;
}
</style>
