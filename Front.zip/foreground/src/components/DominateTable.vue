<template>
  <div>
    <!-- 表格容器，添加垂直滚动条 -->
    <div class="table-container">
      <table class="table">
        <thead>
          <tr>
            <th @click="sortColumn('column1')" class="sortable-header">
              Module
              <span v-if="sortedColumn === 'column1'">
                <span v-if="sortDirection.column1 === 'asc'">▲</span>
                <span v-if="sortDirection.column1 === 'desc'">▼</span>
              </span>
            </th>
            <th @click="sortColumn('column2')" class="sortable-header">
              The most dominant company
              <span v-if="sortedColumn === 'column2'">
                <span v-if="sortDirection.column2 === 'asc'">▲</span>
                <span v-if="sortDirection.column2 === 'desc'">▼</span>
              </span>
            </th>
            <th @click="sortColumn('column3')" class="sortable-header">
              The second most dominant company
              <span v-if="sortedColumn === 'column3'">
                <span v-if="sortDirection.column3 === 'asc'">▲</span>
                <span v-if="sortDirection.column3 === 'desc'">▼</span>
              </span>
            </th>
            <th @click="sortColumn('column4')" class="sortable-header">
              The third most dominant company
              <span v-if="sortedColumn === 'column4'">
                <span v-if="sortDirection.column4 === 'asc'">▲</span>
                <span v-if="sortDirection.column4 === 'desc'">▼</span>
              </span>
            </th>
          </tr>
        </thead>
        <tbody>
          <!-- 根据排序后的数据生成表格内容 -->
          <tr v-for="(row, index) in sortedData" :key="index">
            <td>{{ row.column1 }}</td>
            <td :style="getColorStyle(row.column2)">{{ row.column2 }}</td>
            <td :style="getColorStyle(row.column3)">{{ row.column3 }}</td>
            <td :style="getColorStyle(row.column4)">{{ row.column4 }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  name: "RiskTable",
  props: {
    // 从父组件接收的原始数据
    tableData: {
      type: Array,
      required: true,
    }
  },
  data() {
    return {
      // 默认的排序方式，升序
      sortDirection: {
        column1: 'asc',
        column2: 'asc',
        column3: 'asc',
        column4: 'asc', // 新增第四列的排序方向
      },
      // 当前排序的列
      sortedColumn: null,
    };
  },
  computed: {
    // 根据排序字段和方向返回排序后的数据
    sortedData() {
      return [...this.tableData].sort((a, b) => {
        const column = this.sortedColumn;
        const direction = this.sortDirection[column];
        const comparison = direction === 'asc' ? 1 : -1;

        // 如果是第一列，按字典序排序
        if (column === 'column1') {
          return a[column].localeCompare(b[column]) * comparison;
        }

        // 否则，按数字排序
        const aValue = this.extractNumber(a[column]);
        const bValue = this.extractNumber(b[column]);

        // 如果数据不包含 "-" 符号，则把这些数据排到最后
        const aHasDash = a[column] && a[column].includes('-');
        const bHasDash = b[column] && b[column].includes('-');

        // 如果一个包含 "-" 且另一个不包含，则包含 "-" 的排在前面
        if (!aHasDash && bHasDash) return comparison;
        if (aHasDash && !bHasDash) return -comparison;

        // 处理后两列的排序逻辑
        const isAEmpty = !a[column] || a[column] === '';
        const isBEmpty = !b[column] || b[column] === '';

        // 如果 a 是空的，b 不是空的，a 排到后面
        if (isAEmpty && !isBEmpty) return 1;
        // 如果 b 是空的，a 不是空的，b 排到后面
        if (!isAEmpty && isBEmpty) return -1;

        // 否则，按数字排序
        if (aValue < bValue) return -comparison;
        if (aValue > bValue) return comparison;
        return 0;
      });
    }
  },
  methods: {
    // 处理点击排序列头，切换排序方向
    sortColumn(column) {
      // 如果点击了当前排序列，则切换排序方向
      if (this.sortedColumn === column) {
        this.sortDirection[column] = this.sortDirection[column] === 'asc' ? 'desc' : 'asc';
      } else {
        // 如果点击了其他列，则设置该列为升序，其他列不显示箭头
        this.sortDirection[column] = 'asc';
        this.sortedColumn = column;
      }
    },

    // 提取字符串中"-"后方的数字部分
    extractNumber(value) {
      // 确保 value 是字符串类型，并且不为 null 或 undefined
      if (typeof value !== 'string') {
        return 0; // 如果不是字符串，直接返回 0
      }

      const match = value.match(/-(\d+(\.\d+)?)/); // 匹配"-"后面的数字部分
      return match ? parseFloat(match[1]) : 0; // 如果匹配到数字，返回其数值；否则返回0
    },

    // 计算颜色值，从红色到绿色
    getColorStyle(value) {
      const numericValue = this.extractNumber(value)/100;
      // alert(numericValue);
      const red = Math.round((1 - numericValue) * 255); // 红色分量，值越大越红
      const green = Math.round(numericValue * 255); // 绿色分量，值越大越绿
      return {
        color: `rgb(${green}, ${red}, 0)`, // 动态设置文本颜色
      };
    }
  }
};
</script>

<style scoped>
.table-container {
  max-height: 450px;
  overflow-y: auto; /* 添加垂直滚动条 */
  border: 2px solid #000; /* 外层容器的边框 */
}

.table {
  width: 100%;
  border-collapse: separate; /* 分离表格边框 */
  border-spacing: 0; /* 去掉单元格间的间隙 */
}

th, td {
  padding: 8px;
  border: 1px solid #000; /* 内部单元格的边框 */
  text-align: left;
}

th {
  cursor: pointer;
  background-color: aqua;
  z-index: 1; /* 确保表头在滚动内容上方 */
  position: sticky;
  top: 0;
  background-color: #f4f4f4;
  border-top: 2px solid #000; /* 表头的上边框 */
  border-left: 2px solid #000; /* 表头的左边框 */
}

th:hover {
  background-color: #e0e0e0;
}

th.sortable-header {
  z-index: 2; /* 确保表头在内容上方 */
}

span {
  font-size: 14px;
  margin-left: 5px;
  color: aqua;
}

span[style] {
  font-size: 18px;
}
</style>
