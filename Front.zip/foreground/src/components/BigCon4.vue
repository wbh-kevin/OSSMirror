<template>
  <div class="big-con-container" style="width: 760px; height: 360px">
    <!-- 顶部控制栏 -->
    <el-row type="flex" justify="space-between" align="middle" style="margin-bottom: 20px">
      <el-col :span="10">
        <h3 style="text-align: left;">{{ title }}</h3>
      </el-col>

      <el-col :span="4" style="text-align: center;">
        <el-switch
          v-model="switchValue"
          active-text="Month"
          inactive-text="Year"
          active-color="#13ce66"
          inactive-color="#ff4949"
          @change="handleSwitchChange"
        />
      </el-col>

      <el-col :span="10" style="text-align: right">
        <el-button @click="toggle" type="primary">{{ buttonText }}</el-button>
      </el-col>
    </el-row>

    <!-- 内容区域 -->
    <div class="content-box">
      <div v-if="isTextBoxVisible">
        <div class="text-display-box">
          <p>{{ displayContent }}</p>
        </div>
      </div>

      <div v-else>
        <div id="chartContainer" class="el-margin-top-md">
          <BigLine4 :key="chartDataKey" :title="lineTitle" :value="yearData" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import BigLine4 from "./BigLine4.vue";

export default {
  components: { BigLine4 },
  props: {
    title: String,
    displayContent: String,
    lineTitle: String,
    yearData: {
      type: Object,
    },
  },
  data() {
    return {
      isTextBoxVisible: false,
      switchValue: false, // false = "Year", true = "Month"
    };
  },
  computed: {
    buttonText() {
      return this.isTextBoxVisible ? "Back to graph" : "How does it work";
    },
    chartDataKey() {
      return this.switchValue ? "month" : "year";
    },
  },
  methods: {
    toggle() {
      this.isTextBoxVisible = !this.isTextBoxVisible;
    },
    handleSwitchChange(value) {
      // 发出事件给父组件，携带切换后的值
      const selectedValue = value ? 'Month' : 'Year';
      this.$emit('switch-changed', selectedValue);  // 自定义事件 `switch-changed`
    },
  },
};
</script>

<style scoped>
.big-con-container {
  padding: 20px;
  background-color: white;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.el-row {
  margin-bottom: 10px;
}

.el-col {
  padding: 0 10px;
}

h3 {
  margin: 0;
}

.content-box {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
}

.text-display-box {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 200px;
  font-size: 18px;
  text-align: center;
  padding: 20px;
  background-color: white;
  border: none;
}
</style>
