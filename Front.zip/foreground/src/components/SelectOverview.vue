<template>
  <div class="select-overview">
    <div class="selectbar-container">
      <!-- 左侧下拉框 -->
      <el-select v-model="selectedValue" placeholder="Select or input github repo" class="repo-select" filterable
        allow-create :options="options" clearable>
        <template #prefix>
          <i class="el-icon-search"></i>
        </template>
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value" />
      </el-select>

      <!-- 右侧按钮 -->
      <el-button type="primary" class="submit-button" @click="handleButtonClick" :loading="loading">
        <i class="el-icon-upload2 mr-2"></i>
        SUBMIT
      </el-button>
    </div>

    <!-- 加载动画 -->
    <el-loading v-if="loading" :fullscreen="true"></el-loading>
  </div>
</template>

<script>
export default {
  name: "SelectBar",
  props: {
    options: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      selectedValue: "", // 用来存储左侧下拉框选中的值
      loading: false, // 控制加载动画的显示
      selectedDropdownOptions: [], // 下拉框选项
      showStatus: 0, // 用于控制状态
      next: false,
      urlP: `http://30901d0b.r40.cpolar.top/getData/`,
    };
  },
  methods: {
    // 点击按钮事件函数
    async handleButtonClick() {
      if (!this.selectedValue) {
        alert("Please select a repository!");
        return;
      }
      this.loading = true; // 显示加载动画
      this.showStatus = 1; // 选择后更新 showStatus

      const url = this.urlP + `getCompanyList?repo=${this.selectedValue}`;
      // alert(url)
      try {
        this.next = false;
        const response = await fetch(url);
        const data = await response.json();

        this.selectedDropdownOptions = data.map((item) => ({
          label: item, // 使用 item 作为 label
          value: item, // 使用 item 作为 value
        }));
      } catch (error) {
        // console.error("请求失败:", error);
        // alert("Failed to fetch data. Please try again.");

        // 新增代码：将 selectedValue 进行 URL 编码并发送至新的 URL
        const encodedValue = encodeURIComponent(this.selectedValue);
        const fallbackUrl = this.urlP + `getData/calRepo?repo=${encodedValue}`;
        // alert(fallbackUrl)
        const res = await fetch(fallbackUrl); // 发送请求
        const resText = await res.text(); // 解析响应为文本
        if (resText == "fail") {
          alert("Failed to fetch data. Please try again. SO");
          this.loading = false; // 隐藏加载动画
          this.showStatus = 2; // 加载完成后更新状态
          this.next = true;
          return;
        } else {
          // 使用 el-message 组件替代 alert
          this.$message({
            message: "Successfully confirmed the repository! Please wait for calculating and view this page after few hours.",
            type: "success",
            duration: 5000, // 持续时间为3秒
            center: true, // 在网页中心显示
            offset: 125 // 新增代码：设置偏移量为0以确保在正中央显示
          });
          this.next = true;
          this.loading = false; // 隐藏加载动画
          this.showStatus = 2; // 加载完成后更新状态
          return;
        }
      } finally {
        if (this.next === false) {
          this.loading = false; // 隐藏加载动画
          this.showStatus = 2; // 加载完成后更新状态
          this.$nextTick(() => {
            this.$emit("update:showStatus", this.showStatus); // 通知父组件更新状态
            this.$emit("selected-value", this.selectedValue); // 发送选中的值给父组件
          });
        }
      }
    },
  },
};
</script>

<style scoped>
.select-overview {
  max-width: 1200px;
  margin: 20px auto;
  padding: 20px;
}

.selectbar-container {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  /* background: #3a5bef; */
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.repo-select {
  width: 780px;
  transition: all 0.3s ease;
  background-color: #f8f9fa;
  /* 修改为浅灰色 */
  border: 1px solid #007bff;
  /* 修改为蓝色边框 */
  border-radius: 6px;
  /* 新增代码：添加圆角 */
}

.repo-select:hover {
  transform: translateY(-2px);
}

.submit-button {
  margin-left: 16px;
  padding: 12px 24px;
  font-weight: 600;
  border-radius: 6px;
  transition: all 0.3s ease;
  background-color: #007bff;
  /* 修改为蓝色 */
  border-color: #007bff;
}

.submit-button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
  background-color: #0056b3;
  /* 修改为更深的蓝色 */
  border-color: #0056b3;
}

/* Element UI 组件样式覆盖 */
:deep(.el-select-dropdown__item) {
  padding: 12px 20px;
}

:deep(.el-select-dropdown__item.selected) {
  background-color: #f0f7ff;
}

:deep(.el-select__input) {
  margin-left: 8px;
}

.mr-2 {
  margin-right: 8px;
}
</style>
