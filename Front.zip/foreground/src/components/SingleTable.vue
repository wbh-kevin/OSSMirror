<template>
    <div>
      <!-- 表格容器，添加垂直滚动条 -->
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th @click="sortColumn('column1')" class="sortable-header">
                Company
                <span v-if="sortedColumn === 'column1'">
                  <span v-if="sortDirection.column1 === 'asc'">▲</span>
                  <span v-if="sortDirection.column1 === 'desc'">▼</span>
                </span>
              </th>
              <th @click="sortColumn('column2')" class="sortable-header">
                {{ column2Header }}
                <span v-if="sortedColumn === 'column2'">
                  <span v-if="sortDirection.column2 === 'asc'">▲</span>
                  <span v-if="sortDirection.column2 === 'desc'">▼</span>
                </span>
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(row, index) in sortedData" :key="index">
              <td>{{ row.column1 }}</td>
              <td :style="getColorStyle(row.column2)">{{ formatColumn2(row.column2) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: "RiskTable",
    props: {
      // 从父组件接收的原始数据
      tableData: {
        type: Array,
        required: true,
      },
      // 新增：接收列标题
      column2Header: {
        type: String,
        default: 'column2', // 默认值为 'column2'
      },
    },
    data() {
      return {
        // 默认的排序方式，升序
        sortDirection: {
          column1: 'asc',
          column2: 'asc',
        },
        // 当前排序的列
        sortedColumn: null,
      };
    },
    computed: {
      // 仅在数据或排序条件发生变化时才进行排序
      sortedData() {
        const column = this.sortedColumn;
        if (!column) return this.tableData; // 没有选择排序列时直接返回原始数据
        const direction = this.sortDirection[column];
        const comparison = direction === 'asc' ? 1 : -1;
  
        return [...this.tableData].sort((a, b) => {
          if (a[column] < b[column]) return -comparison;
          if (a[column] > b[column]) return comparison;
          return 0;
        });
      },
    },
    methods: {
      // 处理点击排序列头，切换排序方向
      sortColumn(column) {
        // 如果点击了当前排序列，则切换排序方向
        if (this.sortedColumn === column) {
          this.sortDirection[column] = this.sortDirection[column] === 'asc' ? 'desc' : 'asc';
        } else {
          // 如果点击了其他列，则设置该列为升序，其他列不显示箭头
          this.sortDirection[column] = 'asc';
          this.sortedColumn = column;
        }
      },
      // 计算颜色值，从绿色到红色
      getColorStyle(value) {
        // 将 0 到 1 的值映射到绿色到红色之间的渐变色
        const red = Math.round(value * 255); // 红色分量，值越大越红
        const green = 255 - red; // 绿色分量，值越大越绿
        return {
          color: `rgb(${red}, ${green}, 0)`, // 动态设置文本颜色
        };
      },
      // 新增：格式化 column2 的值
      formatColumn2(value) {
        return value.toString().includes('.') && value.toString().split('.')[1].length > 2 
          ? value.toFixed(2) // 如果小数位数大于2位，则四舍五入保留两位
          : value; // 否则返回原值
      },
    },
    watch: {
      tableData: {
        handler() {
          this.sortedColumn = null; // 重置排序列
          this.sortDirection = { // 重置排序方向
            column1: 'asc',
            column2: 'asc',
          };
        },
        immediate: true, // 立即执行一次
      },
    },
  };
  </script>
  
  <style scoped>
  .table-container {
    max-height: 450px;
    overflow-y: auto; /* 添加垂直滚动条 */
    border: 2px solid #000; /* 外层容器的边框 */
  }
  
  .table {
    width: 100%;
    border-collapse: separate; /* 分离表格边框 */
    border-spacing: 0; /* 去掉单元格间的间隙 */
  }
  
  th, td {
    padding: 8px;
    border: 1px solid #000; /* 内部单元格的边框 */
    text-align: left;
    width: 50%; /* 设置每列宽度为50% */
  }
  
  th {
    cursor: pointer;
    background-color: aqua;
    z-index: 1; /* 确保表头在滚动内容上方 */
    position: sticky;
    top: 0;
    background-color: #f4f4f4;
    border-top: 2px solid #000; /* 表头的上边框 */
    border-left: 2px solid #000; /* 表头的左边框 */
  }
  
  th:hover {
    background-color: #e0e0e0;
  }
  
  th.sortable-header {
    z-index: 2; /* 确保表头在内容上方 */
  }
  
  span {
    font-size: 14px;
    margin-left: 5px;
    color: aqua;
  }
  
  span[style] {
    font-size: 18px;
  }
  </style>
  