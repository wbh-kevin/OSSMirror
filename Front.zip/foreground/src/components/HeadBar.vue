<template>
  <div class="headbar-container" style="display:flex; padding: 10px; background-color: #409eff">
    <!-- Element Plus 的菜单组件，使用横向排列 -->
    <div style="width:100px; height: 100%; margin-left: 100px; background-color: #409eff;">
      <!-- LOGO -->
    </div>
    <el-menu mode="horizontal" class="headbar-menu" :default-active="activeIndex" style="margin-right: 50px; background-color: #409eff; margin-left: 100px; width: 100%;">
      <!-- 左侧对齐的菜单项 -->
      <el-menu-item index="1" @click="handleMenuClick('Overview')">Overview</el-menu-item>
      <el-menu-item index="2" @click="handleMenuClick('Analysis')">Contribution Model</el-menu-item>
      <el-menu-item index="3" @click="handleMenuClick('Risk')">Risk</el-menu-item>
      <el-menu-item index="4" @click="handleMenuClick('About')">About</el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  name: 'HeadBar',
  data() {
    return {
      // 当前激活的菜单项，默认为第一个菜单项（Overview）
      activeIndex: '1',
    };
  },
  methods: {
    // 处理点击菜单项的通用事件
    handleMenuClick(menuName) {
      // 使用 $emit 将菜单项名称传递给父组件
      this.$emit('menu-clicked', menuName);
    },
  },
};
</script>

<style scoped>
.headbar-container {
  background-color: #409eff; /* 更新背景色为 #409eff */
  padding: 10px 20px;
}

.headbar-menu {
  display: flex;
  justify-content: space-around; /* 更新为均匀分布 */
  align-items: center; /* 垂直居中 */
  width: 100%; /* 确保菜单项横向铺满 */
}

.el-menu-item {
  font-size: 18px; /* 更新字体大小 */
  font-weight: 600; /* 更新字体粗细 */
  color: white; /* 更新字体颜色为白色，以便与背景色对比 */
}

.el-menu-item:hover {
  background-color: #80deea; /* 更新悬停背景色 */
  cursor: pointer;
}
.el-menu-item.is-active {
  /* background-color: gray !important; 选中后背景变灰色 */
  background-color: #409eff !important;
  color: #91EAE4 !important; /* 文字颜色保持白色 */
}

/* 中间空白部分占据剩余空间，确保左右对齐 */
.spacer {
  flex-grow: 1; /* 使中间部分自动扩展，撑开两端 */
}
</style>
