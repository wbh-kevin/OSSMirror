<template>
  <div ref="lineChart" style="width: 700px; height: 300px;"></div>
</template>

<script>
// 导入 ECharts
import { onMounted, ref, watch } from 'vue';
import * as echarts from 'echarts';

export default {
  name: 'BigLine',
  props: {
    title: {
      type: String,
      required: true
    },
    value: {
      type: Object,
      required: true,
      validator(value) {
        // 确保传递的 value 对象包含 xAxis 和 yAxis
        return Array.isArray(value.xAxis) && Array.isArray(value.yAxis);
      }
    }
  },
  setup(props) {
    const lineChart = ref(null);  // 用来绑定 ECharts 图表的 DOM
    const chartInstance = ref(null); // 存储已初始化的 ECharts 实例

    // 渲染图表的方法
    const renderChart = () => {
      if (lineChart.value) {
        // 初始化 ECharts 实例
        chartInstance.value = echarts.init(lineChart.value);

        // 配置折线图的选项
        const option = {
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          grid: {
            top: 40,      // 由于移除了标题，可以减少顶部边距
            bottom: 30,
            left: 40,
            right: 20,
            containLabel: true
          },
          legend: {
            top: 10,      // 由于移除了标题，图例可以往上移
            left: 'center',
            textStyle: {
              fontSize: 12,
              color: '#666'
            }
          },
          xAxis: {
            type: 'category',
            data: props.value.xAxis,  // 横坐标数据
            boundaryGap: false,  // 不留白
          },
          yAxis: {
            type: 'value',  // 纵坐标为数值型
          },
          series: [{
            name: props.title,  // 设置折线的名称为父组件传递的 title
            type: 'line',
            smooth: false,  // 平滑曲线
            data: props.value.yAxis,  // 纵坐标数据
            symbol: 'circle',
            symbolSize: 4,         // 将圆圈尺寸从 8 减小到 4
            lineStyle: {
              width: 1            // 添加线条宽度设置，默认是 2
            },
            showSymbol: true,
            showAllSymbol: true,
            itemStyle: {
              color: '#3398DB'  // 设置折线的颜色
            }
          }]
        };

        // 使用配置项渲染图表
        chartInstance.value.setOption(option);

        // 监听窗口大小变化，图表自适应
        window.addEventListener('resize', () => {
          chartInstance.value.resize();
        });
      }
    };

    // 在组件挂载后初始化图表
    onMounted(() => {
      renderChart();
    });

    // 监听 props 的变化，重新渲染图表
    watch(
      () => props.value,
      () => {
        renderChart();
      },
      { deep: true }
    );

    return {
      lineChart
    };
  }
};
</script>

<style scoped>
/* 这里可以添加样式 */
</style>
