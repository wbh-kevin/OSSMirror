<template>
    <footer class="footer-bar">
      <div class="footer-content">
        <p>© 2025 Beijing Institute of Technology. All rights reserved.</p>
        <nav>
          <ul>
            <li><a href="https://yuxiazhang-bit.github.io/team.html">About us</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact us</a></li>
          </ul>
        </nav>
      </div>
    </footer>
  </template>
  
  <script>
  export default {
    name: "FooterBar",
  };
  </script>
  
  <style scoped>
  .footer-bar {
    background-color: #2c3e50;
    color: white;
    padding: 10px 0;
    text-align: center;
  }
  
  .footer-content {
    max-width: 1200px;
    margin: 0 auto;
  }
  
  .footer-content nav ul {
    list-style: none;
    padding: 0;
  }
  
  .footer-content nav ul li {
    display: inline;
    margin: 0 15px;
  }
  
  .footer-content nav ul li a {
    color: white;
    text-decoration: none;
  }
  
  .footer-content nav ul li a:hover {
    text-decoration: underline;
  }
  </style>