<template>
  <div class="calpage-container">
    <div class="selector-wrapper">
      <SelectBar :options="options" :initialSelectedValue="receivedValue" @update:showStatus="updateStatusFromChild"
        :key="initialSelectedValue" @submit-data="handleSubmitData" />
    </div>

    <div class="main-content" v-if="status !== 0" style="margin-left: -200px;">
      <el-menu class="side-navigation" :default-active="activeNav" mode="vertical" background-color="#f7f7f7"
        text-color="#333" active-text-color="#409EFF">
        <el-menu-item @click="scrollToTop" index="top">
          <i class="el-icon-arrow-up"></i> {{ status === 4 ? 'General view' :
            status === 1 ? 'View of module' : status === 2 ? 'View of company' :
              status === 3 ? 'View of company and module' : 'Top' }}
        </el-menu-item>
        <el-menu-item v-for="(item, index) in getNavItems()" :key="index" :index="item.id"
          @click="scrollToSection(item.id)" style="margin-left: 40px;">
          <p style="max-width: 200px; word-wrap: break-word; overflow-wrap: break-word; white-space: normal; line-height: 1.2;">
            {{ item.name }}
          </p>

        </el-menu-item>
      </el-menu>

      <el-scrollbar class="chart-scrollbar">
        <div v-if="status === 4" class="charts-container">
          <div id="chartContainer0" class="chart-wrapper">
            <PieChart :chartData="chartData0" :title="'Overview'"
              hiddenText="This chart shows how much commit made by each company and public volunteers." />
          </div>
          <div id="chartContainer1" class="chart-wrapper">
            <BigCon :title="'Commits'"
              :displayContent="'This chart shows the total number of commits in the selected repo by year.'"
              :lineTitle="'Commits'" :value="value0" @switch-changed="handleSwitchChanged1" />
          </div>
        </div>

        <div v-if="status === 1" class="charts-container">
          <!-- 模块 -->
          <div id="chartContainer0" class="chart-wrapper">
            <BigCon :title="'Module Commit Frequency Over Time'"
              :displayContent="'This chart displays the trend of repository commits over time by showing the total number of commits within each time period. The time scale can be switched between year and month using the buttons at the top.'"
              :lineTitle="'Commits'" :value="value1" @switch-changed="handleSwitchChanged2" />
          </div>
          <div id="chartContainer1" class="chart-wrapper">
            <PieChart :chartData="chartData1" :title="'Commit Contributions by Company'"
              hidden-text="This chart illustrates the proportion of commits made by different companies within the selected module of the repository, based on the account ownership information." />
          </div>
          <div id="chartContainer2" class="chart-wrapper">
            <PieChart :chartData="chartData2" :title="'Edited Code Distribution by Company'"
              hidden-text="This chart shows the proportion of modified lines contributed by different companies within the selected module of the repository, based on the account ownership information." />
          </div>
        </div>

        <div v-if="status === 2" class="charts-container">
          <!-- 公司 -->
          <div id="chartContainer0" class="chart-wrapper">
            <BigCon :title="'Commit intensity'" 
              :displayContent="'This chart shows how the number of company contributions to the repository has changed over time'" :lineTitle="'Commit intensity'"
              :value="value3" @switch-changed="handleSwitchChanged3" />
          </div>
          <!-- <div id="chartContainer1" class="chartContainer">
            <BigCon
              :title="'Commit extension by time'"
              :displayContent="displayContent"
              :lineTitle="'Commit extension by time'"
              :value="value"
            />
          </div> -->
          <div id="chartContainer2" class="chart-wrapper">
            <BigCon :title="'Commit extension'" 
              :displayContent="'This chart shows how the number of modules the company contributed to the repository changed over time'"
              :lineTitle="'Commit extension'" :value="value4" @switch-changed="handleSwitchChanged4" />
          </div>
          <!-- <div id="chartContainer3" class="chartContainer">
            <PieChart
              :chartData="chartData3"
              :title="'Dependency on committers'"
            />
          </div> -->
          <div id="chartContainer4" class="chart-wrapper">
            <PieChart :chartData="chartData4" :title="'Focused modules'" 
            hidden-text="This chart shows the percentage of contribution effort that the company allocates to different modules in the repository" />
          </div>

          <div id="chartContainer5" class="chart-wrapper">
            <!-- <div style="text-align: center; margin-top: 20px;">Commit types</div> -->
            <Div10 :values="numbers" />
          </div>
        </div>

        <div v-if="status === 3" class="charts-container">
          <div id="chartContainer0" class="chart-wrapper">
            <BigCon :title="'Commits'" :lineTitle="'Commits'" :value="value6"
              :displayContent="'This chart shows how the number of modules the company contributed to the specific module in repository changed over time'"
              @switch-changed="handleSwitchChanged6" />
          </div>
          <!-- <div id="chartContainer1" class="chartContainer">
            <PieChart
              :chartData="chartData"
              :title="'Cooperation with other companies'"
            />
          </div> -->
        </div>

        <div v-if="status === 5" style="margin-top: 10px; margin-bottom: 10px">
          <WantMore />
        </div>
      </el-scrollbar>
    </div>
    <button class="scroll-to-top" v-if="isVisible" @click="scrollToTop">Top</button>
  </div>
</template>

<script>
import { defineComponent } from "vue";
import PieChart from "@/components/PieChart.vue";
import BigCon from "@/components/BigCon.vue";
import SelectBar from "@/components/SelectBar.vue";
import WantMore from "@/components/WantMore.vue";
import Div10 from "./Div10.vue";

export default defineComponent({
  name: "App",
  components: {
    PieChart,
    BigCon,
    SelectBar,
    WantMore,
    Div10,
  },
  props: {
    receivedValue: {
      type: String,
      required: true,
    },
  },
  data() {
    return {
      options: [],
      selectedValue: "",
      bigConTitle: "BrokenLine Title",
      displayContent: "Information about chart",
      chartTitle: "PieChart Title",
      module: "",
      submodule: "",
      subsubmodule: "",
      selectedDropdown: "",
      chartData0: {},
      chartData3: {},
      chartData4: {},
      value0: {},
      value3: {},
      value4: {},
      value5: {},
      value6: {},
      chartData1: {},
      chartData2: {},
      chartData: {
        JavaScript: 50,
        Python: 30,
        Ruby: 20,
        114: 50,
        514: 30,
        1919: 20,
        810: 50,
        1145: 30,
        114514: 20,
        1919810: 20,
        homo: 1145,
        beast: 514,
        tiansuo: 810,
      },
      tripleOptions: [],
      title: "line",
      value1: {},
      value: {
        xAxis: [
          "2024-01-01",
          "2024-01-02",
          "2024-01-03",
          "2024-01-04",
          "2024-01-05",
        ],
        yAxis: [20, 50, 80, 60, 90],
      },
      status: 0,
      activeNav: "top",
      numbers: [12, 34, 56, 78, 90],
      isVisible: false,
    };
  },
  mounted() {
    // 弹出传递的值
    console.log("Received value from parent:", this.receivedValue);

    // 获取数据的逻辑
    fetch("http://localhost:8888/getData/getRepoList")
      .then((response) => response.json())
      .then((data) => {
        this.options = data.map((item) => ({ label: item, value0: item }));
      })
      .catch((error) => console.error("获取数据失败:", error));

    window.addEventListener('scroll', this.handleScroll);
  },
  beforeUnmount() {
    window.removeEventListener('scroll', this.handleScroll);
  },
  methods: {
    async handleSwitchChanged1(newValue) {
      const tail = newValue === "Month" ? 1 : 0;
      // alert(tail)
      try {
        // 2. 获取提交数量数据并更新 value
        const commitCountUrl = `http://localhost:8888/getData/getCommitCount?repo=${this.selectedValue}&time=${tail}`;
        // alert(commitCountUrl)
        const commitCountResponse = await fetch(commitCountUrl);
        const commitCountText = await commitCountResponse.text();
        let commitCountData = [];

        try {
          commitCountData = JSON.parse(commitCountText);
        } catch (e) {
          console.error("解析 JSON 失败:", commitCountText);
          alert(`返回的提交数数据格式异常:\n${commitCountText}`);
          return;
        }
        this.value0.xAxis = commitCountData.map((item) => item.time);
        this.value0.yAxis = commitCountData.map((item) => item.count);
      } catch (error) {
        console.error("请求失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
    },
    async handleSwitchChanged2(newValue) {

      var suburl = this.module;
      var type = 1;

      if (this.submodule !== "" && this.submodule !== "view_all") {
        suburl = suburl + "/" + this.submodule;
        type = 2;
      }

      if (this.subsubmodule !== "" && this.subsubmodule !== "view_all") {
        suburl = suburl + "/" + this.subsubmodule;
        type = 3;
      }

      // 对 URL 进行编码处理
      suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
      suburl = encodeURIComponent(suburl);
      if (newValue !== "Month") {
        type += 3;
      }
      // 构造最终的 URL
      var url = `http://localhost:8888/getData/getModule?repo=${this.selectedValue}&prefix=${suburl}&type=${type}`;
      // alert(url)
      // 用 fetch 获取 URL 的数据
      try {
        // 获取 URL 的数据
        const response = await fetch(url);
        const responseText1 = await response.text(); // 获取返回的文本数据
        const responseText = responseText1.slice(
          1,
          responseText1.length - 1
        );
        // 解析返回的字符串数据
        const rawData = {};

        // 按照逗号分割字符串，得到每一对 'key=value'
        const items = responseText.split(",");

        items.forEach((item) => {
          // 按等号分割每个 'key=value' 字符串
          const [key, value] = item.split("=");
          if (key && value) {
            rawData[key.trim()] = parseInt(value.trim(), 10); // 转换 value 为数字
          }
        });

        // 提取 xAxis 和 yAxis
        const xAxis = Object.keys(rawData); // 获取所有的日期（年份-月份）
        const yAxis = Object.values(rawData); // 获取对应的值
        // 格式化 value1
        this.value1 = {
          xAxis: xAxis,
          yAxis: yAxis,
        };
      } catch (error) {
        console.error("获取数据失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
    },
    async handleSwitchChanged3(newValue) {
      var t = 0;
      if (newValue !== "Month") {
        t = 1;
      }
      var url = `http://localhost:8888/getData/getCI?repo=${this.selectedValue}&company=${this.selectedDropdown}&type=${t}`;
      // alert(url);
      try {
        // 获取 URL 的数据
        const response = await fetch(url);
        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
        // alert(JSON.stringify(responseData))
        // this.value = responseData
        const xAxis = Object.keys(responseData);
        const yAxis = Object.values(responseData);
        this.value3 = { xAxis: xAxis, yAxis: yAxis };
        // 将返回的数据存入 this.chartData1
        // this.chartData2 = responseData;
      } catch (error) {
        console.error("获取数据失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
    },
    async handleSwitchChanged4(newValue) {
      var t = 0;
      if (newValue !== "Month") {
        t = 1;
      }
      var url = `http://localhost:8888/getData/getCE?repo=${this.selectedValue}&company=${this.selectedDropdown}&type=${t}`;
      // alert(url);
      try {
        // 获取 URL 的数据
        const response = await fetch(url);
        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
        // alert(JSON.stringify(responseData))
        // this.value = responseData
        const xAxis = Object.keys(responseData);
        const yAxis = Object.values(responseData);
        this.value4 = { xAxis: xAxis, yAxis: yAxis };
        // 将返回的数据存入 this.chartData1
        // this.chartData2 = responseData;
      } catch (error) {
        console.error("获取数据失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
    },
    async handleSwitchChanged6(newValue) {
      // alert(newValue)

      var suburl = this.module;
      var type = 1;

      if (this.submodule !== "" && this.submodule !== "view_all") {
        suburl = suburl + "/" + this.submodule;
        type = 2;
      }

      if (this.subsubmodule !== "" && this.subsubmodule !== "view_all") {
        suburl = suburl + "/" + this.subsubmodule;
        type = 3;
      }
      if (newValue !== "Month") {
        type += 3;
      }
      // alert(suburl)
      // 对 URL 进行编码处理
      suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
      suburl = encodeURIComponent(suburl);
      var url = `http://localhost:8888/getData/getCF?repo=${this.selectedValue}&company=${this.selectedDropdown}&type=${type}&prefix=${suburl}`;
      // alert(url);
      try {
        // 获取 URL 的数据
        const response = await fetch(url);
        const responseData = await response.json(); // 将返回的文本数据转换为 JSON
        // alert(JSON.stringify(responseData))
        // this.value = responseData
        const xAxis = Object.keys(responseData);
        const yAxis = Object.values(responseData);
        this.value6 = { xAxis: xAxis, yAxis: yAxis };
        // 将返回的数据存入 this.chartData1
        // this.chartData2 = responseData;
      } catch (error) {
        console.error("获取数据失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
    },
    async handleSubmitData(data) {
      // alert(JSON.stringify(data))
      const selectedValue = data.selectedValue;
      this.selectedValue = selectedValue;
      if (data.showStatus === 4) {
        try {
          // 1. 获取总数统计数据并更新 chartData
          const totalCountUrl = `http://localhost:8888/getData/getTotalCount?repo=${selectedValue}`;
          const totalCountResponse = await fetch(totalCountUrl);
          const totalCountText = await totalCountResponse.text(); // 直接获取文本格式
          let totalCountData = {};

          try {
            totalCountData = JSON.parse(totalCountText); // 解析 JSON
          } catch (e) {
            console.error("解析 JSON 失败:", totalCountText);
            alert(`返回的总数数据格式异常:\n${totalCountText}`);
            return;
          }

          this.chartData0 = totalCountData;
          this.chartDataKey++;

          // 2. 获取提交数量数据并更新 value
          const commitCountUrl = `http://localhost:8888/getData/getCommitCount?repo=${selectedValue}`;
          const commitCountResponse = await fetch(commitCountUrl);
          const commitCountText = await commitCountResponse.text();
          let commitCountData = [];

          try {
            commitCountData = JSON.parse(commitCountText);
          } catch (e) {
            console.error("解析 JSON 失败:", commitCountText);
            alert(`返回的提交数数据格式异常:\n${commitCountText}`);
            return;
          }

          // 解析 year 和 count 到 value 的 xAxis 和 yAxis
          this.value0.xAxis = commitCountData.map((item) => item.time);
          this.value0.yAxis = commitCountData.map((item) => item.count);

          // 3. 强制刷新 chartContainer1
          this.chartContainer1Key++;
        } catch (error) {
          console.error("请求失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
      } else if (data.showStatus === 1) {
        if (!isNaN(Number(data.module))) {
          var suburl = data.module;
          suburl = data.tri[Number(data.module)].name;
          this.module = data.tri[Number(data.module)].name;
          var type = 1;

          if (data.submodule !== "" && data.submodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.submodule)].name;
            this.submodule = data.tri[Number(data.submodule)].name;
            type = 2;
          }

          if (data.subsubmodule !== "" && data.subsubmodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.subsubmodule)].name;
            this.subsubmodule = data.tri[Number(data.subsubmodule)].name;
            type = 3;
          }

          if (data.selectedRadio === "Option 1") {
            type += 3;
          }

          // 对 URL 进行编码处理
          suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
          suburl = encodeURIComponent(suburl);

          // 构造最终的 URL
          var url = `http://localhost:8888/getData/getModule?repo=${data.selectedValue}&prefix=${suburl}&type=${type}`;

          // 用 fetch 获取 URL 的数据
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseText1 = await response.text(); // 获取返回的文本数据
            const responseText = responseText1.slice(
              1,
              responseText1.length - 1
            );
            // 解析返回的字符串数据
            const rawData = {};

            // 按照逗号分割字符串，得到每一对 'key=value'
            const items = responseText.split(",");

            items.forEach((item) => {
              // 按等号分割每个 'key=value' 字符串
              const [key, value] = item.split("=");
              if (key && value) {
                rawData[key.trim()] = parseInt(value.trim(), 10); // 转换 value 为数字
              }
            });

            // 提取 xAxis 和 yAxis
            const xAxis = Object.keys(rawData); // 获取所有的日期（年份-月份）
            const yAxis = Object.values(rawData); // 获取对应的值

            // 格式化 value1
            this.value1 = {
              xAxis: xAxis,
              yAxis: yAxis,
            };
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
          var t = type % 3;
          // 用 fetch 获取 URL 的数据
          url = `http://localhost:8888/getData/getModuleC?repo=${data.selectedValue}&prefix=${suburl}&type=${t}`;
          // alert(url)
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseData = await response.json(); // 将返回的文本数据转换为 JSON
            // alert(responseData)
            // 将返回的数据存入 this.chartData1
            this.chartData1 = responseData;

            // console.log("chartData:", this.chartData); // 打印返回的数据，查看是否正确存入
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
          url = `http://localhost:8888/getData/getModuleCL?repo=${data.selectedValue}&prefix=${suburl}&type=${t}`;
          // alert(url)
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseData = await response.json(); // 将返回的文本数据转换为 JSON
            // alert(responseData)
            // 将返回的数据存入 this.chartData1
            this.chartData2 = responseData;
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
        }
      } else if (data.showStatus === 2) {
        this.selectedDropdown = data.selectedDropdown;
        // alert(data.selectedDropdown)
        t = 0;
        if (data.selectedRadio === "Option 1") {
          t = 1;
        }
        url = `http://localhost:8888/getData/getCI?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          // this.value = responseData
          const xAxis = Object.keys(responseData);
          const yAxis = Object.values(responseData);
          this.value3 = { xAxis: xAxis, yAxis: yAxis };
          // 将返回的数据存入 this.chartData1
          // this.chartData2 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getCE?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          // this.value = responseData
          const xAxis = Object.keys(responseData);
          const yAxis = Object.values(responseData);
          this.value4 = { xAxis: xAxis, yAxis: yAxis };
          // 将返回的数据存入 this.chartData1
          // this.chartData2 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getDep?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          this.chartData3 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getMF?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${t}`;
        // alert(url)
        try {
          // 获取 URL 的数据
          const response = await fetch(url);
          const responseData = await response.json(); // 将返回的文本数据转换为 JSON
          // alert(JSON.stringify(responseData))
          this.chartData4 = responseData;
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
        url = `http://localhost:8888/getData/getDiv?repo=${data.selectedValue}&company=${data.selectedDropdown}`;
        // alert(url);

        try {
          // 获取 URL 的数据
          const response = await fetch(url);

          // 获取返回的字符串数据
          const responseData = await response.text(); // 使用 text() 而不是 json()
          // alert(responseData.split("\n")[0])
          // alert(responseData); // 直接显示返回的字符串
          this.numbers = responseData.split("\n").map(Number);
          // this.chartData4 = responseData; // 如果你需要在图表中使用它
        } catch (error) {
          console.error("获取数据失败:", error);
          alert("获取数据失败，请检查 API 服务是否正常。");
        }
      } else if (data.showStatus === 3) {
        // alert(data.showStatus)
        // alert(data.selectedDropdown)
        this.selectedDropdown = data.selectedDropdown;
        if (!isNaN(Number(data.module))) {
          suburl = data.module;
          suburl = data.tri[Number(data.module)].name;
          type = 1;

          if (data.submodule !== "" && data.submodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.submodule)].name;
            type = 2;
          }

          if (data.subsubmodule !== "" && data.subsubmodule !== "view_all") {
            suburl = suburl + "/" + data.tri[Number(data.subsubmodule)].name;
            type = 3;
          }

          if (data.selectedRadio === "Option 1") {
            type += 3;
          }
          suburl = suburl.replace(/\//g, "\\1").replace(/\\/g, "\\0");
          suburl = encodeURIComponent(suburl);
          url = `http://localhost:8888/getData/getCF?repo=${data.selectedValue}&company=${data.selectedDropdown}&type=${type}&prefix=${suburl}`;
          // alert(url)
          try {
            // 获取 URL 的数据
            const response = await fetch(url);
            const responseData = await response.json(); // 将返回的文本数据转换为 JSON
            // alert(JSON.stringify(responseData))
            const xAxis = Object.keys(responseData);
            const yAxis = Object.values(responseData);
            this.value6 = { xAxis: xAxis, yAxis: yAxis };
          } catch (error) {
            console.error("获取数据失败:", error);
            alert("获取数据失败，请检查 API 服务是否正常。");
          }
        }
      }

      // Emit 更新选中的值
      this.$emit("update-selected-value", selectedValue);
    },
    setStatus(value0) {
      this.status = value0;
    },
    scrollToSection(sectionId) {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    },
    scrollToTop() {
      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    },
    getNavItems() {
      const chartContainers = [];
      if (this.status === 4) {
        chartContainers.push({ id: "chartContainer0", name: "Overview" });
        chartContainers.push({ id: "chartContainer1", name: "Commits" });
      } else if (this.status === 1) {
        chartContainers.push({
          id: "chartContainer0",
          name: "Module Commit Frequency Over Time",
        });
        chartContainers.push({
          id: "chartContainer1",
          name: "Commit Contributions by Company",
        });
        chartContainers.push({
          id: "chartContainer2",
          name: "Edited Code Distribution by Company",
        });
      } else if (this.status === 2) {
        chartContainers.push({
          id: "chartContainer0",
          name: "Commit intensity",
        });
        chartContainers.push({
          id: "chartContainer2",
          name: "Commit extension",
        });
        chartContainers.push({
          id: "chartContainer4",
          name: "Focused modules",
        });
        chartContainers.push({
          id: "chartContainer5",
          name: "Task preference",
        });
      }
      // 更多状态条件...
      return chartContainers;
    },
    updateStatusFromChild(newStatus) {
      this.status = newStatus;
    },
    handleScroll() {
      this.isVisible = window.scrollY > 100;
    },
  },
});
</script>
<style scoped>
.calpage-container {
  max-width: 1920px;
  margin: 0 auto;
  padding: 20px;
}

.selector-wrapper {
  max-width: 1200px;
  margin: 0 auto 20px;
  padding: 0 20px;
}

.main-content {
  display: flex;
  gap: 30px;
  position: relative;
}

.side-navigation {
  position: sticky;
  top: 20px;
  width: 250px;
  height: fit-content;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.chart-scrollbar {
  flex: 1;
  /* max-height: calc(100vh - 100px); */
  overflow-y: auto;
  overflow-x: hidden;
}

.charts-container {
  padding: 20px;
  /* width: 1050px; */
  overflow-x: hidden;
}

.chart-wrapper {
  width: 100%;
  background-color: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 20px;
  margin-bottom: 30px;
  min-height: 400px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.el-menu-item {
  font-size: 15px;
  height: 50px;
  line-height: 50px;
  padding-left: 20px !important;
  white-space: normal;
  /* border-top: 1px solid #e0e0e0; */
  border-bottom: 2px solid #e0e0e0;
}

.el-menu-item i+span,
.el-menu-item:has(.el-icon-arrow-up) {
  padding-left: 0px !important;
}

.el-menu-item:not(:has(.el-icon-arrow-up)) {
  padding-left: 20px !important;
}

.el-menu-item:hover {
  background-color: #e6f1fe !important;
}

@media (max-width: 1400px) {
  .main-content {
    flex-direction: column;
  }

  .side-navigation {
    width: 100%;
    position: static;
    margin-bottom: 20px;
  }

  .chart-scrollbar {
    max-height: none;
  }
}

.scroll-to-top {
  position: fixed;
  bottom: 100px;
  right: 80px;
  background-color: #409EFF;
  color: white;
  border: none;
  border-radius: 5px;
  padding: 10px 15px;
  cursor: pointer;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.2);
  z-index: 1000;
  /* 确保按钮在其他元素之上 */
}

.scroll-to-top:hover {
  background-color: #66b1ff;
}
</style>
