<template>
    <div ref="lineChart" style="width: 700px; height: 300px;"></div>
  </template>
  
  <script>
  import { onMounted, ref, watch, computed } from 'vue';
  import * as echarts from 'echarts';
  
  export default {
    name: 'BigLine4',
    props: {
      title: {
        type: String,
        required: false,
        default: '默认折线图'
      },
      value: {
        type: Object,
        required: false,
        // default: () => ({
        //   xAxis: ['1月', '2月', '3月', '4月', '5月', '6月'],
        //   series: [
        //     { name: '产品A', data: [10, 20, 15, 30, 25, 40] },
        //     { name: '产品B', data: [15, 25, 20, 35, 30, 45] },
        //     { name: '产品C', data: [20, 30, 25, 40, 35, 50] },
        //     { name: '产品D', data: [55, 35, 30, 45, 40, 55] }
        //   ]
        // }),
        validator(value) {
          return (
            Array.isArray(value.xAxis) &&
            Array.isArray(value.series) &&
            value.series.length <= 4 &&
            value.series.every(dataset => 
              Array.isArray(dataset.data) && typeof dataset.name === 'string'
            )
          );
        }
      }
    },
    setup(props) {
      const lineChart = ref(null);
      const chartInstance = ref(null);
  
      // 计算最终数据，确保即使没有传值也能正常运行
      const chartData = computed(() => ({
        xAxis: props.value?.xAxis,
        series: props.value?.series
      }));
  
      const renderChart = () => {
        if (lineChart.value) {
          chartInstance.value = echarts.init(lineChart.value);
  
          // 添加检查以确保 chartData.value 和 series 是有效的
          if (chartData.value && chartData.value.series) {
            const option = {
              tooltip: {
                trigger: 'axis',
                axisPointer: {
                  type: 'cross',
                  label: { backgroundColor: '#6a7985' }
                }
              },
              grid: {
                top: 40,
                bottom: 30,
                left: 40,
                right: 20,
                containLabel: true
              },
              legend: {
                top: 10,
                left: 'center',
                textStyle: { fontSize: 12, color: '#666' },
                data: chartData.value.series.map(dataset => dataset.name)
              },
              xAxis: {
                type: 'category',
                data: chartData.value.xAxis,
                boundaryGap: false
              },
              yAxis: { type: 'value' },
              series: chartData.value.series.map((dataset, index) => ({
                name: dataset.name,
                type: 'line',
                smooth: false,
                data: dataset.data,
                symbol: 'circle',
                symbolSize: 4,
                lineStyle: { width: 1 },
                showSymbol: true,
                showAllSymbol: true,
                itemStyle: { color: ['#3398DB', '#E74C3C', '#2ECC71', '#F1C40F'][index] }
              }))
            };
  
            chartInstance.value.setOption(option);
          }
          window.addEventListener('resize', () => chartInstance.value.resize());
        }
      };
  
      onMounted(renderChart);
      watch(chartData, renderChart, { deep: true });
  
      return { lineChart };
    }
  };
  </script>
  
  <style scoped>
  /* 可在这里添加额外样式 */
  </style>
  