<template>
    <div class="want-more-container">
      <!-- 按钮 -->
      <el-button 
        type="primary" 
        @click="handleClick" 
        class="want-more-btn"
      >
        Deeper
      </el-button>
  
      <!-- 文本 -->
      <span class="want-more-text">Deeper anlyzation updated x days ago</span>
    </div>
  </template>
  
  <script>
  export default {
    name: "WantMore",
    methods: {
      handleClick() {
        // 这里可以定义按钮点击后的逻辑
        console.log("按钮被点击，查看更多内容");
      }
    }
  };
  </script>
  
  <style scoped>
  .want-more-container {
    display: flex;
    align-items: center;
    gap: 10px; /* 按钮和文本之间的间距 */
  }
  
  .want-more-btn {
    margin-right: 10px; /* 按钮右边的间距 */
  }
  
  .want-more-text {
    font-size: 16px;
    color: #333;
  }
  </style>
  