<template>
    <div ref="chartRef" style="width: 800px; height: 400px;"></div>
  </template>
  
  <script setup>
  import { onMounted, ref } from 'vue'
  import * as echarts from 'echarts'
  
  const chartRef = ref(null)
  
  const data = [
  { year: 2004, name: 'cantab', rank: 1 },
  { year: 2004, name: 'networknode', rank: 2 },
  { year: 2004, name: 'linuxmips', rank: 3 },
  { year: 2004, name: 'susede', rank: 4 },
  { year: 2004, name: 'physiqueusherbrookeca', rank: 5 },

  { year: 2005, name: 'pobox', rank: 1 },
  { year: 2005, name: 'intel', rank: 2 },
  { year: 2005, name: 'pretzelyyzus', rank: 3 },
  { year: 2005, name: 'usibm', rank: 4 },
  { year: 2005, name: 'cantab', rank: 5 },

  { year: 2006, name: 'redhat', rank: 1 },
  { year: 2006, name: 'garzik', rank: 2 },
  { year: 2006, name: 'g5osdl', rank: 3 },
  { year: 2006, name: 'infradead', rank: 4 },
  { year: 2006, name: 'pobox', rank: 5 },

  { year: 2007, name: 'woodylinuxfoundation', rank: 1 },
  { year: 2007, name: 'infradead', rank: 2 },
  { year: 2007, name: 'insightbb', rank: 3 },
  { year: 2007, name: 'kernelcrashing', rank: 4 },
  { year: 2007, name: 'samba', rank: 5 },

  { year: 2008, name: 'eltehu', rank: 1 },
  { year: 2008, name: 'linuxfoundation', rank: 2 },
  { year: 2008, name: 'susede', rank: 3 },
  { year: 2008, name: 'intel', rank: 4 },
  { year: 2008, name: 'davemloft', rank: 5 },

  { year: 2009, name: 'eltehu', rank: 1 },
  { year: 2009, name: 'susede', rank: 2 },
  { year: 2009, name: 'intel', rank: 3 },
  { year: 2009, name: 'linuxfoundation', rank: 4 },
  { year: 2009, name: 'opensourcewolfsonmicro', rank: 5 },

  { year: 2010, name: 'susecz', rank: 1 },
  { year: 2010, name: 'eltehu', rank: 2 },
  { year: 2010, name: 'intel', rank: 3 },
  { year: 2010, name: 'susede', rank: 4 },
  { year: 2010, name: 'opensourcewolfsonmicro', rank: 5 },

  { year: 2011, name: 'linuxsh', rank: 1 },
  { year: 2011, name: 'susecz', rank: 2 },
  { year: 2011, name: 'eltehu', rank: 3 },
  { year: 2011, name: 'susede', rank: 4 },
  { year: 2011, name: 'linuxfoundation', rank: 5 },

  { year: 2012, name: 'redhat', rank: 1 },
  { year: 2012, name: 'intel', rank: 2 },
  { year: 2012, name: 'linuxfoundation', rank: 3 },
  { year: 2012, name: 'euromailse', rank: 4 },
  { year: 2012, name: 'kernel', rank: 5 },

  { year: 2013, name: 'redhat', rank: 1 },
  { year: 2013, name: 'linuxfoundation', rank: 2 },
  { year: 2013, name: 'susecz', rank: 3 },
  { year: 2013, name: 'kernel', rank: 4 },
  { year: 2013, name: 'euromailse', rank: 5 },

  { year: 2014, name: 'kernel', rank: 1 },
  { year: 2014, name: 'linuxfoundation', rank: 2 },
  { year: 2014, name: 'redhat', rank: 3 },
  { year: 2014, name: 'susecz', rank: 4 },
  { year: 2014, name: 'susede', rank: 5 },

  { year: 2015, name: 'kernel', rank: 1 },
  { year: 2015, name: 'chromium', rank: 2 },
  { year: 2015, name: 'linuxfoundation', rank: 3 },
  { year: 2015, name: 'intel', rank: 4 },
  { year: 2015, name: 'osgsamsung', rank: 5 },

  { year: 2016, name: 'kernel', rank: 1 },
  { year: 2016, name: 'linuxfoundation', rank: 2 },
  { year: 2016, name: 'intel', rank: 3 },
  { year: 2016, name: 'chromium', rank: 4 },
  { year: 2016, name: 'ffwllch', rank: 5 },

  { year: 2017, name: 'kernel', rank: 1 },
  { year: 2017, name: 'chromium', rank: 2 },
  { year: 2017, name: 'linuxfoundation', rank: 3 },
  { year: 2017, name: 'intel', rank: 4 },
  { year: 2017, name: 'ffwllch', rank: 5 },

  { year: 2018, name: 'kernel', rank: 1 },
  { year: 2018, name: 'linuxfoundation', rank: 2 },
  { year: 2018, name: 'chromium', rank: 3 },
  { year: 2018, name: 'intel', rank: 4 },
  { year: 2018, name: 'samsung', rank: 5 },

  { year: 2019, name: 'kernel', rank: 1 },
  { year: 2019, name: 'chromium', rank: 2 },
  { year: 2019, name: 'linuxfoundation', rank: 3 },
  { year: 2019, name: 'susede', rank: 4 },
  { year: 2019, name: 'linuxintel', rank: 5 },

  { year: 2020, name: 'kernel', rank: 1 },
  { year: 2020, name: 'linuxfoundation', rank: 2 },
  { year: 2020, name: 'chromium', rank: 3 },
  { year: 2020, name: 'susede', rank: 4 },
  { year: 2020, name: 'linuxintel', rank: 5 },

  { year: 2021, name: 'kernel', rank: 1 },
  { year: 2021, name: 'linuxfoundation', rank: 2 },
  { year: 2021, name: 'chromium', rank: 3 },
  { year: 2021, name: 'intel', rank: 4 },
  { year: 2021, name: 'susede', rank: 5 },

  { year: 2022, name: 'chromium', rank: 1 },
  { year: 2022, name: 'susede', rank: 2 },
  { year: 2022, name: 'kernel', rank: 3 },
  { year: 2022, name: 'intel', rank: 4 },
  { year: 2022, name: 'linuxfoundation', rank: 5 },

  { year: 2023, name: 'kernel', rank: 1 },
  { year: 2023, name: 'chromium', rank: 2 },
  { year: 2023, name: 'linuxfoundation', rank: 3 },
  { year: 2023, name: 'intel', rank: 4 },
  { year: 2023, name: 'susede', rank: 5 },

  { year: 2024, name: 'kernel', rank: 1 },
  { year: 2024, name: 'chromium', rank: 2 },
  { year: 2024, name: 'linuxfoundation', rank: 3 },
  { year: 2024, name: 'intel', rank: 4 },
  { year: 2024, name: 'susede', rank: 5 }
]

  
  // 处理数据
  const years = [...new Set(data.map(d => d.year))].sort()
  const companies = [...new Set(data.map(d => d.name))]
  
  // 每个公司对应的排名数组
  const series = companies.map(company => {
    const companyData = years.map(year => {
      const item = data.find(d => d.year === year && d.name === company)
      return item ? item.rank : null
    })
    return {
      name: company,
      type: 'line',
      data: companyData,
      connectNulls: true,
      symbol: 'circle',
      symbolSize: 8,
      lineStyle: {
        width: 2
      }
    }
  })
  
  onMounted(() => {
    const chart = echarts.init(chartRef.value)
  
    chart.setOption({
      title: {
        text: 'Company Rank by Year',
        left: 'center'
      },
      // tooltip: {
      //   trigger: 'item',
      //   formatter: (params) => `${params.seriesName} - ${params.value}位`
      // },
      legend: {
        top: '10%',
        type: 'scroll'
      },
      grid: {
        top: '20%',
        left: '5%',
        right: '5%',
        bottom: '10%'
      },
      xAxis: {
        type: 'category',
        data: years,
        boundaryGap: false
      },
      yAxis: {
        type: 'value',
        inverse: true, // 反转Y轴，1在上面
        min: 1,
        max: 5,
        interval: 1,
        axisLabel: {
          formatter: '{value}'
        }
      },
      series: series
    })
  
    window.addEventListener('resize', () => {
      chart.resize()
    })
  })
  </script>
  
  <style scoped>
  </style>
  