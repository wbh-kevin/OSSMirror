<template>
  <div class="big-con-container" style="width: 760px; height: 360px">
    <!-- 横向排列的div -->
    <el-row
      type="flex"
      justify="space-between"
      align="middle"
      style="margin-bottom: 20px"
    >
      <!-- 左侧标题 -->
      <el-col :span="10">
        <h3 style="text-align: left;">{{ title }}</h3>
      </el-col>

      <!-- 中间的滑块（开关） -->
      <el-col :span="4" style="text-align: center;">
        <el-switch
          v-model="switchValue"
          active-text="Month"
          inactive-text="Year"
          active-color="#13ce66"
          inactive-color="#ff4949"
          @change="handleSwitchChange"
        />
      </el-col>

      <!-- 右侧按钮 -->
      <el-col :span="10" style="text-align: right">
        <el-button @click="toggle" type="primary">{{ buttonText }}</el-button>
      </el-col>
    </el-row>

    <!-- 内容区域，保证固定高度 -->
    <div class="content-box">
      <div v-if="isTextBoxVisible">
        <div class="text-display-box" style="width: 750px">
          <p>{{ inputContent }}</p>
        </div>
      </div>

      <div v-else>
        <div id="chartContainer" class="el-margin-top-md">
          <!-- 添加 key 属性，使用 switchValue 作为依据 -->
          <BigLine 
            :key="switchValue ? 'month' : 'year'"
            :title="lineTitle" 
            :value="value" 
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// 引入 BigLine 子组件
import BigLine from "./BigLine.vue";

export default {
  components: { BigLine },
  props: {
    title: {
      type: String,
      required: true,
    },
    displayContent: {
      type: String,
      required: true,
    },
    lineTitle: {
      type: String,
      required: true,
    },
    value: {
      type: [Number, String],
      required: true,
    },
  },
  data() {
    return {
      isTextBoxVisible: false,
      inputContent: this.displayContent,
      switchValue: false, // 默认开关状态为 "Year"
    };
  },
  computed: {
    buttonText() {
      return this.isTextBoxVisible ? "Back to graph" : "How does it works";
    },
  },
  methods: {
    toggle() {
      this.isTextBoxVisible = !this.isTextBoxVisible;
      if (!this.isTextBoxVisible) {
        this.inputContent = this.displayContent;
      }
    },
    handleSwitchChange(value) {
      // 发出事件给父组件，携带切换后的值
      const selectedValue = value ? 'Month' : 'Year';
      this.$emit('switch-changed', selectedValue);  // 自定义事件 `switch-changed`
    },
  },
};
</script>

<style scoped>
.big-con-container {
  padding: 20px;
  background-color: white;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.el-row {
  margin-bottom: 10px;
}

.el-col {
  padding: 0 10px;
}

h3 {
  margin: 0;
}

.content-box {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
}

.text-display-box {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 200px;
  font-size: 18px;
  text-align: center;
  padding: 20px;
  background-color: white;
  border: none;
}
</style>
