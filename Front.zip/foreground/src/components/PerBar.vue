<template>
    <div class="progress-container" style="height: 400px;">
      <h1 class="chart-title">Risk of module domination</h1>
      <div ref="chart" class="progress-chart"></div>
    </div>
  </template>
  
  <script>
  import * as echarts from 'echarts';
  
  export default {
    name: 'PerBar',
    props: {
      progressPercentage: {
        type: Number,
        required: true,
        validator: value => value >= 0 && value <= 100,
      },
    },
    watch: {
      // 监听 progressPercentage 的变化
      progressPercentage(newValue) {
        this.updateProgress(newValue);
      },
    },
    mounted() {
      this.initChart();
      this.updateProgress(this.progressPercentage); // 初始化时设置进度
    },
    beforeUnmount() {
      if (this.chart) {
        this.chart.dispose(); // 销毁 chart 实例，防止内存泄漏
      }
    },
    methods: {
      initChart() {
        this.chart = echarts.init(this.$refs.chart);
        const option = {
          series: [
            {
              type: 'gauge',
              radius: '100%',
              min: 0,
              max: 100,
              splitNumber: 10,
              axisLine: {
                lineStyle: {
                  width: 10,
                  color: [
                    [0.2, '#33cc33'],
                    [0.4, '#99cc00'],
                    [0.6, '#ffcc00'],
                    [0.8, '#ff9900'],
                    [1, '#ff4500'],
                  ],
                },
              },
              axisTick: {
                length: 10,
                lineStyle: {
                  color: '#999',
                  width: 1,
                },
              },
              axisLabel: {
                color: '#999',
                fontSize: 12,
              },
              pointer: {
                length: '80%',
                width: 6,
                color: 'auto',
              },
              title: {
                offsetCenter: [0, '80%'],
                fontSize: 16,
                fontWeight: 'bold',
                color: '#333',
                formatter: 'Progress',
              },
              detail: {
                valueAnimation: true,
                formatter: '{value}%',
                color: '#333',
                fontSize: 18,
              },
              data: [{ value: this.progressPercentage, name: '' }],
            },
          ],
        };
        this.chart.setOption(option);
      },
      updateProgress(progress) {
        if (this.chart) {
          const option = this.chart.getOption();
          option.series[0].data[0].value = progress;
          this.chart.setOption(option, true); // 更新图表
        }
      },
    },
  };
  </script>
  
  <style scoped>
  .progress-container {
    width: 100%;
    height: 200px; /* 控制进度条的高度 */
    text-align: center; /* 使标题居中 */
  }
  
  .chart-title {
    margin: 0; /* 去掉默认的外边距 */
    font-size: 24px; /* 设置标题字体大小 */
    color: #333; /* 设置标题颜色 */
  }
  
  .progress-chart {
    width: 100%;
    height: 80%;
  }
  </style>
  