<template>
  <div>
    <div style="margin: 0 auto; max-width: 1200px;">
      <!-- 监听子组件的更新事件 -->
      <SelectOverview :options="options" @selected-value="handleSelectedValueUpdate"
        @update:showStatus="updateStatusFromChild" style="margin-bottom: 20px;" />
    </div>

    <!-- 传递 barChartData1 和 barChartData2 给子组件 -->
    <div id="chart-container" v-if="isDataLoaded" style="display: flex; align-items: center; width: 1200px; margin: 0 auto; height: 400px;">
      <BarChart :data1="barChartData1" :data2="barChartData2" @bar-clicked="handleBarClick" style="flex: 0 0 70%;" />
      <div>
        <PerBar :progress-percentage="percent" style="width: 200px; height: 300px;" @click="toggleDominateTable"></PerBar>
        <el-button type="primary" @click="toggleDominateTable" style="display: block; margin: 0 auto;" v-if="false">
          {{ showDominateTable ? 'hide details' : 'show details' }}
        </el-button>
      </div>
    </div>
        <el-button type="primary" v-if="isDataLoaded"  @click="downloadChartsAsImage" style="display: block; margin: 0 auto;">
          Download Charts
        </el-button>
    <SingleTable :tableData="tableData2" v-if="showSingleTable" ref="singleTable" :column2Header="c2H"
      style="margin: 20px auto; width: 80%; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);" />

    <div v-if="showDominateTable" style="margin: 20px auto; width: 80%; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
      <DominateTable :tableData="dominateData" style="height: 450px;" />
      <el-button type="primary" @click="downloadDominateTableCSV" style="margin: 20px auto; display: block;">
        Download Dominate Table
      </el-button>
    </div>

    <div style="display: flex; justify-content: space-between; margin: 20px 0;" v-if="false">
      <h1 style="font-size: 24px; color: #333;">公司撤出概率预测</h1>
      <div style="height: 240px; width: 600px;">
        <PerBar :progressPercentage="progress" />
      </div>
    </div>

    <!-- <div style="margin: 20px auto; width: 80%; background-color: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);"
    v-if="false">
      <RiskTable :tableData="tableData" style="height: 450px;" />
      <el-button type="primary" @click="downloadRiskTableCSV" style="margin: 20px auto; display: block;">
        Download Risk Table
      </el-button>
    </div> -->
  </div>
</template>

<script>
import PerBar from "./PerBar.vue";
import SelectOverview from "./SelectOverview.vue";
// import RiskTable from "./RiskTable.vue";
import DominateTable from "./DominateTable.vue";
import { ElButton } from 'element-plus';
import BarChart from './BarChart.vue';
import SingleTable from './SingleTable.vue';
import html2canvas from 'html2canvas';

export default {
  name: "RiskCal",
  components: {
    PerBar,
    SelectOverview,
    // RiskTable,
    DominateTable,
    ElButton,
    BarChart,
    SingleTable,
  },
  data() {
    return {
      urlP: `http://30901d0b.r40.cpolar.top/getData/`,
      tableData: [],
      tableData2: [],
      percent: 0,
      c2H: "",
      racial: 0,
      totalLen: 0,
      dominateData: [],
      topCompanies: [],
      progress: 50,
      options: [],
      showSingleTable: false,
      barChartData1: [0.1, 0.5, 0.2, 0.2, 0.2], // 初始化为默认值
      barChartData2: [0.1, 0.5, 0.2, 0.2, 0.2], // 初始化为默认值
      isDataLoaded: false,
      showDominateTable: false,
      previousSelectedBar: null,
      previousSeriesName: null,
    };
  },
  methods: {
    async handleSelectedValueUpdate(selectedValue) {
      try {
        const url = this.urlP + `getRisk?repo=${selectedValue}`;
        const response = await fetch(url);
        const data = await response.json();

        const processedData = Object.keys(data).map((key) => ({
          column1: key,
          column2: data[key].depend,
          column3: data[key].predict,
        }));

        this.tableData = processedData;

        // 统计数据分布
        const ranges = [0, 0.2, 0.4, 0.6, 0.8, 1.01];
        const countColumn2 = new Array(ranges.length - 1).fill(0);
        const countColumn3 = new Array(ranges.length - 1).fill(0);

        processedData.forEach(item => {
          const value2 = item.column2;
          const value3 = item.column3;

          const index2 = ranges.findIndex((range, i) => value2 >= range && value2 < ranges[i + 1]);
          if (index2 !== -1) countColumn2[index2]++;

          const index3 = ranges.findIndex((range, i) => value3 >= range && value3 < ranges[i + 1]);
          if (index3 !== -1) countColumn3[index3]++;
        });

        // alert(JSON.stringify(countColumn2))

        // 更新 BarChart 数据
        this.barChartData1 = countColumn2;
        this.barChartData2 = countColumn3;
      } catch (error) {
        console.error("请求失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
      // 异步请求获取数据
      try {
        const url = this.urlP + `getDominate?repo=${selectedValue}`;
        // alert(url)
        const response = await fetch(url);
        const data = await response.text(); // 获取原始的文本数据
        this.racial = 0;
        this.totalLen = 0;
        // 处理返回的数据
        const processedData = data
          .split("Module:")
          .map((item) => {
            // 清理掉空的项
            if (!item.trim()) return null;

            // 以换行符分割，获取模块名和公司贡献信息
            const lines = item.trim().split("\n");
            const moduleName = lines[0].trim(); // 模块名

            // 提取公司和贡献数据
            const companies = lines
              .slice(1)
              .map((line) => {
                const parts = line.split("-");
                if (parts.length === 2) {
                  const company = parts[0].trim();
                  const contribution = parts[1].trim();
                  return { company, contribution };
                }
                return null;
              })
              .filter(Boolean); // 去掉无效数据

            // 只取前三个公司和贡献数据
            const topCompanies = companies.slice(0, 3);
            const CA1 = parseFloat(topCompanies[0].contribution.replace('%', '')) / 100;
            const CA2 = topCompanies[1] ? parseFloat(topCompanies[1].contribution.replace('%', '')) / 100 : 0;
            // alert(moduleName)
            // alert(CA1)
            // 添加条件判断
            if (3 * CA1 * CA1 > 1 + CA2 * CA2) {
                this.racial += 1;
            }
            this.totalLen += 1;

            // 返回结果，每个模块包含前三个公司的贡献数据
            return {
              column1: moduleName, // 模块名称
              column2: topCompanies[0]
                ? `${topCompanies[0].company}-${topCompanies[0].contribution}`
                : "",
              column3: topCompanies[1]
                ? `${topCompanies[1].company}-${topCompanies[1].contribution}`
                : "",
              column4: topCompanies[2]
                ? `${topCompanies[2].company}-${topCompanies[2].contribution}`
                : "",
            };
          })
          .filter((item) => item !== null); // 去除 null 值

        // 输出格式化后的 JSON 数据
        this.dominateData = processedData;
        this.percent = this.racial*100/this.totalLen;
        this.percent = this.percent.toFixed(2);
        // alert(this.racial/this.totalLen)
      } catch (error) {
        console.error("请求失败:", error);
        alert("获取数据失败，请检查 API 服务是否正常。");
      }
      this.isDataLoaded = true;
    },
    handleBarClick({ selectedBar, seriesName }) {
      if (this.previousSelectedBar === selectedBar && this.previousSeriesName === seriesName) {
        this.showSingleTable = !this.showSingleTable;
      } else {
        this.showSingleTable = true;
      }
      
      this.previousSelectedBar = selectedBar;
      this.previousSeriesName = seriesName;

      if (seriesName === "Risk of dependency on single supplier") {
        this.c2H = "Risk of dependency on single supplier";
      }
      else if (seriesName === "Departure Risk") {
        this.c2H = "Departure Risk";
      }
      if (selectedBar === "0-0.2" && seriesName === "Risk of dependency on single supplier") {
        const jsonData = this.tableData
          .filter(item => item.column3 < 0.2) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column3
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.2-0.4" && seriesName === "Risk of dependency on single supplier") {
        const jsonData = this.tableData
          .filter(item => item.column3 < 0.4 && item.column3 >= 0.2) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column3
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.4-0.6" && seriesName === "Risk of dependency on single supplier") {
        const jsonData = this.tableData
          .filter(item => item.column3 < 0.6 && item.column3 >= 0.4) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column3
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.6-0.8" && seriesName === "Risk of dependency on single supplier") {
        const jsonData = this.tableData
          .filter(item => item.column3 < 0.8 && item.column3 >= 0.6) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column3
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.8-1" && seriesName === "Risk of dependency on single supplier") {
        const jsonData = this.tableData
          .filter(item => item.column3 >= 0.8) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column3
          }));
        this.tableData2 = jsonData;
      }
      if (selectedBar === "0-0.2" && seriesName === "Departure Risk") {
        const jsonData = this.tableData
          .filter(item => item.column2 < 0.2) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column2
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.2-0.4" && seriesName === "Departure Risk") {
        const jsonData = this.tableData
          .filter(item => item.column2 < 0.4 && item.column2 >= 0.2) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column2
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.4-0.6" && seriesName === "Departure Risk") {
        const jsonData = this.tableData
          .filter(item => item.column2 < 0.6 && item.column2 >= 0.4) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column2
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.6-0.8" && seriesName === "Departure Risk") {
        const jsonData = this.tableData
          .filter(item => item.column2 < 0.8 && item.column2 >= 0.6) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column2
          }));
        this.tableData2 = jsonData;
      }
      else if (selectedBar === "0.8-1" && seriesName === "Departure Risk") {
        const jsonData = this.tableData
          .filter(item => item.column2 >= 0.8) // 只保留 item.column3 中值小于 0.2 的行
          .map(item => ({
            column1: item.column1,
            column2: item.column2
          }));
        this.tableData2 = jsonData;
      }
    },
    toggleDominateTable() {
      this.showDominateTable = !this.showDominateTable;
    },
    async downloadChartsAsImage() {
      const container = document.getElementById('chart-container');
      if (!container) {
        alert('图表未加载完成');
        return;
      }

      try {
        const canvas = await html2canvas(container);
        const link = document.createElement('a');
        link.href = canvas.toDataURL('image/png');
        link.download = 'chart-image.png';
        link.click();
      } catch (err) {
        console.error('截图失败:', err);
        alert('截图失败，请稍后重试');
      }
    },
  },
  mounted() {
    fetch(this.urlP + "getRepoList2")
    .then((response) => response.json())
      .then((data) => {
        this.options = data.map((item) => ({
          label: item.name + (item.id==1?` (Last updated: ${item.date})`:` (Calculating: ${item.date})`),
          value: item.name
        }));
      })
      .catch((error) => {
        console.error("获取数据失败:", error);
      });
  },
};
</script>

<style scoped>
/* 可根据需求添加样式 */
</style>
