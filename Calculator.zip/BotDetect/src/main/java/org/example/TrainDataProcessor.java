package org.example;

import java.io.*;
import java.util.*;

public class TrainDataProcessor {
    public static void main(String[] args) {
        // 输入输出文件路径
        String preTrainCsv = "pre_train.csv";
        String llmOutTxt = "data/torvalds-linux/llm.out";  // 修改后的输入文件
        String trainOutCsv = "train_out.csv";

        // 读取 llm.out 文件，存储到 List
        List<String> llmOutList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(llmOutTxt))) {
            String line;
            while ((line = reader.readLine()) != null) {
                llmOutList.add(line.trim());  // 直接存储 word
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 读取 pre_train.csv 文件，存储为 List
        List<String[]> preTrainList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(preTrainCsv))) {
            String line;
            boolean isFirstLine = true;
            while ((line = reader.readLine()) != null) {
                if (isFirstLine) { // 跳过表头
                    isFirstLine = false;
                    continue;
                }
                String[] fields = line.split(",");
                if (fields.length == 3) {
                    preTrainList.add(fields); // 存储 sha, message, author_date
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 将结果写入到 train_out.csv 文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(trainOutCsv))) {
            // 写入表头
            writer.write("sha,author_date,word");
            writer.newLine();

            // 遍历 llm.out，每一行对应 pre_train.csv 的一行
            for (int i = 0; i < llmOutList.size(); i++) {
                String word = llmOutList.get(i);
                int lineNumber = i + 1; // 使用行号（从 1 开始）

                if (lineNumber - 1 < preTrainList.size()) {
                    String[] preTrainEntry = preTrainList.get(lineNumber - 1);
                    String sha = preTrainEntry[0];
                    String authorDate = preTrainEntry[2];

                    // 输出 sha, author_date 和 word
                    writer.write(sha + "," + authorDate + "," + word);
                    writer.newLine();
                }
            }

            System.out.println("数据处理完毕，结果存储在 " + trainOutCsv);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
