package org.example;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevTag;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.storage.file.FileRepositoryBuilder;
import org.eclipse.jgit.lib.Ref;

import java.io.File;
import java.util.Date;
import java.util.List;

public class GitTagChecker {

    public String printLatestTagDate(String formattedRepoName) {
        Repository repository = null;
        Git git = null;

        try {
            File gitDir = new File(formattedRepoName + "/.git");

            repository = new FileRepositoryBuilder()
                    .setGitDir(gitDir)
                    .build();

            git = new Git(repository);
            List<Ref> tags = git.tagList().call();

            Ref latestTag = null;
            Date latestDate = null;

            for (Ref tag : tags) {
                try (RevWalk revWalk = new RevWalk(repository)) {
                    var objectId = tag.getObjectId();
                    var obj = revWalk.parseAny(objectId);

                    RevCommit commit = null;

                    if (obj instanceof RevTag tagObj) {
                        var targetObj = revWalk.parseAny(tagObj.getObject());

                        if (targetObj instanceof RevCommit commitObj) {
                            commit = commitObj;
                        } else {
//                            System.out.println("Tag " + tag.getName() + " 指向的不是 commit，而是 " + targetObj.getClass().getSimpleName());
                            continue; // 忽略非 commit 的 tag
                        }

                    } else if (obj instanceof RevCommit commitObj) {
                        commit = commitObj;
                    } else {
//                        System.out.println("Tag " + tag.getName() + " 本身不是 commit，也不是 annotated tag: " + obj.getClass().getSimpleName());
                        continue;
                    }

                    Date commitDate = commit.getAuthorIdent().getWhen();

                    if (latestDate == null || commitDate.after(latestDate)) {
                        latestDate = commitDate;
                        latestTag = tag;
                    }
                }
            }


            if (latestTag != null) {
                String tagName = latestTag.getName().replace("refs/tags/", "");
//                System.out.println("🟢 最新 Tag: " + tagName);
//                System.out.println("📅 发布时间: " + latestDate);
                return latestDate.toString();
            } else {
//                System.out.println("⚠️ 没有找到任何 Tag。");
            }

        } catch (Exception e) {
//            System.err.println("❌ 读取 Git 仓库出错: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (git != null) git.close();
            if (repository != null) repository.close();
        }
        return null;
    }

    // 示例用法
//    public static void main(String[] args) {
//        System.out.println(printLatestTagDate("linux"));
////        printLatestTagDate("linux"); // 替换为本地仓库目录
//    }
}
