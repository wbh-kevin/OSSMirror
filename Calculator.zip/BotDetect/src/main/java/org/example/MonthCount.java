package org.example;

import java.io.*;
import java.util.*;

public class MonthCount {
    public static void main(String[] args) {
        MonthCount monthCount = new MonthCount();
        monthCount.monthCount("gitdata");
    }
    public void monthCount(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/filtered_git_log.csv"; // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/month_count.csv"; // 输出文件路径
        Map<String, Integer> monthCountMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false; // 跳过表头
                    continue;
                }

                String[] columns = line.split(","); // CSV 采用逗号分隔
                if (columns.length < 11) continue;

                String authorDateStr = columns[4]; // 第五列是 author_date
                // authorDateStr 格式: "Mon Dec 09 06:03:39 CST 2024"
                String[] dateParts = authorDateStr.split(" "); // 按空格拆分
                if (dateParts.length > 0) {
                    String month = dateParts[1].trim();  // 提取月份
                    String year = dateParts[dateParts.length - 1].trim(); // 提取年份

                    // 检查提取的月份是否有效
                    if (!isValidMonth(month)) {
                        System.out.println("无效的月份: " + month);  // 打印无效月份
                        continue;
                    }

                    // 创建 "年-月" 格式
                    String yearMonth = year + "-" + month;

                    monthCountMap.put(yearMonth, monthCountMap.getOrDefault(yearMonth, 0) + 1);
                }
            }
        } catch (IOException e) {
            System.err.println("读取文件失败: " + e.getMessage());
        }

        // 创建月份的顺序映射
        Map<String, Integer> monthOrder = new HashMap<>();
        monthOrder.put("-Jan", 1);
        monthOrder.put("-Feb", 2);
        monthOrder.put("-Mar", 3);
        monthOrder.put("-Apr", 4);
        monthOrder.put("-May", 5);
        monthOrder.put("-Jun", 6);
        monthOrder.put("-Jul", 7);
        monthOrder.put("-Aug", 8);
        monthOrder.put("-Sep", 9);
        monthOrder.put("-Oct", 10);
        monthOrder.put("-Nov", 11);
        monthOrder.put("-Dec", 12);

        // 将统计结果写入 month_count.csv
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write("Year-Month,Count\n");  // 写入表头

            // 按照自定义顺序排序
            monthCountMap.entrySet().stream()
                    .sorted((entry1, entry2) -> {
                        // 比较年份
                        int yearComparison = entry1.getKey().substring(0, 4).compareTo(entry2.getKey().substring(0, 4));
                        if (yearComparison != 0) {
                            return yearComparison;
                        }

                        // 如果年份相同，比较月份，使用 monthOrder 映射
                        String month1 = entry1.getKey().substring(5);
                        String month2 = entry2.getKey().substring(5);
                        Integer monthOrder1 = monthOrder.get(month1);
                        Integer monthOrder2 = monthOrder.get(month2);

                        if (monthOrder1 == null || monthOrder2 == null) {
                            System.out.println("无法找到月份顺序: " + month1 + " 或 " + month2);  // 打印错误信息
                            return 0;
                        }

                        return Integer.compare(monthOrder1, monthOrder2);
                    })
                    .forEach(entry -> {
                        try {
                            writer.write(entry.getKey().replace("\"", "") + "," + entry.getValue() + "\n");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
            System.out.println("统计结果已输出到 " + outputFilePath);
        } catch (IOException e) {
            System.err.println("写入文件失败: " + e.getMessage());
        }
    }

    // 检查月份是否有效
    private static boolean isValidMonth(String month) {
        return month.equals("Jan") || month.equals("Feb") || month.equals("Mar") || month.equals("Apr") ||
                month.equals("May") || month.equals("Jun") || month.equals("Jul") || month.equals("Aug") ||
                month.equals("Sep") || month.equals("Oct") || month.equals("Nov") || month.equals("Dec");
    }
}
