package org.example;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

class ContributionCalculator {
    public void CICal(String repo) {
        String csvFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_one.csv";
        String outputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/CI.txt"; // 输出文件路径
        String line;
        String csvSplitBy = ",";
        SimpleDateFormat originalDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        SimpleDateFormat monthFormat = new SimpleDateFormat("yyyy-MM");
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");

        // Map to store contributions by company and time
        Map<String, Map<String, Map<String, Contribution>>> companyTimeData = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Read header
            line = br.readLine(); // Skip the header line
            if (line == null || !line.startsWith("rev")) {
                throw new IOException("Invalid CSV file or missing headers");
            }

            // Read file
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSplitBy);

                if (values.length != 10) { // Check for the new column count
                    continue; // Skip invalid lines
                }

                String authorDate = values[3]; // author_date
                String mailCompany = values[5]; // mailcompany
                String filePath = values[6]; // file_path
                int addedLines = Integer.parseInt(values[7]); // added_lines
                int deletedLines = Integer.parseInt(values[8]); // deleted_lines
                int mergeCount = Integer.parseInt(values[9]); // merge_count

                // Parse dates into month and year
                Date date = originalDateFormat.parse(authorDate);
                String monthKey = monthFormat.format(date);
                String yearKey = yearFormat.format(date);

                // Process data by company, time, and module
                companyTimeData.computeIfAbsent(mailCompany, k -> new HashMap<>())
                        .computeIfAbsent(monthKey, k -> new HashMap<>())
                        .computeIfAbsent(filePath, k -> new Contribution())
                        .addContribution(addedLines, deletedLines, mergeCount);

                companyTimeData.computeIfAbsent(mailCompany, k -> new HashMap<>())
                        .computeIfAbsent(yearKey, k -> new HashMap<>())
                        .computeIfAbsent(filePath, k -> new Contribution())
                        .addContribution(addedLines, deletedLines, mergeCount);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Write results to CI.txt
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
            bw.write("Contribution Intensity by Company and Time:\n");
            writeContributionData(companyTimeData, bw);
            System.out.println("Results written to " + outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Write contribution data grouped by company and time to a file
    private static void writeContributionData(Map<String, Map<String, Map<String, Contribution>>> data, BufferedWriter bw) throws IOException {
        for (Map.Entry<String, Map<String, Map<String, Contribution>>> companyEntry : data.entrySet()) {
            String company = companyEntry.getKey();
            bw.write("Company: " + company + "\n");
            Map<String, Map<String, Contribution>> timeData = companyEntry.getValue();

            for (Map.Entry<String, Map<String, Contribution>> timeEntry : timeData.entrySet()) {
                String time = timeEntry.getKey();
                bw.write("  Time Period: " + time + "\n");

                timeEntry.getValue().entrySet().stream()
                        .sorted(Map.Entry.comparingByKey()) // Sort modules alphabetically
                        .forEach(entry -> {
                            String module = entry.getKey();
                            Contribution contribution = entry.getValue();
                            try {
                                bw.write(String.format(
                                        "    Module: %s, Added Lines: %d, Deleted Lines: %d, Merge Count: %d, Total Lines: %d%n",
                                        module, contribution.addedLines, contribution.deletedLines,
                                        contribution.mergeCount, contribution.getTotalLines()
                                ));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        });
            }
        }
    }
}

// Helper class to store contribution data
class Contribution {
    int addedLines;
    int deletedLines;
    int mergeCount;

    public void addContribution(int added, int deleted, int merge) {
        this.addedLines += added;
        this.deletedLines += deleted;
        this.mergeCount += merge;
    }

    public int getTotalLines() {
        return addedLines + deletedLines;
    }
}
