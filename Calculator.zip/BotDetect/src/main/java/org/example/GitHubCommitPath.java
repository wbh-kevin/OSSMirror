package org.example;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class GitHubCommitPath {

    private static final String GITHUB_API_URL = "https://api.github.com/repos/torvalds/linux";
    private static final String GITHUB_TOKEN = "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";  // 在这里填入你的 GitHub Token

    public static void main(String[] args) throws Exception {
        String commitSha = "1e699e177e339e462cdc8571e3d0fcf29665608e";      // 填入提交的SHA

        // 拼接 API 请求 URL
        String url = GITHUB_API_URL + "/commits/" + commitSha;

        // 调用函数获取 commit 信息
        getCommitPaths(url);
    }
    public String getRPath(String sha) throws Exception {
        String url = GITHUB_API_URL + "/commits/" + sha;

        // 调用函数获取 commit 信息
        return getCommitPaths(url);

    }

    // 获取指定 Commit 的文件路径
    private static String getCommitPaths(String apiUrl) throws Exception {
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        // 设置 Authorization 头部，用于 GitHub Token 验证
        connection.setRequestProperty("Authorization", "token " + GITHUB_TOKEN);

        int responseCode = connection.getResponseCode();
        if (responseCode == 200) {  // 如果请求成功
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // 解析 JSON 响应
            JsonObject commitData = JsonParser.parseString(response.toString()).getAsJsonObject();

            // 获取文件变更列表
            JsonArray files = commitData.getAsJsonArray("files");

            // 输出每个文件的路径
//            System.out.println("Files changed in commit:");
            String changedLine = new String();
            for (int i = 0; i < files.size(); i++) {
                JsonObject file = files.get(i).getAsJsonObject();
                String filePath = file.get("filename").getAsString();
                changedLine += filePath + ';';
//                System.out.println(filePath);
            }
            return changedLine;
        } else {
            System.out.println("GET request failed. Response Code: " + responseCode);
            return null;
        }
    }
}
