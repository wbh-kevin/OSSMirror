package org.example;

import org.xbill.DNS.*;
import org.xbill.DNS.Record;

import java.io.*;
import java.util.*;

public class GetUserCompany {

    public static void main(String[] args) {
        String inputFilePath = "mailcompany.txt"; // 输入文件路径
        String outputFilePath = "cc.txt"; // 输出文件路径

        try {
            String[] domainList = readDomainsFromFile(inputFilePath);
            List<String> results = new ArrayList<>();
            int i=0;
            for (String domain : domainList) {
                i++;
                if (i%10==0){
                    System.out.println(i/10);
                }
                String bestMXRecord = resolveBestMXRecord(domain);
                results.add(domain + " -> " + bestMXRecord);
            }

            writeResultsToFile(results, outputFilePath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 解析域名并返回最佳 MX 记录
    private static String resolveBestMXRecord(String domain) {
        if (domain == null || domain.isEmpty()) return "Invalid domain";

        try {
            Lookup lookup = new Lookup(domain, Type.MX);
            Record[] records = lookup.run();
            if (lookup.getResult() == Lookup.SUCCESSFUL) {
                MXRecord bestRecord = null;

                for (Record record : records) {
                    MXRecord mx = (MXRecord) record;
                    if (bestRecord == null || mx.getPriority() < bestRecord.getPriority()) {
                        bestRecord = mx;
                    }
                }

                return bestRecord != null ? bestRecord.getTarget().toString() + " (Priority: " + bestRecord.getPriority() + ")" : "No MX records found";
            } else {
                return "No MX records found";
            }
        } catch (TextParseException e) {
            return "Invalid domain format";
        } catch (Exception e) {
            return "Error resolving domain: " + e.getMessage();
        }
    }

    // 从文件读取域名
    private static String[] readDomainsFromFile(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        return br.lines().toArray(String[]::new);
    }

    // 将结果写入文件
    private static void writeResultsToFile(List<String> results, String filePath) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
        for (String result : results) {
            writer.write(result);
            writer.newLine();
        }
        writer.close();
    }
}
