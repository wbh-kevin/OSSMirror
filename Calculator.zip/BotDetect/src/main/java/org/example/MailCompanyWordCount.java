package org.example;

import java.io.*;
import java.util.*;

public class MailCompanyWordCount {
    public void merge(String csvPath, String llmPath, String outputPath) {
        List<String> shaList = new ArrayList<>();
        List<String> wordList = new ArrayList<>();

        // Step 1: 读取 CSV 文件，只保留 sha 列
        try (BufferedReader csvReader = new BufferedReader(new FileReader(csvPath))) {
            String header = csvReader.readLine(); // 读取表头
            if (header == null) {
                throw new IOException("Empty CSV file.");
            }
            String[] headers = header.split(",");
            int shaIndex = Arrays.asList(headers).indexOf("sha");

            if (shaIndex == -1) {
                throw new IOException("Column 'sha' not found.");
            }

            String row;
            while ((row = csvReader.readLine()) != null) {
                String[] fields = row.split(",", -1); // -1 to keep empty fields
                if (fields.length > shaIndex) {
                    shaList.add(fields[shaIndex]);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading CSV: " + e.getMessage());
            return;
        }

        // Step 2: 读取 llm.out 文件
        try (BufferedReader llmReader = new BufferedReader(new FileReader(llmPath))) {
            String line;
            while ((line = llmReader.readLine()) != null) {
                wordList.add(line);
            }
        } catch (IOException e) {
            System.err.println("Error reading llm.out: " + e.getMessage());
            return;
        }

        // Step 3: 检查行数匹配
        if (shaList.size() != wordList.size()) {
            System.err.println("Mismatch: shaList size = " + shaList.size() + ", wordList size = " + wordList.size());
            return;
        }

        // Step 4: 写入新 CSV 文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            writer.write("sha,word\n");
            for (int i = 0; i < shaList.size(); i++) {
                writer.write(shaList.get(i) + "," + wordList.get(i) + "\n");
            }
        } catch (IOException e) {
            System.err.println("Error writing output CSV: " + e.getMessage());
        }

        System.out.println("Merge completed: " + outputPath);
    }
    public void merge2(String joinedCsvPath, String mergedCsvPath, String outputPath) {
        Map<String, String> shaToMailCompany = new HashMap<>();

        // Step 1: 读取 merged_all.csv，建立 rev -> mailcompany 的映射
        try (BufferedReader mergedReader = new BufferedReader(new FileReader(mergedCsvPath))) {
            String header = mergedReader.readLine();
            if (header == null) throw new IOException("Empty merged_all.csv");

            String[] headers = header.split(",");
            int revIndex = Arrays.asList(headers).indexOf("rev");
            int mailIndex = Arrays.asList(headers).indexOf("mailcompany");

            if (revIndex == -1 || mailIndex == -1) {
                throw new IOException("Missing 'rev' or 'mailcompany' column in merged_all.csv");
            }

            String line;
            while ((line = mergedReader.readLine()) != null) {
                String[] fields = line.split(",", -1);
                if (fields.length > Math.max(revIndex, mailIndex)) {
                    String rev = fields[revIndex];
                    String mailCompany = fields[mailIndex];
                    shaToMailCompany.put(rev, mailCompany);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading merged_all.csv: " + e.getMessage());
            return;
        }

        // Step 2: 读取 joined_output_1.csv，查找 sha -> mailcompany
        try (
                BufferedReader joinedReader = new BufferedReader(new FileReader(joinedCsvPath));
                BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))
        ) {
            String header = joinedReader.readLine();
            if (header == null) throw new IOException("Empty joined_output_1.csv");

            writer.write("sha,mailcompany,word\n"); // 新表头

            String line;
            while ((line = joinedReader.readLine()) != null) {
                String[] fields = line.split(",", -1);
                if (fields.length < 2) continue;
//                System.out.println(fields);

                String sha = fields[0];
                String word = fields[1];
                sha = sha.substring(1, sha.length() - 1);

//                System.out.println(sha);
                String mailcompany = shaToMailCompany.getOrDefault(sha, ""); // 没找到则为空

                writer.write(sha + "," + mailcompany + "," + word + "\n");
            }
        } catch (IOException e) {
            System.err.println("Error processing joined_output_1.csv: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        MailCompanyWordCount m = new MailCompanyWordCount();
        m.work("OPENHarmonydev-openharmony");
//        m.merge("pre_train.csv", "llm.out", "joined_output_1.csv");
//        m.merge2("joined_output_1.csv", "merged_all.csv", "joined_output_2.csv");
//        m.merge3();
    }
    public void work(String repo){
        merge("/root/workspace/wbh/BotDetect/data/" + repo + "/pre_train.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/llm.out",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/joined_output_1.csv");
        merge2("/root/workspace/wbh/BotDetect/data/" + repo + "/joined_output_1.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_all.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/joined_output_2.csv");
        merge3(repo);
    }
    public static void merge3(String repo) {
        // 输入输出文件路径
        String inputCsv = "/root/workspace/wbh/BotDetect/data/" + repo + "/joined_output_2.csv";
        String outputCsv = "/root/workspace/wbh/BotDetect/data/" + repo + "/word_count_output.csv";

        // Step 1: 读取 joined_output.csv 并统计每个 mailcompany 和 word 的出现次数
        Map<String, Map<String, Integer>> mailCompanyWordCountMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputCsv))) {
            String line;
            reader.readLine(); // 跳过表头

            // 读取每一行并进行统计
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 3) {
                    String mailCompany = fields[1].trim();  // mailcompany 字段
                    String word = fields[2].trim();  // word 字段

                    // 获取 mailCompany 对应的 word 统计 Map
                    Map<String, Integer> wordCountMap = mailCompanyWordCountMap.computeIfAbsent(mailCompany, k -> new HashMap<>());

                    // 增加 word 出现次数
                    wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Step 2: 将统计结果输出到新的 CSV 文件
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputCsv))) {
            // 写入输出文件的表头
            writer.write("mailcompany,word,count");
            writer.newLine();

            // 遍历统计结果并写入到新的 CSV 文件
            for (Map.Entry<String, Map<String, Integer>> entry : mailCompanyWordCountMap.entrySet()) {
                String mailCompany = entry.getKey();
                Map<String, Integer> wordCountMap = entry.getValue();

                // 对每个 mailcompany 下的 word 进行遍历
                for (Map.Entry<String, Integer> wordEntry : wordCountMap.entrySet()) {
                    String word = wordEntry.getKey();
                    int count = wordEntry.getValue();

                    // 写入统计结果到 CSV 文件
                    writer.write(mailCompany + "," + word + "," + count);
                    writer.newLine();
                }
            }

            System.out.println("数据处理完毕，结果存储在 " + outputCsv);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
