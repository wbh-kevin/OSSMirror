package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
    // MySQL数据库的配置信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306/localhost";
    private static final String USER = "root";
    private static final String PASS = "password";

    public static void main(String[] args) {
        // Step 1: 创建数据库表
        createTable();

        // Step 2: 读取CSV文件并插入数据
        String csvFile = "commit_changes.csv";
        String line;
        int lineNumber = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
            String insertSQL = "INSERT INTO commit_changes (commit_sha, file_path, added_lines, deleted_lines) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertSQL);

            // Skip the header
            br.readLine();

            while ((line = br.readLine()) != null) {
                lineNumber++;
                String[] elements = line.split(",");

                // Step 2.1: 数据解析
                String commitSha;
                String filePath;
                int addedLines;
                int deletedLines;

                if (elements.length >= 4) {
                    commitSha = elements[0];
                    deletedLines = Integer.parseInt(elements[elements.length - 1]);
                    addedLines = Integer.parseInt(elements[elements.length - 2]);

                    // 中间的元素（文件路径）需要用逗号拼接
                    StringBuilder filePathBuilder = new StringBuilder();
                    for (int i = 1; i < elements.length - 2; i++) {
                        filePathBuilder.append(elements[i]);
                        if (i < elements.length - 3) {
                            filePathBuilder.append(",");
                        }
                    }
                    filePath = filePathBuilder.toString();

                    // Step 3: 插入数据到数据库
                    preparedStatement.setString(1, commitSha);
                    preparedStatement.setString(2, filePath);
                    preparedStatement.setInt(3, addedLines);
                    preparedStatement.setInt(4, deletedLines);
                    preparedStatement.executeUpdate();

                    // Step 4: 显示进度
                    System.out.println("Inserted line " + lineNumber + ": commit_sha=" + commitSha + ", file_path=" + filePath);
                } else {
                    System.err.println("Line " + lineNumber + " has insufficient data.");
                }
            }
            preparedStatement.close();
            connection.close();
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createTable() {
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement statement = connection.createStatement()) {
            String createTableSQL = "CREATE TABLE IF NOT EXISTS commit_changes (" +
                    "commit_sha VARCHAR(40) NOT NULL," +
                    "file_path TEXT NOT NULL," +
                    "added_lines INT NOT NULL," +
                    "deleted_lines INT NOT NULL," +
                    "PRIMARY KEY (commit_sha)," +
                    "INDEX idx_commit_sha (commit_sha)" +
                    ");";
            statement.execute(createTableSQL);
            System.out.println("Table `commit_changes` created or already exists.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
