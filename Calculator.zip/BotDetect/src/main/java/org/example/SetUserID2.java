package org.example;

import java.io.*;
import java.util.*;

public class SetUserID2 {

    // 存储 <邮箱, 序号> 的键值对
    private Map<String, Integer> emailUserIdMap;
    private Set<String> mailCompanySet; // 存放所有出现过的 mailcompany 子串
    private Map<String, Integer> mailCompanyCount; // 存放每个 mailcompany 出现的次数

    public SetUserID2() {
        this.emailUserIdMap = new HashMap<>();
        this.mailCompanySet = new HashSet<>();
        this.mailCompanyCount = new HashMap<>();
    }

    // 从 rs2.txt 文件中加载 <email, userId> 映射
    public void loadFromFile(String filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("#");
                if (parts.length >= 2) {
                    int userId = Integer.parseInt(parts[0]);
                    String[] emails = parts[1].split(";");

                    // 对于每个邮箱，存储 <email, userId> 键值对
                    for (String email : emails) {
                        emailUserIdMap.put(email, userId);
                    }
                }
            }
        }
    }

    // 从 git_log.csv 文件中读取数据并更新 CSV 输出
    public void processGitLogAndExportCsv(String gitLogPath, String outputPath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(gitLogPath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {

            String line;
            // 读取表头
            String header = reader.readLine();
            writer.write("rev,author_name,author_email,author_date,UserID,mailcompany\n");

            // 遍历 git_log.csv 文件内容
            while ((line = reader.readLine()) != null) {
                String[] parts = parseCsvLine(line);
                if (parts.length < 11) continue; // 确保至少包含表头中定义的列数

                String rev = parts[0];           // 提交哈希
                String authorName = parts[2];    // 作者名字
                String authorEmail = parts[3];   // 作者邮箱
                String authorDate = parts[4];    // 作者日期

                Integer userId = emailUserIdMap.get(authorEmail); // 查找对应的 UserID

                // 提取 mailcompany 为 @ 后的子串
                String mailCompany = authorEmail.contains("@") ? authorEmail.substring(authorEmail.indexOf('@') + 1) : "unknown";
                mailCompanySet.add(mailCompany);

                // 更新 mailCompany 出现次数
                mailCompanyCount.put(mailCompany, mailCompanyCount.getOrDefault(mailCompany, 0) + 1);

                // 写入输出 CSV
                writer.write(rev + "," + authorName + "," + authorEmail + "," + authorDate + ",");
                writer.write((userId != null ? userId.toString() : "null") + "," + mailCompany);
                writer.newLine();
            }
        }
    }

    // 保存邮件域名及其统计
    public void saveMailCompanies(String outputPath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            for (String mailCompany : mailCompanySet) {
                int count = mailCompanyCount.get(mailCompany);
                writer.write(mailCompany); // 输出 mailCompany 和其出现次数
                writer.newLine();
            }
        }
    }

    // CSV 解析器，处理可能包含引号的字段
    private static String[] parseCsvLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '\"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                fields.add(currentField.toString());
                currentField.setLength(0);
            } else {
                currentField.append(c);
            }
        }
        fields.add(currentField.toString());
        return fields.toArray(new String[0]);
    }

    public void setID(String repo) {
        SetUserID2 setUserID2 = new SetUserID2();
        String filePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/rs2.txt";
        String gitLogPath = "/root/workspace/wbh/BotDetect/data/" + repo + "/git_log.csv";
        String outputPath = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid.csv";
        String mailCompanyOutputPath = "/root/workspace/wbh/BotDetect/data/" + repo + "/mailcompany.txt";

        try {
            setUserID2.loadFromFile(filePath);
            setUserID2.processGitLogAndExportCsv(gitLogPath, outputPath);
            setUserID2.saveMailCompanies(mailCompanyOutputPath);
            System.out.println("CSV with UserID and mailcompany column saved as " + outputPath);
            System.out.println("Distinct mail companies and their counts saved as " + mailCompanyOutputPath);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
