package org.example;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class CsvStatistic {
    public static void main(String[] args) {
        CsvStatistic csvStatistic = new CsvStatistic();
        csvStatistic



                .csvStatistic("gitdata");
    }

    public void csvStatistic(String repo) {
        // CSV 文件路径
        String csvFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid_processed.csv";
        // 输出结果文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/total.txt";

        // 统计每个 mailcompany 出现的次数
        Map<String, Integer> companyCounts = new HashMap<>();

        try (Reader reader = new FileReader(csvFilePath);
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            // 使用 Apache Commons CSV 解析 CSV 文件
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withHeader());

            // 遍历 CSV 记录
            for (CSVRecord record : csvParser) {
                // 获取 mailcompany 列的数据
                String mailCompany = record.get("mailcompany");

                // 更新该公司出现的次数
                companyCounts.put(mailCompany, companyCounts.getOrDefault(mailCompany, 0) + 1);
            }

            // 将统计结果写入到 total.txt 文件
            for (Map.Entry<String, Integer> entry : companyCounts.entrySet()) {
                String line = "\"" + entry.getKey() + "\": " + entry.getValue()+",";
                writer.write(line);
                writer.newLine();  // 换行
            }

            System.out.println("统计结果已写入 " + outputFilePath);

        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("读取文件或写入文件时发生错误！");
        }
    }
}
