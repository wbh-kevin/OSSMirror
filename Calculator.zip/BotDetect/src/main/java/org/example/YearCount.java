package org.example;

import java.io.*;
import java.util.*;

public class YearCount {
    public static void main(String[] args) {
        YearCount yearCount = new YearCount();
        yearCount.yearCount("gitdata");
    }
    public void yearCount(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/filtered_git_log.csv"; // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/year_count.csv"; // 输出文件路径
        Map<String, Integer> yearCountMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false; // 跳过表头
                    continue;
                }

                String[] columns = line.split(","); // CSV 采用制表符分隔
                if (columns.length < 11) continue;

                String authorDateStr = columns[4]; // 第五列是 author_date
                // authorDateStr 格式: "Mon Dec 09 06:03:39 CST 2024"
                String[] dateParts = authorDateStr.split(" "); // 按空格拆分
                if (dateParts.length > 0) {
                    String year = dateParts[dateParts.length - 1].trim(); // 去除年份中的空格和引号

                    yearCountMap.put(year, yearCountMap.getOrDefault(year, 0) + 1);
                }
            }
        } catch (IOException e) {
            System.err.println("读取文件失败: " + e.getMessage());
        }

        // 将统计结果写入 year_count.csv
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write("Year,Count\n");  // 写入表头
            // 按年份排序并写入文件
            yearCountMap.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(entry -> {
                        try {
//                            writer.write(entry.getKey() + "," + entry.getValue() + "\n");
                            writer.write(entry.getKey().substring(0, entry.getKey().length() - 1) + "," + entry.getValue() + "\n");

                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    });
            System.out.println("统计结果已输出到 " + outputFilePath);
        } catch (IOException e) {
            System.err.println("写入文件失败: " + e.getMessage());
        }
    }
}
