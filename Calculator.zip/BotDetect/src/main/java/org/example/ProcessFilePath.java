package org.example;

import java.io.*;
import java.util.*;

class Node {
    int index;
    String name;
    int start;
    int end;

    public Node(int index, String name, int start, int end) {
        this.index = index;
        this.name = name;
        this.start = start;
        this.end = end;
    }

    @Override
    public String toString() {
        return index + "," + name + "," + start + "," + end;
    }
}

public class ProcessFilePath {
    public static void main(String[] args) {
        ProcessFilePath processFilePath = new ProcessFilePath();
        processFilePath.process("gitdata");
    }
    public void process(String repo) {
        String csvFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/commit_changes.csv";
        String line;
        String splitBy = ",";

        Set<String> uniquePaths = new TreeSet<>();

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            br.readLine(); // 读取表头

            while ((line = br.readLine()) != null) {
                String[] columns = line.split(splitBy);
                if (columns.length < 2) continue;
                String filePath = columns[1].trim();

                String[] pathParts = filePath.split("/");

                if (pathParts.length > 1) {
                    String[] processedParts = Arrays.copyOf(pathParts, pathParts.length - 1);
                    int length = Math.min(3, processedParts.length);
                    String[] finalPathParts = Arrays.copyOf(processedParts, length);
                    String finalPath = String.join("/", finalPathParts);
                    uniquePaths.add(finalPath);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        List<Node> l1 = new ArrayList<>();
        List<Node> l2 = new ArrayList<>();
        List<Node> l3 = new ArrayList<>();

        int i = 0;
        String prevC1 = null, prevC2 = null;

        for (String path : uniquePaths) {
            String[] parts = path.split("/");
            String c1 = parts.length > 0 ? parts[0] : "";
            String c2 = parts.length > 1 ? parts[1] : "";
            String c3 = parts.length > 2 ? parts[2] : "";

            if (i == 0 || !c1.equals(prevC1)) {
                l1.add(new Node(l1.size(), c1, i, i));
                l2.add(new Node(l2.size(), c2, i, i));
                l3.add(new Node(i, c3, -1, -1));
            } else if (!c2.equals(prevC2)) {
                l2.add(new Node(l2.size(), c2, i, i));
                l3.add(new Node(i, c3, -1, -1));
                l1.get(l1.size() - 1).end++;
            } else {
                l3.add(new Node(i, c3, -1, -1));
                l2.get(l2.size() - 1).end++;
            }

            prevC1 = c1;
            prevC2 = c2;
            i++;
        }

        int l1Size = l1.size();
        int l2Size = l2.size();

        // 更新索引偏置量
        List<Node> newL1 = new ArrayList<>();
        for (Node node : l1) {
            newL1.add(new Node(node.index, node.name, node.start + l1Size, node.end + l1Size));
        }

        List<Node> newL2 = new ArrayList<>();
        for (Node node : l2) {
            newL2.add(new Node(node.index + l1Size, node.name, node.start + l1Size + l2Size, node.end + l1Size + l2Size));
        }

        List<Node> newL3 = new ArrayList<>();
        for (Node node : l3) {
            newL3.add(new Node(node.index + l1Size + l2Size, node.name, node.start, node.end));
        }

        try (BufferedWriter writer = new BufferedWriter(
                new FileWriter("/root/workspace/wbh/BotDetect/data/" + repo + "/TreeStru.txt"))) {
            writer.write("0,,1,"+(l1.size())+"\n");
//            System.out.println("0,,1,"+(l1.size()+1));
            printList("L1", newL1, writer);
            printList("L2", newL2, writer);
            printList("L3", newL3, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void printList(String label, List<Node> list, BufferedWriter writer) throws IOException {
//        writer.write(label + ":\n");
        for (Node node : list) {
            writer.write(node.toString() + "\n");
        }
        writer.write("\n");
    }
}
