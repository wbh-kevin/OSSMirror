package org.example;

import java.sql.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class MergeUsers {
    private static Map<String, Set<String>> emailNames = new HashMap<>();
    private static Map<String, Set<String>> nameEmails = new HashMap<>();
    private static Map<Integer, List<Set<String>>> idEmailsNames = new HashMap<>();

    public static void main(String[] args) throws SQLException, IOException {
        // 数据库连接信息
        String url = "jdbc:mysql://localhost:3306";
        String user = "root";
        String password = "password";

        // 读取数据库中的提交记录并填充 emailNames 和 nameEmails
        readFromDatabase(url, user, password);
//        System.out.println("READ");
        // 写入 rs1.txt 文件并构建 idEmailsNames
//        writeRs1("rs1.txt");
//        System.out.println("WRITE 1");
        // 合并重复的用户
        mergeUsers();

        // 写入 rs2.txt 文件
        writeRs2("rs2.txt");
    }

    private static void readFromDatabase(String url, String user, String password) throws SQLException {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // 建立与数据库的连接
            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();

            // 执行 SQL 查询，假设表结构为：commits (cosha, cname, cemail, aname, aemail)
            String query = "SELECT rev, committer_name, committer_email, author_name, author_email FROM oss_projects_50.linux_commits";
            resultSet = statement.executeQuery(query);

            // 遍历查询结果并更新 emailNames 和 nameEmails
            while (resultSet.next()) {
                String rev = resultSet.getString("rev");  // 提交哈希，未使用
                String cname = resultSet.getString("committer_name");  // 提交者名字
                String cemail = resultSet.getString("committer_email"); // 提交者邮件
                String aname = resultSet.getString("author_name");  // 作者名字
                String aemail = resultSet.getString("author_email"); // 作者邮件

                if (cemail != null && !cemail.isEmpty()) {
                    emailNames.putIfAbsent(cemail, new HashSet<>());
                    if (cname != null && !cname.isEmpty()) {
                        emailNames.get(cemail).add(cname);
                    }
                }
                if (aemail != null && !aemail.isEmpty()) {
                    emailNames.putIfAbsent(aemail, new HashSet<>());
                    if (aname != null && !aname.isEmpty()) {
                        emailNames.get(aemail).add(aname);
                    }
                }
                if (cname != null && !cname.isEmpty()) {
                    nameEmails.putIfAbsent(cname, new HashSet<>());
                    if (cemail != null && !cemail.isEmpty()) {
                        nameEmails.get(cname).add(cemail);
                    }
                }
                if (aname != null && !aname.isEmpty()) {
                    nameEmails.putIfAbsent(aname, new HashSet<>());
                    if (aemail != null && !aemail.isEmpty()) {
                        nameEmails.get(aname).add(aemail);
                    }
                }
            }
        } finally {
            // 关闭数据库连接
            if (resultSet != null) resultSet.close();
            if (statement != null) statement.close();
            if (connection != null) connection.close();
        }
    }

    private static void writeRs1(String filePath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath), StandardCharsets.UTF_8)) {
            int id = 1;
            for (Map.Entry<String, Set<String>> entry : emailNames.entrySet()) {
                String email = entry.getKey();
                Set<String> names = entry.getValue();
                writer.write(id + ":" + email + ":" + String.join(";", names) + "\n");
                idEmailsNames.put(id, Arrays.asList(new HashSet<>(Collections.singleton(email)), names));
                id++;
            }

            for (Map.Entry<String, Set<String>> entry : nameEmails.entrySet()) {
                String name = entry.getKey();
                Set<String> emails = entry.getValue();
                idEmailsNames.put(id, Arrays.asList(emails, new HashSet<>(Collections.singleton(name))));
                id++;
            }
        }
    }

    private static void mergeUsers() {
        boolean stop;
        int upid = idEmailsNames.size() + 1;
        int time = 0;
        do {
            stop = true;
            for (int i = 1; i < upid; i++) {
                if (idEmailsNames.containsKey(i)) {
                    for (int j = i + 1; j < upid; j++) {
                        if (idEmailsNames.containsKey(j)) {
                            Set<String> emailsI = idEmailsNames.get(i).get(0);
                            Set<String> namesI = idEmailsNames.get(i).get(1);
                            Set<String> emailsJ = idEmailsNames.get(j).get(0);
                            Set<String> namesJ = idEmailsNames.get(j).get(1);
                            time++;
                            if (time%10000000==0){
                                System.out.println(time/10000000);
                            }
                            if (!Collections.disjoint(emailsI, emailsJ) || !Collections.disjoint(namesI, namesJ)) {
                                stop = false;
                                emailsI.addAll(emailsJ);
                                namesI.addAll(namesJ);
                                idEmailsNames.remove(j);
                            }
                        }
                    }
                }
            }
        } while (!stop);
    }

    private static void writeRs2(String filePath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath), StandardCharsets.UTF_8)) {
            int a = 23370;
            for (Map.Entry<Integer, List<Set<String>>> entry : idEmailsNames.entrySet()) {
                a++;
                Set<String> emails = entry.getValue().get(0);
                Set<String> names = entry.getValue().get(1);
                writer.write(a + "#" + String.join(";", emails) + "#" + String.join(";", names) + "\n");
            }
        }
    }
}
