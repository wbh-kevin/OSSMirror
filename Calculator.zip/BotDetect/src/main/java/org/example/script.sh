#!/bin/bash
# 输出 "Hello"
echo "Hello"