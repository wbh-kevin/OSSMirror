package org.example;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.lib.ProgressMonitor;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;

import java.io.File;
import java.io.IOException;

import static org.example.Main.extractRepoName;

public class InitGitData {

    // 克隆Git仓库
    public void cloneRepository(String repoUrl, String localDir) {
        try {
            // 检查目标目录是否存在并清空
            File directory = new File(localDir);
            if (directory.exists()) {
                deleteDirectory(directory); // 清空目录内容
            } else {
                directory.mkdirs(); // 如果目标目录不存在，则创建它
            }
            System.out.println("Deleted");

            // 使用自定义的 ProgressMonitor 来显示进度
            ProgressMonitor progressMonitor = new ProgressMonitor() {
                @Override
                public void start(int totalTasks) {
                    System.out.println("Starting cloning process...");
                }

                @Override
                public void beginTask(String title, int totalWork) {
                    System.out.println(title + " - Total work: " + totalWork);
                }

                @Override
                public void update(int completed) {
//                    System.out.print("\rProgress: " + completed + "...");
                }

                @Override
                public void endTask() {
                    System.out.println("\nCloning process completed.");
                }

                @Override
                public boolean isCancelled() {
                    return false; // You can implement cancellation logic if needed
                }

                @Override
                public void showDuration(boolean b) {

                }
            };

            // 克隆Git仓库并使用ProgressMonitor
            System.out.println("Cloning repository from: " + repoUrl);
            Git.cloneRepository()
                    .setURI(repoUrl)
                    .setDirectory(directory) // 设置克隆到的目标目录
                    .setProgressMonitor(progressMonitor) // 设置进度监控
                    .call(); // 执行克隆操作

            System.out.println("Repository cloned successfully into: " + localDir);

        } catch (Exception e) {
            System.err.println("Error cloning repository: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // 删除目录及其中的文件
    private void deleteDirectory(File directory) throws IOException {
        if (directory.exists()) {
            for (File file : directory.listFiles()) {
                if (file.isDirectory()) {
                    deleteDirectory(file); // 如果是文件夹，则递归删除
                } else {
                    file.delete(); // 删除文件
                }
            }
            directory.delete(); // 删除目录
        }
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        InitGitData initGitData = new InitGitData();
        String repoUrl = "https://github.com/wbh-tmod/WBHMODE.git";  // 替换为实际的Git仓库地址
        String formattedRepoName = extractRepoName(repoUrl);
//        System.out.println("Formatted Repo Name: " + formattedRepoName);
//        String localDir = "gitdata"; // 克隆到的本地目录
        String localDir = formattedRepoName;
        initGitData.clone2(repoUrl, localDir);
    }

    public void clone2(String repoUrl, String localDir) throws IOException, InterruptedException {
        // 检查目标目录是否存在并清空
        File directory = new File(localDir);
        if (directory.exists()) {
            deleteDirectory(directory); // 清空目录内容
        }
        System.out.println("Deleted");
        // 构造命令
        String[] cmd = {"/bin/bash", "/root/workspace/wbh/BotDetect/src/main/java/org/example/clone2.sh", repoUrl, localDir};
        System.out.println(repoUrl);
        System.out.println(localDir);

        // 创建进程
        Process process = new ProcessBuilder(cmd)
                .inheritIO() // 继承标准输入输出，可看到脚本输出
                .start();

        // 等待执行完成
        int exitCode = process.waitFor();

        if (exitCode != 0) {
            throw new RuntimeException("Git clone 脚本执行失败，退出码: " + exitCode);
        }
    }
}
