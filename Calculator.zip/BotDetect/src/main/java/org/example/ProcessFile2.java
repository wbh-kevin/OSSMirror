package org.example;

import java.io.*;
import java.util.*;

public class ProcessFile2 {
    public static void main(String[] args) {
        ProcessFile2 processFile2 = new ProcessFile2();
        processFile2.process("gitdata");
    }
    public void process(String repo) {
        String inputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/TreeStru.txt";
        String outputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/NewTS.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String line;
            boolean firstLine = true;

            while ((line = br.readLine()) != null) {
                // 保留第一行原封不动
                if (firstLine) {
                    writer.write(line + "\n");
                    firstLine = false;
                } else {
                    // 对其余行进行处理
                    String[] parts = line.split(",");
                    if (parts.length == 4) {
                        try {
                            // 将数字部分转换为整数并加 1
                            int index = Integer.parseInt(parts[0]);
                            String name = parts[1];
                            int start = Integer.parseInt(parts[2]);
                            int end = Integer.parseInt(parts[3]);
                            if (index != -1) index += 1;
                            if (start != -1) start += 1;
                            if (end != -1) end += 1;

                            // 重新构造更新后的行
                            String updatedLine = index + "," + name + "," + start + "," + end;
                            writer.write(updatedLine + "\n");
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
