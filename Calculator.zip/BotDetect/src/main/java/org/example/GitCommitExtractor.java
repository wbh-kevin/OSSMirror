package org.example;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.diff.Edit;
import org.eclipse.jgit.diff.EditList;
import org.eclipse.jgit.diff.RawTextComparator;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.treewalk.AbstractTreeIterator;
import org.eclipse.jgit.treewalk.CanonicalTreeParser;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class GitCommitExtractor {

    public void getDiff(String repo) {
        String rootDirectory = System.getProperty("user.dir");

        // 定义现有仓库路径：程序根目录下的 "gitdata" 文件夹
        String repoDirectoryPath = "/root/workspace/wbh/BotDetect/" + repo;
        String repoPath = "/root/workspace/wbh/BotDetect/" + repo; // 本地 Git 仓库路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/commit_changes.csv"; // 输出 CSV 文件路径

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            // 写入 CSV 表头
            writer.write("commit_sha,file_path,added_lines,deleted_lines\n");

            // 打开仓库
            Git git = Git.open(new File(repoPath));
            Repository repository = git.getRepository();

            // 遍历每个 commit
            Iterable<RevCommit> commits = git.log().call();
            int i = 0;
            for (RevCommit commit : commits) {
                i = i + 1;
                if (i%1000 == 0){
                    System.out.println(i/1000);
                }
                if (commit.getParentCount() == 0) continue; // 跳过没有父 commit 的 commit

                // 获取当前 commit 和父 commit 的树
                AbstractTreeIterator parentTree = prepareTreeParser(repository, commit.getParent(0));
                AbstractTreeIterator commitTree = prepareTreeParser(repository, commit);

                // 比较差异
                try (DiffFormatter diffFormatter = new DiffFormatter(new ByteArrayOutputStream())) {
                    diffFormatter.setRepository(repository);
                    diffFormatter.setDiffComparator(RawTextComparator.DEFAULT);
                    diffFormatter.setDetectRenames(true);

                    List<DiffEntry> diffs = diffFormatter.scan(parentTree, commitTree);
                    for (DiffEntry diff : diffs) {
                        int addedLines = 0;
                        int deletedLines = 0;

                        EditList editList = diffFormatter.toFileHeader(diff).toEditList();
                        for (Edit edit : editList) {
                            addedLines += edit.getEndB() - edit.getBeginB();
                            deletedLines += edit.getEndA() - edit.getBeginA();
                        }

                        // 写入 CSV 文件
                        String csvLine = String.format("%s,%s,%d,%d\n",
                                commit.getName(),
                                diff.getNewPath(),
                                addedLines,
                                deletedLines);
                        writer.write(csvLine);
                    }
                }
            }

            System.out.println("数据已成功写入到: " + outputFilePath);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 准备树解析器
    private static AbstractTreeIterator prepareTreeParser(Repository repository, RevCommit commit) throws Exception {
        CanonicalTreeParser treeParser = new CanonicalTreeParser();
        try (var reader = repository.newObjectReader()) {
            treeParser.reset(reader, commit.getTree().getId());
        }
        return treeParser;
    }
}
