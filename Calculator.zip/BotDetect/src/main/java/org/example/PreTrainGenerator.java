package org.example;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class PreTrainGenerator {
    public static void main(String[] args) {
        PreTrainGenerator preTrainGenerator = new PreTrainGenerator();
//        String spDate = "Mon Mar 17 06:55:17 CST 2025"; // 示例传递的日期
        preTrainGenerator.start("torvalds-linux");
    }

    public void start(String repo) {
        GitTagChecker gitTagChecker = new GitTagChecker();
//        String spDate = gitTagChecker.printLatestTagDate(repo);
        String spDate = "Mon Jan 01 00:00:00 CST 2024";

        String inputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/filtered_git_log.csv"; // 输入文件路径
        String outputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/pre_train.csv";       // 输出文件路径

        try {
            // 使用 Locale.US 解析英文月份、星期及时区缩写
            SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);
            Date startDate = dateFormat.parse(spDate);

            extractData(inputFile, outputFile, startDate);
            System.out.println("Data extraction complete. Output written to " + outputFile);
        } catch (IOException | ParseException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
    }

    /**
     * 提取指定的字段并写入新文件，只有当 authorDate 晚于 spDate 时才写入
     */
    private void extractData(String inputFile, String outputFile, Date spDate) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

        String line;
        boolean isFirstLine = true;

        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.US);

        while ((line = reader.readLine()) != null) {
            String[] fields = line.split(",", -1);

            if (isFirstLine) {
                isFirstLine = false;
                writer.write("sha,message,author_date");
                writer.newLine();
                continue;
            }

            String sha = fields[0];
            String message = fields[6];
            String authorDateStr = fields[4].replaceAll("^\"|\"$", ""); // 去除首尾引号

            try {
                Date authorDate = dateFormat.parse(authorDateStr);
                if (authorDate.after(spDate)) {
                    writer.write(String.format("%s,%s,%s", sha, message, fields[4])); // 保留原始 authorDateStr 的格式
                    writer.newLine();
                }
            } catch (ParseException e) {
                System.err.println("Error parsing date: " + authorDateStr);
            }
        }

        reader.close();
        writer.close();
    }

}
