package org.example;

import java.io.IOException;

public class Main {
//    public static void main(String[] args) throws IOException {
//        work();
//    }
    public static void main(String[] args) throws IOException, InterruptedException {
        // InitGitData          导入仓库数据
        // GitLogExtrator       获取提交日期人名等信息
        // BotAuthorFilter2     清除机器账户
        // MergeUsers2          合并用户
        // SetUserID2           设置用户组下各个账户
        // GetDomain            获取邮箱域名
        // GitCommitExtractor   获取修改文件的路径信息
        // GetOrgFromMail       获取邮箱域名
        // GetOrg               获取邮箱所属公司
//        System.out.println("USER DIR:");
//        System.out.println(System.getProperty("user.dir"));
        System.setProperty("user.dir", "/root/workspace/wbh/BotDetect/src/main/java/org/example");

        ShowSchedule showSchedule = new ShowSchedule();

        InitGitData initGitData = new InitGitData();
        String repoUrl = "https://github.com/torvalds/linux.git";  // 替换为实际的Git仓库地址
//        repoUrl = "https://github.com/OPENHarmonydev/openharmony.git";
        repoUrl = args[0];
        String formattedRepoName = extractRepoName(repoUrl);
        System.out.println("Formatted Repo Name: " + formattedRepoName);
//        String localDir = "gitdata"; // 克隆到的本地目录
        String localDir = formattedRepoName;
        if (!showSchedule.check(localDir) || showSchedule.check2(localDir)){
            if (showSchedule.checkEmpty()) {
                if (!showSchedule.check(localDir)){
                    showSchedule.add(localDir);
                }
                initGitData.clone2(repoUrl, localDir);
                GitLogExtractor gitLogExtractor = new GitLogExtractor();
                gitLogExtractor.extractor(localDir);

                showSchedule.update(localDir);

                BotAuthorFilter2 filter = new BotAuthorFilter2();
                filter.detectBotAuthor(localDir);  // 检测并处理机器人作者

                MergeUsers2 mergeUsers2 = new MergeUsers2();
                mergeUsers2.merge(localDir);

                showSchedule.update(localDir);

                SetUserID2 setUserID2 = new SetUserID2();
                setUserID2.setID(localDir);

                GitCommitExtractor gitCommitExtractor = new GitCommitExtractor();
                gitCommitExtractor.getDiff(localDir);

                CommitChangesProcessor commitChangesProcessor = new CommitChangesProcessor();
                commitChangesProcessor.processCommit(localDir);

                GetOrgFromMail getOrgFromMail = new GetOrgFromMail();
                getOrgFromMail.getOrg(localDir);

                showSchedule.update(localDir);

                GetOrg getOrg = new GetOrg();
                getOrg.getO(localDir);

                CSVProcessor csvProcessor = new CSVProcessor();
                csvProcessor.csvProcess(localDir);

                MailCompanyProcessor mailCompanyProcessor = new MailCompanyProcessor();
                mailCompanyProcessor.companyProcess(localDir);

                showSchedule.update(localDir);

                CsvMerger csvMerger = new CsvMerger();
                csvMerger.mergeCSV(localDir);

                ContributionCalculator contributionCalculator = new ContributionCalculator();
                contributionCalculator.CICal(localDir);

//        ContributionBreadthCalculator contributionBreadthCalculator = new ContributionBreadthCalculator();
//        contributionBreadthCalculator.CECal(localDir);

                showSchedule.update(localDir);

                CompanyModuleAnalyzer companyModuleAnalyzer = new CompanyModuleAnalyzer();
                companyModuleAnalyzer.moduleCal(localDir);

                CsvRevMerger csvRevMerger = new CsvRevMerger();
                csvRevMerger.mergeRev(localDir);

                showSchedule.update(localDir);

                CompanyCollaborationAnalyzer companyCollaborationAnalyzer = new CompanyCollaborationAnalyzer();
                companyCollaborationAnalyzer.collabCal(localDir);

                ContributorDependencyAnalyzer contributorDependencyAnalyzer = new ContributorDependencyAnalyzer();
                contributorDependencyAnalyzer.dependencyAnalyze(localDir);

                showSchedule.update(localDir);

                CompanyDominatedModulesAnalyzer companyDominatedModulesAnalyzer = new CompanyDominatedModulesAnalyzer();
                companyDominatedModulesAnalyzer.dominationAnalyze(localDir);

                CsvStatistic csvStatistic = new CsvStatistic();
                csvStatistic.csvStatistic(localDir);

                showSchedule.update(localDir);

                MonthCount monthCount = new MonthCount();
                monthCount.monthCount(localDir);

                YearCount yearCount = new YearCount();
                yearCount.yearCount(localDir);

                ProcessFilePath processFilePath = new ProcessFilePath();
                processFilePath.process(localDir);

                ProcessFile2 processFile2 = new ProcessFile2();
                processFile2.process(localDir);

                showSchedule.update(localDir);

                PreTrainGenerator preTrainGenerator = new PreTrainGenerator();
                preTrainGenerator.start(localDir);

                CsvAllMerger csvAllMerger = new CsvAllMerger();
                csvAllMerger.mergeCSV(localDir);

                CPFile cpFile = new CPFile();
                cpFile.copyFilesToWorkspace(localDir);

                PyStarter pyStarter = new PyStarter();
//        pyStarter.executeScriptAsync();
//        pyStarter.runScript();
                pyStarter.runScript2();

                cpFile.copyFileToRepo(localDir);

                MailCompanyWordCount mailCompanyWordCount = new MailCompanyWordCount();
                mailCompanyWordCount.work(localDir);

                RiskCalculator riskCalculator = new RiskCalculator();
                riskCalculator.work(localDir);

                showSchedule.update(localDir);
            }
        }
//
//        OSUtils osUtils = new OSUtils();
//        osUtils.out();
    }

    public static void work() throws IOException {
        InitGitData initGitData = new InitGitData();
        String repoUrl = "https://github.com/torvalds/linux.git";  // 替换为实际的Git仓库地址
        repoUrl = "https://github.com/OPENHarmonydev/openharmony.git";
//        repoUrl = args[0];
        String formattedRepoName = extractRepoName(repoUrl);
        System.out.println("Formatted Repo Name: " + formattedRepoName);
//        String localDir = "gitdata"; // 克隆到的本地目录
        String localDir = formattedRepoName;
//        initGitData.cloneRepository(repoUrl, localDir);
        GitLogExtractor gitLogExtractor = new GitLogExtractor();
        gitLogExtractor.extractor(localDir);

//        showSchedule.update(localDir);

        BotAuthorFilter2 filter = new BotAuthorFilter2();
        filter.detectBotAuthor(localDir);  // 检测并处理机器人作者

        MergeUsers2 mergeUsers2 = new MergeUsers2();
        mergeUsers2.merge(localDir);

//        showSchedule.update(localDir);

        SetUserID2 setUserID2 = new SetUserID2();
        setUserID2.setID(localDir);

        GitCommitExtractor gitCommitExtractor = new GitCommitExtractor();
        gitCommitExtractor.getDiff(localDir);

        CommitChangesProcessor commitChangesProcessor = new CommitChangesProcessor();
        commitChangesProcessor.processCommit(localDir);

        GetOrgFromMail getOrgFromMail = new GetOrgFromMail();
        getOrgFromMail.getOrg(localDir);

//        showSchedule.update(localDir);

        GetOrg getOrg = new GetOrg();
        getOrg.getO(localDir);

        CSVProcessor csvProcessor = new CSVProcessor();
        csvProcessor.csvProcess(localDir);

        MailCompanyProcessor mailCompanyProcessor = new MailCompanyProcessor();
        mailCompanyProcessor.companyProcess(localDir);

//        showSchedule.update(localDir);

        CsvMerger csvMerger = new CsvMerger();
        csvMerger.mergeCSV(localDir);

        ContributionCalculator contributionCalculator = new ContributionCalculator();
        contributionCalculator.CICal(localDir);

//        ContributionBreadthCalculator contributionBreadthCalculator = new ContributionBreadthCalculator();
//        contributionBreadthCalculator.CECal(localDir);

//        showSchedule.update(localDir);

        CompanyModuleAnalyzer companyModuleAnalyzer = new CompanyModuleAnalyzer();
        companyModuleAnalyzer.moduleCal(localDir);

        CsvRevMerger csvRevMerger = new CsvRevMerger();
        csvRevMerger.mergeRev(localDir);

//        showSchedule.update(localDir);

        CompanyCollaborationAnalyzer companyCollaborationAnalyzer = new CompanyCollaborationAnalyzer();
        companyCollaborationAnalyzer.collabCal(localDir);

        ContributorDependencyAnalyzer contributorDependencyAnalyzer = new ContributorDependencyAnalyzer();
        contributorDependencyAnalyzer.dependencyAnalyze(localDir);

//        showSchedule.update(localDir);

        CompanyDominatedModulesAnalyzer companyDominatedModulesAnalyzer = new CompanyDominatedModulesAnalyzer();
        companyDominatedModulesAnalyzer.dominationAnalyze(localDir);

        CsvStatistic csvStatistic = new CsvStatistic();
        csvStatistic.csvStatistic(localDir);

//        showSchedule.update(localDir);

        MonthCount monthCount = new MonthCount();
        monthCount.monthCount(localDir);

        YearCount yearCount = new YearCount();
        yearCount.yearCount(localDir);

        ProcessFilePath processFilePath = new ProcessFilePath();
        processFilePath.process(localDir);

        ProcessFile2 processFile2 = new ProcessFile2();
        processFile2.process(localDir);

//        showSchedule.update(localDir);

        PreTrainGenerator preTrainGenerator = new PreTrainGenerator();
        preTrainGenerator.start(localDir);

        CsvAllMerger csvAllMerger = new CsvAllMerger();
        csvAllMerger.mergeCSV(localDir);

        CPFile cpFile = new CPFile();
        cpFile.copyFilesToWorkspace(localDir);

        PyStarter pyStarter = new PyStarter();
//        pyStarter.executeScriptAsync();
//        pyStarter.runScript();
        pyStarter.runScript2();

        cpFile.copyFileToRepo(localDir);

        MailCompanyWordCount mailCompanyWordCount = new MailCompanyWordCount();
        mailCompanyWordCount.work(localDir);

        RiskCalculator riskCalculator = new RiskCalculator();
        riskCalculator.work(localDir);

//        showSchedule.update(localDir);
    }

    /**
     * 从 repoUrl 提取最后两个部分，并用 "-" 连接
     */
    public static String extractRepoName(String repoUrl) {
        if (repoUrl == null || !repoUrl.contains("/")) {
            return "invalid-repo";
        }

        // 移除结尾的 ".git"（如果存在）
        if (repoUrl.endsWith(".git")) {
            repoUrl = repoUrl.substring(0, repoUrl.length() - 4);
        }

        // 拆分 URL
        String[] parts = repoUrl.split("/");

        // 确保至少有两个部分
        if (parts.length < 2) {
            return "invalid-repo";
        }

        // 获取最后两个部分
        String lastPart = parts[parts.length - 1]; // 仓库名
        String secondLastPart = parts[parts.length - 2]; // 组织或用户名称

        // 连接并返回
        return secondLastPart + "-" + lastPart;
    }
}