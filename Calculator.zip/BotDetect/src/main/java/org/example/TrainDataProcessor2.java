package org.example;

import java.io.*;
import java.util.*;

public class TrainDataProcessor2 {
    public static void main(String[] args) {
        TrainDataProcessor2 trainDataProcessor2 = new TrainDataProcessor2();
        trainDataProcessor2.process("torvalds-linux");
    }
    public void process(String repo) {
        // 输入输出文件路径
        String userIdCompanyCsv = "userid_company.csv";
        String trainOutCsv = "train_out.csv";
        String outputCsv = "joined_output.csv";

        // Step 1: 读取 userid_company.csv 并将其存入 Map，以 sha 为 key，mailcompany 为 value
        Map<String, String> shaToMailCompanyMap = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(userIdCompanyCsv))) {
            String line;
            reader.readLine(); // 跳过表头

            // 读取每一行，并将 sha 和 mailcompany 存入 Map
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 6) {  // 确保每行数据有 6 列
                    String sha = fields[0].trim();
                    String mailCompany = fields[5].trim();
                    shaToMailCompanyMap.put(sha, mailCompany);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Step 2: 读取 train_out.csv 并输出连接后的结果到 joined_output.csv
        try (BufferedReader reader = new BufferedReader(new FileReader(trainOutCsv));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputCsv))) {
            String line;
            reader.readLine(); // 跳过表头

            // 写入输出文件的表头
            writer.write("sha,mailcompany,word");
            writer.newLine();

            // 读取 train_out.csv 中每一行并进行连接
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 3) {  // 确保每行数据有 3 列
                    String sha = fields[0].trim().replaceAll("^\"|\"$", "");
                    String word = fields[2].trim();

                    // 如果 sha 在 shaToMailCompanyMap 中找到对应的 mailcompany，则输出
                    if (shaToMailCompanyMap.containsKey(sha)) {
                        String mailCompany = shaToMailCompanyMap.get(sha);
                        writer.write(sha + "," + mailCompany + "," + word);
                        writer.newLine();
                    }
                }
            }

            System.out.println("数据处理完毕，结果存储在 " + outputCsv);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
