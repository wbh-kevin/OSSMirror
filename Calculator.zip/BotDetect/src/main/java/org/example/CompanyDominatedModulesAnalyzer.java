package org.example;

import java.io.*;
import java.util.*;

public class CompanyDominatedModulesAnalyzer {

    public void dominationAnalyze(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_one.csv"; // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/company_dominated_modules.csv"; // 输出文件路径

        try {
            analyzeCompanyDominatedModules(inputFilePath, outputFilePath);
            System.out.println("Analysis complete. Results written to: " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error processing the file: " + e.getMessage());
        }
    }

    /**
     * 分析公司主导的模块。
     */
    private void analyzeCompanyDominatedModules(String inputFilePath, String outputFilePath) throws IOException {
        // 数据结构：模块 -> 公司 -> 贡献行数
        Map<String, Map<String, Integer>> moduleContributions = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath))) {
            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // 跳过表头
                }

                String[] fields = line.split(",", -1);
                if (fields.length < 10) {
                    continue; // 跳过格式不正确的行
                }

                String mailCompany = fields[5]; // mailcompany 列
                String filePath = fields[6]; // file_path 列
                int addedLines = parseInteger(fields[7]); // added_lines 列
                int deletedLines = parseInteger(fields[8]); // deleted_lines 列

                // 计算贡献行数
                int totalLinesChanged = 1;

                // 更新模块和公司的贡献统计
                moduleContributions
                        .computeIfAbsent(filePath, k -> new HashMap<>()) // file_path 为键
                        .merge(mailCompany, totalLinesChanged, Integer::sum); // 累加行数
            }
        }

        // 写入分析结果
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write("Module,Company,TotalContributions,CompanyContributions,ContributionPercentage");
            writer.newLine();

            for (Map.Entry<String, Map<String, Integer>> moduleEntry : moduleContributions.entrySet()) {
                String module = moduleEntry.getKey(); // 模块路径
                Map<String, Integer> companyContributions = moduleEntry.getValue();

                // 计算模块的总贡献行数
                int totalContributions = companyContributions.values().stream().mapToInt(Integer::intValue).sum();

                // 判断主导公司
                for (Map.Entry<String, Integer> companyEntry : companyContributions.entrySet()) {
                    String company = companyEntry.getKey();
                    int companyContribution = companyEntry.getValue();
                    double contributionPercentage = (companyContribution / (double) totalContributions) * 100;

                    if (contributionPercentage > 1.0) { // 判断是否主导
                        writer.write(String.format("%s,%s,%d,%d,%.2f%%",
                                module, company, totalContributions, companyContribution, contributionPercentage));
                        writer.newLine();
                    }
                }
            }
        }
    }

    /**
     * 将字符串转换为整数，若失败则返回 0。
     */
    private int parseInteger(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
