package org.example;

import java.io.*;
import java.util.*;

public class GetOrgFromMail {

    // 定义100个常见的邮箱域名
    private final Set<String> emailDomains = loadEmailDomains("/root/workspace/wbh/BotDetect/data/freeEmail.txt");

    private Set<String> loadEmailDomains(String filePath) {
        Set<String> domains = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    domains.add(line.toLowerCase());
                }
            }
        } catch (IOException e) {
            e.printStackTrace(); // 可以替换为日志记录
        }
        return domains;
    }

    // 读取文件并去除匹配的行内容
    public void processFile(String inputFilePath, String outputFilePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line;
            while ((line = reader.readLine()) != null) {
                String domain = line.trim().toLowerCase();

                // 如果当前行与 emailDomains 中的某个域名完全匹配，则跳过该行
                if (!emailDomains.contains(domain)) {
                    writer.write(line);
                    writer.newLine();
                }
            }

            System.out.println("处理完成，输出已写入到：" + outputFilePath);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void getOrg(String repo) {
        // 输入输出文件路径
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/mailcompany.txt";
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/mailcompany2.txt";

        // 调用处理方法
        processFile(inputFilePath, outputFilePath);
    }
}
