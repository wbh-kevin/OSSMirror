package org.example;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

class ContributionBreadthCalculator {
    public void CECal(String repo) {
        String csvFile = "data/" + repo + "/merged_one.csv";
        String outputFile = "data/" + repo + "/CE.txt"; // 输出文件路径
        String line;
        String csvSplitBy = ",";
        SimpleDateFormat originalDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
        SimpleDateFormat monthFormat = new SimpleDateFormat("yyyy-MM");
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");

        // Maps to store breadth data
        Map<String, Set<String>> companyModules = new HashMap<>(); // Company -> Unique modules
        Map<String, Set<String>> companyMonths = new HashMap<>();  // Company -> Unique months
        Map<String, Set<String>> companyYears = new HashMap<>();   // Company -> Unique years

        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            // Read header
            line = br.readLine(); // Skip the header line
            if (line == null || !line.startsWith("rev")) {
                throw new IOException("Invalid CSV file or missing headers");
            }

            // Read file
            while ((line = br.readLine()) != null) {
                String[] values = line.split(csvSplitBy);

                if (values.length != 10) { // Check for the new column count
                    continue; // Skip invalid lines
                }

                String authorDate = values[3]; // author_date
                String mailCompany = values[5]; // mailcompany
                String filePath = values[6]; // file_path

                // Parse dates into month and year
                Date date = originalDateFormat.parse(authorDate);
                String monthKey = monthFormat.format(date);
                String yearKey = yearFormat.format(date);

                // Track unique modules for each company
                companyModules.computeIfAbsent(mailCompany, k -> new HashSet<>()).add(filePath);

                // Track unique months for each company
                companyMonths.computeIfAbsent(mailCompany, k -> new HashSet<>()).add(monthKey);

                // Track unique years for each company
                companyYears.computeIfAbsent(mailCompany, k -> new HashSet<>()).add(yearKey);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Write results to CE.txt
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
            bw.write("Contribution Breadth by Company:\n\n");
            writeBreadthData(bw, companyModules, "Modules");
            writeBreadthData(bw, companyMonths, "Months");
            writeBreadthData(bw, companyYears, "Years");
            System.out.println("Results written to " + outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Write breadth data to file
    private void writeBreadthData(BufferedWriter bw, Map<String, Set<String>> data, String unit) throws IOException {
        bw.write("Breadth by " + unit + ":\n");
        for (Map.Entry<String, Set<String>> entry : data.entrySet()) {
            String company = entry.getKey();
            int count = entry.getValue().size();
            bw.write(String.format("  Company: %s, Unique %s: %d%n", company, unit, count));
        }
        bw.write("\n");
    }
}
