package org.example;

import java.sql.*;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BotAuthorFilter {

    private static final String DB_URL = "jdbc:mysql://localhost:3306";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "password";

    // 文件路径
    private static final String BOT_BASE_FILE = "data/botBase";
    private static final String BOT_NAME_FILE = "data/botName";
    private static final String BOT_EMAIL_FILE = "data/botEmail";
    private static final String BOT_LIST_FILE = "data/botlist";

    // 模式匹配
    private static final Pattern BOT_PATTERN = Pattern.compile("([\\W0-9_]robot$)|(^robot[\\W0-9_])|([\\W0-9_]robot[\\W0-9_])", Pattern.CASE_INSENSITIVE);

    private Set<String> botBaseSet = new HashSet<>();
    private Set<String> botNameSet = new HashSet<>();
    private Set<String> botEmailSet = new HashSet<>();
    private Set<String> botListSet = new HashSet<>();

    private static final Set<String> botAuthors = new HashSet<>();

    private Connection conn;
    private Statement stmt;

    public BotAuthorFilter(){
        try{
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            stmt = conn.createStatement();
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    public void detectBotAuthor(){
//        BotAuthorFilter filter = new BotAuthorFilter();
        loadBotData();
        processAuthors();
    }

    public void removeBotAuthor(){
        try {
            for (String authorId : botAuthors) {
                // 拆分 authorId，假设格式为 "authorName<authorEmail>"
                String[] parts = authorId.split("<");
                String authorName = parts[0];
                String authorEmail = parts[1].replace(">", ""); // 去除 '>' 字符

                // 3. 构建 SQL DELETE 语句
                String deleteSQL = "DELETE FROM oss_projects_50.linux_commits WHERE author_name = ? AND author_email = ?";

                // 4. 创建 PreparedStatement
                PreparedStatement preparedStatement = conn.prepareStatement(deleteSQL);
                preparedStatement.setString(1, authorName);   // 设置作者名称
                preparedStatement.setString(2, authorEmail);  // 设置邮箱

                // 5. 执行删除操作
                int affectedRows = preparedStatement.executeUpdate();

                // 输出删除信息
                System.out.println("Deleted " + affectedRows + " rows for author: " + authorName + " <" + authorEmail + ">");
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    // 加载机器人数据文件
    private void loadBotData() {
        loadFileIntoSet(BOT_BASE_FILE, botBaseSet);
        loadFileIntoSet(BOT_NAME_FILE, botNameSet);
        loadFileIntoSet(BOT_EMAIL_FILE, botEmailSet);
        loadFileIntoSet(BOT_LIST_FILE, botListSet);
    }

    private void loadFileIntoSet(String filePath, Set<String> set) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                set.add(line.trim());
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + filePath);
            e.printStackTrace();
        }
    }

    // 处理数据库中的提交作者数据
    private void processAuthors() {
        try{
            String sql = "SELECT author_name, author_email FROM oss_projects_50.linux_commits"; // 修改表名为linux
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String authorName = rs.getString("author_name");
                String authorEmail = rs.getString("author_email");
                int botType = isBotAuthor(authorName, authorEmail);
                if (botType > 0) {
                    inputSet(authorName, authorEmail);
//                    System.out.println("Bot Author Detected: " + authorName + " <" + authorEmail + ">" + botType);
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    private void inputSet(String authorName, String authorEmail) {
        // 创建唯一的 authorId，包含 authorName 和 authorEmail
        String authorId = authorName + "<" + authorEmail + ">";

        // 检查是否已经处理过
        if (!botAuthors.contains(authorId)) {
            // 处理该作者
            int botType = isBotAuthor(authorName, authorEmail);

            if (botType > 0) {
                System.out.println("Bot Author Detected: " + authorName + " <" + authorEmail + ">, Type: " + botType);
            }

            // 将已处理的 authorId 添加到集合中，避免重复处理
            botAuthors.add(authorId);
        }  //            System.out.println("Author already processed: " + authorId);

    }


    // 判断提交者是否是机器人
    private int isBotAuthor(String authorName, String authorEmail) {
        if (authorName == null || authorEmail == null)
            return 0;

        String authorEmailName = authorEmail.split("@")[0];

        // 根据不同文件和模式进行判断
        if (botBaseSet.contains(authorEmail) || botBaseSet.contains(authorEmailName) || botBaseSet.contains(authorName)) {
            return 1;
        }
        if (botNameSet.contains(authorName)) {
            return 2;
        }
        if (botEmailSet.contains(authorEmail)) {
            return 3;
        }
        if (botListSet.contains(authorName) || botListSet.contains(authorEmailName)) {
            return 4;
        }
        if (BOT_PATTERN.matcher(authorName).find() || BOT_PATTERN.matcher(authorEmailName).find()) {
            return 5;
        }

        return 0;
    }
}
