package org.example;

import java.io.*;

public class RiskCalculator {

    public static void main(String[] args) {
        RiskCalculator rc = new RiskCalculator();
//        rc.calRisk("oh_all_3.csv", "single_contributor_dependency.csv", "test_predict.csv", "test_depend.csv");
        rc.work("openharmony-kernel_liteos_m");
    }

    public void work(String repo){
        String in1 = "/root/workspace/wbh/BotDetect/data/" + repo + "/oh_all_3.csv";
        String in2 = "/root/workspace/wbh/BotDetect/data/" + repo + "/single_contributor_dependency.csv";
        String out2 = "/root/workspace/wbh/BotDetect/data/" + repo + "/test_predict.csv";
        String out1 = "/root/workspace/wbh/BotDetect/data/" + repo + "/test_depend.csv";
        calRisk(in1, in2, out1, out2);
    }

    public void calRisk(String predictFile, String dependFile, String predictOut, String dependOut) {
        try {
            extractPredictData(predictFile, predictOut);
            extractDependData(dependFile, dependOut);
            System.out.println("数据处理完成！");
        } catch (IOException e) {
            System.err.println("文件处理出错: " + e.getMessage());
        }
    }

    private void extractPredictData(String inputFile, String outputFile) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

        String line;
        boolean isFirstLine = true;

        while ((line = reader.readLine()) != null) {
            if (isFirstLine) {
                isFirstLine = false;
                continue; // 跳过表头
            }

            String[] fields = line.split(",", -1);
            if (fields.length >= 2) {
                String company = fields[0].trim();
                String predictedState = fields[1].trim();
                writer.write(company + "," + predictedState);
                writer.newLine();
            }
        }

        reader.close();
        writer.close();
    }

    private void extractDependData(String inputFile, String outputFile) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(inputFile));
        BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));

        String line;
        boolean isFirstLine = true;

        while ((line = reader.readLine()) != null) {
            if (isFirstLine) {
                isFirstLine = false;
                continue; // 跳过表头
            }

            String[] fields = line.split(",", -1);
            if (fields.length >= 4) {
                String company = fields[0].trim();
                String percentageStr = fields[3].trim().replace("%", "");

                try {
                    double percentage = Double.parseDouble(percentageStr) / 100.0;
                    writer.write(company + "," + percentage);
                    writer.newLine();
                } catch (NumberFormatException e) {
                    System.err.println("无法解析百分比: " + fields[3]);
                }
            }
        }

        reader.close();
        writer.close();
    }
}
