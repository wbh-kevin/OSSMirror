package org.example;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MailCompanyProcessor {

    public void companyProcess(String repo) {
        String inputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid_processed.csv"; // 输入文件路径
        String outputFile = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid_company.csv";  // 输出文件路径

        try {
            processMailCompany(inputFile, outputFile);
            System.out.println("Processing complete. Output written to " + outputFile);
        } catch (Exception e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
    }

    private void processMailCompany(String inputFile, String outputFile) throws Exception {
        // 日期格式解析器
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);

        // 数据存储
        List<String[]> allCommits = new ArrayList<>(); // 存储所有数据（每行是 String[]）
        Map<String, List<CommitRecord>> nonPublicCommitsByUserId = new HashMap<>();
        int publicConvertedCount = 0; // 统计 public 转换为非 public 的行数

        // Step 1: 读取文件内容
        try (BufferedReader br = new BufferedReader(new FileReader(inputFile))) {
            String header = br.readLine();
            if (header == null) throw new IOException("File is empty or invalid.");

            allCommits.add(header.split(",", -1)); // 保留表头

            String line;
            while ((line = br.readLine()) != null) {
                try {
                    String[] fields = line.split(",", -1); // 保证空列也被读取

                    if (fields.length < 6) {
                        continue; // 跳过格式不正确的行
                    }

                    String authorId = fields[4];       // author_id
                    String mailCompany = fields[5];    // mailcompany
                    String commitDateStr = fields[3];  // commit_date

                    Date commitDate = dateFormat.parse(commitDateStr); // 日期解析
                    CommitRecord record = new CommitRecord(authorId, mailCompany, commitDate, fields);

                    allCommits.add(fields); // 保留整行数据

                    // 存储非 public 的记录，按 authorId 分组
                    if (!mailCompany.equals("public")) {
                        nonPublicCommitsByUserId
                                .computeIfAbsent(authorId, k -> new ArrayList<>())
                                .add(record);
                    }
                } catch (Exception e) {
                    // 跳过解析错误的行
                }
            }
        }

        // Step 2: 处理 public 数据
        List<String[]> filteredCommits = new ArrayList<>(); // 存储非 public 的记录
        filteredCommits.add(allCommits.get(0)); // 添加表头

        for (int i = 1; i < allCommits.size(); i++) { // 跳过表头，从第二行开始处理
            String[] commitFields = allCommits.get(i);
            try {
                if (commitFields.length >= 6 && commitFields[5].equals("public")) {
                    String authorId = commitFields[4];
                    String commitDateStr = commitFields[3];

                    Date commitDate = dateFormat.parse(commitDateStr);
                    String resolvedCompany = resolveMailCompany(authorId, commitDate, nonPublicCommitsByUserId);

                    if (!resolvedCompany.equals("public")) {
                        commitFields[5] = resolvedCompany; // 更新 mailcompany 字段
                        publicConvertedCount++;
                        filteredCommits.add(commitFields); // 添加到最终结果
                    }
                } else {
                    filteredCommits.add(commitFields); // 非 public 的直接添加
                }
            } catch (Exception e) {
                // 跳过解析错误的行
            }
        }

        // Step 3: 写回到新文件
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))) {
            for (String[] fields : filteredCommits) {
                bw.write(String.join(",", fields));
                bw.newLine();
            }
        }

        // 输出统计结果
        System.out.println("Total 'public' converted to non-public: " + publicConvertedCount);
        System.out.println("Total 'public' commits discarded: " + (allCommits.size() - filteredCommits.size()));
    }


    /**
     * 归属 public commit 到最合适的公司
     */
    private String resolveMailCompany(String authorId, Date commitDate,
                                      Map<String, List<CommitRecord>> nonPublicCommitsByUserId) {
        List<CommitRecord> nonPublicCommits = nonPublicCommitsByUserId.get(authorId);
        if (nonPublicCommits == null || nonPublicCommits.isEmpty()) {
            return "public"; // 如果没有匹配项，保留 public
        }

        // 查找时间差最小的非 public 记录
        CommitRecord closestCommit = null;
        long minTimeDiff = Long.MAX_VALUE;

        for (CommitRecord nonPublicCommit : nonPublicCommits) {
            long timeDiff = Math.abs(commitDate.getTime() - nonPublicCommit.commitDate.getTime());
            if (timeDiff < minTimeDiff) {
                minTimeDiff = timeDiff;
                closestCommit = nonPublicCommit;
            }
        }

        return closestCommit != null ? closestCommit.mailCompany : "public";
    }

    /**
     * CommitRecord 数据类
     */
    static class CommitRecord {
        String authorId;
        String mailCompany;
        Date commitDate;
        String[] originalFields; // 保留原始行的所有字段

        public CommitRecord(String authorId, String mailCompany, Date commitDate, String[] originalFields) {
            this.authorId = authorId;
            this.mailCompany = mailCompany;
            this.commitDate = commitDate;
            this.originalFields = originalFields;
        }
    }
}
