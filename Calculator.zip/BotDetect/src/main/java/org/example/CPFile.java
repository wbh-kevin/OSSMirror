package org.example;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class CPFile {

    // 复制文件的通用方法
    private static void copyFile(String sourcePath, String destinationPath) throws IOException {
        Path source = Paths.get(sourcePath);
        Path destination = Paths.get(destinationPath);

        // 确保目标文件夹存在
        Files.createDirectories(destination.getParent());

        // 复制文件（如果目标文件已存在，则覆盖）
        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Copied: " + sourcePath + " -> " + destinationPath);
    }

    // 将 oh_all_3.csv 复制到 data/repo/{repoPath}/
    public static void copyFileToRepo(String repoPath) {
        String sourceFile = "/root/workspace/wbh/Python/oh_company_prediction_results.csv";
        String destinationDir = "/root/workspace/wbh/BotDetect/data/" + repoPath + "/";
        String destinationFile = destinationDir + "oh_all_3.csv";

        try {
            copyFile(sourceFile, destinationFile);
        } catch (IOException e) {
            System.err.println("Error copying file to repo: " + e.getMessage());
        }

        String sourceFile2 = "/root/workspace/wbh/css-code/llm.out";
        String destinationFile2 = destinationDir + "llm.out";

        try {
            copyFile(sourceFile2, destinationFile2);
        } catch (IOException e) {
            System.err.println("Error copying llm.out to repo: " + e.getMessage());
        }
    }

    // 将 merged_one.csv 和 merged_all.csv 复制到 /root/workspace/wbh/Python/
    public static void copyFilesToWorkspace(String repoPath) {
        String sourceDir = "/root/workspace/wbh/BotDetect/data/" + repoPath + "/";
        String destinationDir1 = "/root/workspace/wbh/Python/";
        String destinationDir2 = "/root/workspace/wbh/css-code/";

        String[] filesToCopy = {"merged_one.csv", "merged_all.csv"};

        for (String fileName : filesToCopy) {
            try {
                copyFile(sourceDir + fileName, destinationDir1 + fileName);
            } catch (IOException e) {
                System.err.println("Error copying file: " + fileName + " -> " + e.getMessage());
            }
        }

        // 新增复制 pre_train.csv 到 css-code 文件夹
        try {
            copyFile(sourceDir + "pre_train.csv", destinationDir2 + "pre_train.csv");
        } catch (IOException e) {
            System.err.println("Error copying pre_train.csv -> " + e.getMessage());
        }
    }


    public static void main(String[] args) {
        // 示例：使用 "example_repo" 作为 repoPath
        String localDir = "openharmony-kernel_liteos_m";

        // 复制文件到 repo
        CPFile cpFile = new CPFile();
        cpFile.copyFilesToWorkspace(localDir);
        cpFile.copyFileToRepo(localDir);
    }
}
