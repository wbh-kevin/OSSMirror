package org.example;

import java.io.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class GetOrg {

    // 生成电子邮件域后缀的函数
    private String generateEmailSuffix(String domain) {
        // 电子邮件后缀就是域名本身，不需要特别处理
        return domain.toLowerCase();
    }

    // 生成简化的公司名称（去掉后缀和不必要的字符）
    private String generateSimpleCompanyName(String domain) {
        Set<String> legalEntities = new HashSet<>(Arrays.asList("inc", "corporation", "ltd", "limited", "gmbh", "ag", "org", "group"));
        Set<String> suffixes = new HashSet<>(Arrays.asList(".com", ".org", ".net", ".co", ".cn", ".io", ".ai", ".tech", ".info"));

        // 去除域名后缀（例如 .com）并处理不必要的字符
        String companyName = domain.toLowerCase();
        for (String entity : legalEntities) {
            companyName = companyName.replace(entity, "");
        }
        for (String suffix : suffixes) {
            if (companyName.endsWith(suffix)) {
                companyName = companyName.substring(0, companyName.length() - suffix.length());
            }
        }
        companyName = companyName.replaceAll("[^a-z0-9 ]", "").replaceAll(" +", ""); // 去掉特殊字符并简化空格
        return companyName;
    }

    public void getO(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/mailcompany2.txt";  // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/output.csv";      // 输出文件路径

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            // 写入 CSV 文件的标题行
            writer.write("email_suffix,simple_company_name\n");

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // 为每个域名生成 email_suffix 和 simple_company_name
                String emailSuffix = generateEmailSuffix(line);
                String simpleCompanyName = generateSimpleCompanyName(line);

                // 写入新行到输出 CSV 文件
                writer.write(String.format("%s,%s\n", emailSuffix, simpleCompanyName));
            }

            System.out.println("数据处理完成并保存到: " + outputFilePath);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
