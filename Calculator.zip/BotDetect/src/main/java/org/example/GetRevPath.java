package org.example;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

public class GetRevPath {

    // 数据库连接信息
    private static final String DB_URL = "jdbc:mysql://localhost:3306";  // 数据库的URL
    private static final String USER = "root";  // 数据库的用户名
    private static final String PASS = "password";  // 数据库的密码
    private static final String QUERY = "SELECT rev FROM localhost.linux_commits";  // SQL查询语句

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;
        BufferedWriter writer = null;  // 用于写文件

        try {
            // 打开数据库连接
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // 创建查询
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);

            // 打开文件以进行写入（保存为 CSV 文件）
            writer = new BufferedWriter(new FileWriter("path.csv"));

            // 写入 CSV 文件的列名
            writer.write("rev,path2");
            writer.newLine();  // 换行

            // 打印Git日志并处理数据
            System.out.println("GITLOG");
            GetGitLog getGitLog = new GetGitLog();
            int idx = 0;

            // 遍历结果集并写入文件
            while (rs.next()) {
                idx++;
                if (idx % 10 == 0) {
                    System.out.println(idx / 10);  // 每处理10个记录时输出进度
                }

                // 获取 'rev' 列数据
                String rev = rs.getString("rev");

                // 获取对应的文件路径
                Paths paths = getGitLog.getPath(rev);

                // 拼接 path2
                String path2 = String.join(";", paths.path2);

                // 拼接成最终的 CSV 行数据
                String line = rev + "," + path2;

                // 写入 CSV 文件
                writer.write(line);
                writer.newLine();  // 换行
            }

            // 关闭资源
            rs.close();
            stmt.close();
            writer.close();  // 关闭文件写入流
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                // 确保 Statement, Connection 和 Writer 关闭
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
                if (writer != null) writer.close();
            } catch (Exception se) {
                se.printStackTrace();
            }
        }
    }
}
