package org.example;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.revwalk.RevCommit;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class GitLogExtractor {

    public void extractor(String repoPath) {
        String outputCsvDir = "/root/workspace/wbh/BotDetect/data/" + repoPath;
//        String repoPath = "gitdata"; // Git 仓库路径
        String outputCsv = "/root/workspace/wbh/BotDetect/data/" + repoPath + "/git_log.csv"; // 输出 CSV 文件路径
        repoPath = "/root/workspace/wbh/BotDetect/" + repoPath;

        try {
            // 检查并创建目录
            File dir = new File(outputCsvDir);
            if (!dir.exists()) {
                boolean created = dir.mkdirs();
                if (created) {
                    System.out.println("创建目录：" + outputCsvDir);
                } else {
                    System.err.println("无法创建目录：" + outputCsvDir);
                    return;
                }
            }
            extractGitLog(repoPath, outputCsv);
            System.out.println("Git log successfully written to " + outputCsv);
        } catch (Exception e) {
            System.err.println("An error occurred while extracting the git log: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * 提取 Git 仓库的日志并写入 CSV 文件
     */
    public void extractGitLog(String repoPath, String outputCsv) throws Exception {
        // 打开 Git 仓库
        System.out.println("REPO: "+repoPath);
        System.out.println("OUT: "+repoPath);
        try (Git git = Git.open(new File(repoPath));
             BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputCsv), StandardCharsets.UTF_8))) {

            // 写入表头
            String header = "sha,author_ID,author_name,author_email,author_date,subject,message," +
                    "committer_ID,committer_name,committer_email,committer_date,num_files";
            writer.write(header);
            writer.write("\n"); // 统一使用 Linux 换行符

            // 遍历日志
            Iterable<RevCommit> commits = git.log().call();
            Iterator<RevCommit> iterator = commits.iterator();

            int count = 0; // 当前已处理的日志条数
            int progressCounter = 1; // 用于输出的自增整数

            while (iterator.hasNext()) {
                RevCommit commit = iterator.next();

                // 提取信息
                String sha = commit.getName();
                String authorName = commit.getAuthorIdent().getName();
                String authorEmail = commit.getAuthorIdent().getEmailAddress();
                String authorDate = commit.getAuthorIdent().getWhen().toString();
                String committerName = commit.getCommitterIdent().getName();
                String committerEmail = commit.getCommitterIdent().getEmailAddress();
                String committerDate = commit.getCommitterIdent().getWhen().toString();
                String subject = commit.getShortMessage();
                String message = commit.getFullMessage();

                // 确保每个字段都不为 null，如果是 null 则替换为空字符串
                sha = escapeCsvField(sha);
                authorName = escapeCsvField(authorName);
                authorEmail = escapeCsvField(authorEmail);
                authorDate = escapeCsvField(authorDate);
                subject = escapeCsvField(subject);
                message = escapeCsvField(message);
                committerName = escapeCsvField(committerName);
                committerEmail = escapeCsvField(committerEmail);
                committerDate = escapeCsvField(committerDate);

                // 使用 String.format 格式化 CSV 行
                String csvLine = String.format("\"%s\",\"\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"\",\"%s\",\"%s\",\"%s\",%d",
                        sha,
                        authorName,
                        authorEmail,
                        authorDate,
                        "",
                        message,
                        committerName,
                        committerEmail,
                        committerDate,
                        0);  // 确保这里传递的是正确的参数

                // 写入文件
                writer.write(csvLine);
                writer.write("\n"); // 统一使用 Linux 换行符

                // 更新进度
                count++;
                if (count % 1000 == 0) {
                    System.out.println(progressCounter++);
                }
            }
        }
    }

    /**
     * 对 CSV 字段进行转义处理：
     * 1. 如果字段包含双引号，则每个双引号前加一个双引号。
     * 2. 如果字段包含逗号，使用双引号包裹整个字段。
     */
    private static String escapeCsvField(String field) {
        if (field == null || field.isEmpty()) {
            return field; // 空值或空字符串直接返回
        }

        // 映射规则：替换逗号和换行符，保证可逆性
        field = field.replace(",", "\u0001COMMA\u0001");
        field = field.replace("\r\n", "\u0001NEWLINE\u0001"); // 先替换 Windows 换行符
        field = field.replace("\r", ""); // 删除多余的回车符
        field = field.replace("\n", "\u0001NEWLINE\u0001");

        return field;
    }

    public static void main(String[] args) {
        GitLogExtractor gitLogExtractor = new GitLogExtractor();
        gitLogExtractor.extractor("OPENHarmonydev-openharmony");
    }
}
