package org.example;

import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.diff.DiffEntry;
import org.eclipse.jgit.diff.DiffFormatter;
import org.eclipse.jgit.lib.ObjectId;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GetGitLog {

    private Git git;
    private Repository repository;

    // 构造函数，在类初始化时连接到现有的 Git 仓库
    public GetGitLog() {
        // 获取当前程序根目录
        String rootDirectory = System.getProperty("user.dir");

        // 定义现有仓库路径：程序根目录下的 "gitdata" 文件夹
        String repoDirectoryPath = rootDirectory + File.separator + "gitdata";

        try {
            // 打开现有的 Git 仓库
            System.out.println("Opening existing repository at " + repoDirectoryPath);
            this.git = Git.open(new File(repoDirectoryPath));

            // 获取仓库对象
            this.repository = git.getRepository();

            System.out.println("Repository opened.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 获取指定 SHA 对应的文件路径
    public Paths getPath(String sha) {
        try {
            // 将传入的 SHA 转换为 ObjectId
            ObjectId commitId = repository.resolve(sha);

            if (commitId == null) {
                return null;
            }

            // 使用 RevWalk 获取对应的 RevCommit 对象
            try (RevWalk revWalk = new RevWalk(repository)) {
                RevCommit commit = revWalk.parseCommit(commitId);
//                System.out.println("Found commit: " + commit.getName());

                // 获取父提交（用于比较差异）
                RevCommit parent = commit.getParentCount() > 0 ? commit.getParent(0) : null;

                if (parent != null) {
                    // 使用 DiffFormatter 来获取文件差异
                    try (DiffFormatter diffFormatter = new DiffFormatter(new ByteArrayOutputStream())) {
                        diffFormatter.setRepository(repository);
                        List<DiffEntry> diffs = diffFormatter.scan(parent.getTree(), commit.getTree());

                        // 创建一个用于存储已经输出过的路径的 Set
                        Set<String> path3 = new HashSet<>();
                        Set<String> path2 = new HashSet<>();
                        Set<String> path1 = new HashSet<>();

                        // 打印受影响的文件路径
                        for (DiffEntry diff : diffs) {
                            String filePath = diff.getNewPath();

                            // 分割路径，基于文件路径中的 "/" 符号
                            String[] pathSegments = filePath.split("/");

                            // 检查路径是否超过3个文件夹
                            String shortenedPath;
                            if (pathSegments.length > 3) {
                                // 只输出前三个文件夹
                                shortenedPath = String.join("/", pathSegments[0], pathSegments[1], pathSegments[2]);
                            } else {
                                // 路径不超过3个文件夹，输出原始路径
                                shortenedPath = filePath;
                            }

                            int slashCount = shortenedPath.length() - shortenedPath.replace("/", "").length();  // 计算 '/' 的数量
                            if (slashCount == 2) {
                                // 检查路径是否已经输出过
                                if (!path3.contains(shortenedPath)) {
                                    path3.add(shortenedPath);
                                }
                            }

                            String shortenedPath2;
                            if (pathSegments.length > 2) {
                                // 检查 pathSegments[1] 是否为文件（通过判断是否包含 "."）
                                if (pathSegments[1].contains(".")) {
                                    shortenedPath2 = pathSegments[0];  // 如果是文件，将 shortenedPath2 设置为 pathSegments[0]
                                } else {
                                    shortenedPath2 = String.join("/", pathSegments[0], pathSegments[1]);  // 否则使用前两个部分构建路径
                                }
                            } else {
                                if (pathSegments.length == 2 && pathSegments[1].contains(".")) {
                                    shortenedPath2 = pathSegments[0];  // 如果是文件，将 shortenedPath2 设置为 pathSegments[0]
                                } else {
                                    shortenedPath2 = filePath;  // 如果 pathSegments 的长度不超过 2，则使用原始路径
                                }
                            }


                            slashCount = shortenedPath2.length() - shortenedPath2.replace("/", "").length();  // 计算 '/' 的数量
                            if (slashCount == 1) {
                                if (!path2.contains(shortenedPath2)) {
                                    path2.add(shortenedPath2);
                                }
                            }

                            String shortenedPath1;
                            if (pathSegments.length > 1) {
                                shortenedPath1 = pathSegments[0];
                            } else {
                                shortenedPath1 = filePath;
                            }

                            if (!path1.contains(shortenedPath1)) {
                                path1.add(shortenedPath1);
                            }
                        }

                        Paths paths = new Paths(path3, path2, path1);
                        return paths;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // 在关闭时释放资源
    public void close() {
        if (git != null) {
            git.close();
        }
    }
}