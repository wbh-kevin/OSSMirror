package org.example;

import java.io.*;
import java.util.*;
import java.util.regex.*;

public class GitCommitStats {
    private static final String REPO_PATH = "./linux"; // 仓库路径
    private static final String OUTPUT_CSV = "commit_stats_2024_11.csv";

    public static void main(String[] args) {
        Map<String, Integer> commitCounts = new HashMap<>();

        try {
            // 执行 Git log 命令
            Process process = new ProcessBuilder("git", "log", "--since=2024-11-01", "--until=2025-01-01", "--pretty=format:%an <%ae>")
                    .directory(new File(REPO_PATH))
                    .start();

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;

            while ((line = reader.readLine()) != null) {
                commitCounts.put(line, commitCounts.getOrDefault(line, 0) + 1);
            }
            process.waitFor();

            // 将统计结果写入 CSV
            writeCsv(commitCounts);
            System.out.println("统计完成，结果已写入 " + OUTPUT_CSV);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void writeCsv(Map<String, Integer> commitCounts) {
        try (PrintWriter writer = new PrintWriter(new File(OUTPUT_CSV))) {
            writer.println("用户,邮箱,提交次数");

            for (Map.Entry<String, Integer> entry : commitCounts.entrySet()) {
                String[] parts = entry.getKey().split(" <", 2);
                String user = parts[0];
                String email = parts[1].replace(">", "");
                writer.println(user + "," + email + "," + entry.getValue());
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
