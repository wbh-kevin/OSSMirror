package org.example;

import java.io.*;
import java.util.*;

public class CsvMerger {

    public void mergeCSV(String repo) {
        String userFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid_company.csv"; // 输入文件 1

        // 三个目录级别的输入文件
        String[] commitFilePaths = {"/root/workspace/wbh/BotDetect/data/" + repo + "/processed_commit_changes_one.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/processed_commit_changes_two.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/processed_commit_changes_three.csv"};

        // 三个输出文件
        String[] outputFilePaths = {"/root/workspace/wbh/BotDetect/data/" + repo + "/merged_one.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_two.csv",
                "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_three.csv"};

        try {
            for (int i = 0; i < commitFilePaths.length; i++) {
                mergeCsvFiles(userFilePath, commitFilePaths[i], outputFilePaths[i]);
                System.out.println("Merging complete for " + commitFilePaths[i] +
                        ". Output written to " + outputFilePaths[i]);
            }
        } catch (IOException e) {
            System.err.println("Error processing the files: " + e.getMessage());
        }
    }

    /**
     * 合并两个 CSV 文件。
     */
    private void mergeCsvFiles(String userFilePath, String commitFilePath, String outputFilePath) throws IOException {
        // 读取 userid_processed.csv 的所有数据到 Map 中
        Map<String, String> userFileData = readCsvToMap(userFilePath);

        try (BufferedReader commitReader = new BufferedReader(new FileReader(commitFilePath));
             BufferedWriter outputWriter = new BufferedWriter(new FileWriter(outputFilePath))) {

            // 写入表头
            String header1 = "rev,author_name,author_email,author_date,UserID,mailcompany";
            String header2 = "file_path,added_lines,deleted_lines,merge_count"; // processed_commit_changes.csv 去掉 commit_sha 后的表头
            outputWriter.write(header1 + "," + header2);
            outputWriter.newLine();

            String line;
            boolean isFirstLine = true;

            while ((line = commitReader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // 跳过表头
                }

                String[] commitFields = line.split(",", 4); // 假设行有 4 个字段：commit_sha, file_path, added_lines, deleted_lines
                if (commitFields.length != 4) {
                    continue; // 跳过格式不正确的行
                }

                String commitSha = commitFields[0]; // commit_sha

                // 如果找到匹配的 rev
                if (userFileData.containsKey(commitSha)) {
                    String userRow = userFileData.get(commitSha);
                    String mergedLine = userRow + "," + String.join(",", Arrays.copyOfRange(commitFields, 1, 4));
                    outputWriter.write(mergedLine);
                    outputWriter.newLine();
                }
            }
        }
    }

    /**
     * 读取 CSV 文件并将其存储到 Map 中，键为 rev，值为整行数据。
     */
    private Map<String, String> readCsvToMap(String filePath) throws IOException {
        Map<String, String> dataMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false; // 跳过表头
                    continue;
                }

                String[] fields = line.split(",", -1); // 保留空字段
                if (fields.length < 6) {
                    continue; // 跳过格式不正确的行
                }

                String rev = fields[0]; // rev 是第一列
                dataMap.put(rev, line); // 存储整行数据
            }
        }

        return dataMap;
    }
}
