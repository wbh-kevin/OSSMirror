package org.example;

import java.io.*;
import java.util.*;

public class CompanyModuleAnalyzer {

    public void moduleCal(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_one.csv"; // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/company_focus_modules.csv"; // 输出文件路径

        try {
            analyzeCompanyFocus(inputFilePath, outputFilePath);
            System.out.println("Analysis complete. Output written to " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error processing the file: " + e.getMessage());
        }
    }

    /**
     * 分析每个公司聚焦的模块并输出到文件。
     */
    private void analyzeCompanyFocus(String inputFilePath, String outputFilePath) throws IOException {
        Map<String, Map<String, Integer>> companyFocus = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath))) {

            String header = br.readLine(); // 读取表头
            if (header == null) {
                throw new IOException("Input file is empty or invalid.");
            }

            String line;
            while ((line = br.readLine()) != null) {
                String[] fields = splitCsvLine(line);

                // 校验行格式
                if (fields.length != 10) {
                    System.err.println("Invalid line skipped: " + line);
                    continue;
                }

                String company = fields[5]; // mailcompany
                String module = fields[6]; // file_path
                int addedLines;
                int deletedLines;

                try {
                    addedLines = Integer.parseInt(fields[7]); // added_lines
                    deletedLines = Integer.parseInt(fields[8]); // deleted_lines
                } catch (NumberFormatException e) {
                    System.err.println("Invalid numeric data skipped: " + line);
                    continue;
                }

                // 计算公司对模块的总修改量
                int changes = addedLines + deletedLines;

                // 更新公司对模块的关注度统计
                companyFocus.computeIfAbsent(company, k -> new HashMap<>())
                        .merge(module, changes, Integer::sum);
            }

            // 写入分析结果
            bw.write("Company,Module,TotalChanges");
            bw.newLine();
            for (Map.Entry<String, Map<String, Integer>> companyEntry : companyFocus.entrySet()) {
                String company = companyEntry.getKey();
                for (Map.Entry<String, Integer> moduleEntry : companyEntry.getValue().entrySet()) {
                    String module = moduleEntry.getKey();
                    int totalChanges = moduleEntry.getValue();
                    bw.write(String.format("%s,%s,%d", company, module, totalChanges));
                    bw.newLine();
                }
            }
        }
    }

    /**
     * 拆分 CSV 行，支持包含逗号的字段。
     */
    private String[] splitCsvLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean insideQuotes = false;

        for (char c : line.toCharArray()) {
            if (c == ',' && !insideQuotes) {
                fields.add(currentField.toString());
                currentField.setLength(0);
            } else if (c == '"') {
                insideQuotes = !insideQuotes;
            } else {
                currentField.append(c);
            }
        }
        fields.add(currentField.toString()); // Add the last field
        return fields.toArray(new String[0]);
    }
}