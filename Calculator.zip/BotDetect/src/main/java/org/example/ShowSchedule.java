package org.example;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ShowSchedule {

    private final String filePath = "/root/workspace/wbh/BackgroundServer/src/main/java/com/example/backgroundserver/datas/repoList.csv";
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d");

    public boolean check(String repo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",", -1);
                if (fields.length > 0 && fields[0].trim().equals(repo)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.err.println("读取文件出错: " + e.getMessage());
        }
        return false;
    }

    public void add(String repo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(repo + ",0,0%");
            writer.newLine();
            System.out.println("添加成功: " + repo);
        } catch (IOException e) {
            System.err.println("写入文件出错: " + e.getMessage());
        }
    }

    public void update(String repo) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            List<String> updatedLines = new ArrayList<>();
            boolean updated = false;

            for (String line : lines) {
                String[] fields = line.split(",", -1);
                if (fields.length >= 3 && fields[0].trim().equals(repo)) {
                    String percentageStr = fields[2].trim().replace("%", "");

                    try {
                        double percentage = Double.parseDouble(percentageStr);
                        if (percentage < 90.0) {
                            percentage = Math.min(percentage + 10, 90);
                            fields[2] = ((int) percentage) + "%";
                        } else {
                            fields[1] = "1";
                            fields[2] = LocalDate.now().format(formatter); // 用 yyyy/M/d 格式
                        }
                        updated = true;
                        updatedLines.add(String.join(",", fields));
                    } catch (NumberFormatException e) {
                        // 设置为10%并添加
                        fields[2] = "10%";
                        updated = true;
                        updatedLines.add(String.join(",", fields));
                        System.err.println("无法解析百分比，已默认设置为 10%: " + repo);
                    }
                } else {
                    updatedLines.add(line);
                }
            }

            if (updated) {
                Files.write(Paths.get(filePath), updatedLines);
                System.out.println("更新成功: " + repo);
            } else {
                System.out.println("未找到目标 repo: " + repo);
            }

        } catch (IOException e) {
            System.err.println("更新文件出错: " + e.getMessage());
        }
    }


    public boolean check2(String repo) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            LocalDate now = LocalDate.now();

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",", -1);
                if (fields.length >= 3 && fields[0].trim().equals(repo)) {
                    String value = fields[2].trim();

                    // 如果是日期格式
                    if (value.matches("\\d{4}/\\d{1,2}/\\d{1,2}")) {
                        LocalDate date = LocalDate.parse(value, formatter);
                        if (date.plusDays(7).isBefore(now) || date.plusDays(7).isEqual(now)) {
                            return true; // 超过一周
                        }
                    }
                    return false; // 不超过，或者格式不是日期
                }
            }

        } catch (IOException e) {
            System.err.println("读取文件出错: " + e.getMessage());
        }
        return false; // 未找到 repo 或异常
    }

    public boolean checkEmpty() {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",", -1);
                if (fields.length >= 3) {
                    String third = fields[2].trim();
                    if (third.endsWith("%")) {
                        return false; // 出现百分比
                    }
                }
            }

            return true; // 全部是时间戳
        } catch (IOException e) {
            System.err.println("读取文件失败: " + e.getMessage());
            return false;
        }
    }

    public static void main(String[] args) {
        ShowSchedule showSchedule = new ShowSchedule();
        System.out.println(showSchedule.check("OPENHarmonydev-openharmony"));
        System.out.println(showSchedule.check2("OPENHarmonydev-openharmony"));
        System.out.println(showSchedule.checkEmpty());
    }
}
