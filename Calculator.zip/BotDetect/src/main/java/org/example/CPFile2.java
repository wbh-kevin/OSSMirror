package org.example;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class CPFile2 {

    // 复制文件的通用方法
    private static void copyFile(String sourcePath, String destinationPath) throws IOException {
        Path source = Paths.get(sourcePath);
        Path destination = Paths.get(destinationPath);

        // 确保目标文件夹存在
        Files.createDirectories(destination.getParent());

        // 复制文件（如果目标文件已存在，则覆盖）
        Files.copy(source, destination, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("Copied: " + sourcePath + " -> " + destinationPath);
    }

    // 将 pre_train.csv 复制到 /root/workspace/wbh/css-code/pre_train.csv
    public static void copyFilesToWorkspace(String sourceDir) {
        String sourceFile = "data/" + sourceDir + "/pre_train.csv";
        String destinationFile = "/root/workspace/wbh/css-code/pre_train.csv";

        try {
            copyFile(sourceFile, destinationFile);
        } catch (IOException e) {
            System.err.println("Error copying file: " + sourceFile + " -> " + e.getMessage());
        }
    }

    // 将 /root/workspace/wbh/css-code/llm.out 复制到 data/repo/llm.out
    public static void copyFileToRepo(String repo) {
        String sourceFile = "/root/workspace/wbh/css-code/llm.out";
        String destinationFile = "data/" + repo + "/llm.out";

        try {
            copyFile(sourceFile, destinationFile);
        } catch (IOException e) {
            System.err.println("Error copying file: " + sourceFile + " -> " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        // 示例：从指定路径复制 pre_train.csv
        String localDir = "torvalds-linux";

//        copyFilesToWorkspace(localDir);
        copyFileToRepo(localDir);
    }
}
