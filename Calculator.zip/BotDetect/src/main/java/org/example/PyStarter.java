package org.example;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.io.File;


public class PyStarter {
    public int runScript2() {
        try {
            // 设置要执行的脚本
            ProcessBuilder processBuilder = new ProcessBuilder("bash", "starter.sh");

            // 设置工作目录为脚本所在目录（非常关键！）
            processBuilder.directory(new File("/root/workspace/wbh/css-code"));

            // 合并标准输出和错误输出
            processBuilder.redirectErrorStream(true);

            // 设置环境变量，确保 conda/python 能找到（如有需要）
            Map<String, String> env = processBuilder.environment();
            env.put("PATH", "/root/miniconda3/bin:" + env.get("PATH"));

            System.out.println("Running CSS script synchronously in correct working directory...");
            Process process = processBuilder.start();

            // 读取脚本输出
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("[CSS Starter Output] " + line);
                }
            }

            // 等待脚本执行完毕
            int exitCode = process.waitFor();
            System.out.println("CSS Script finished with exit code: " + exitCode);
            return exitCode;
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return -1; // 表示执行出错
        }
    }


    public int runScript() {
        try {
            ProcessBuilder processBuilder = new ProcessBuilder("bash", "/root/workspace/wbh/Python/starter.sh");
            processBuilder.redirectErrorStream(true); // 合并 stdout 和 stderr

            // 设置环境变量，确保 conda/python 能找到
            Map<String, String> env = processBuilder.environment();
            env.put("PATH", "/root/miniconda3/bin:" + env.get("PATH"));

            System.out.println("Running script synchronously...");
            Process process = processBuilder.start();

            // 输出读取
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println("[Starter Output] " + line);
                }
            }

            int exitCode = process.waitFor(); // 阻塞主线程直到脚本完成
            System.out.println("Script finished with exit code: " + exitCode);
            return exitCode;
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return -1; // 表示执行出错
        }
    }


    public void executeScriptAsync() {
        Thread thread = new Thread(() -> {
            try {
                ProcessBuilder processBuilder = new ProcessBuilder("sh", "/root/workspace/wbh/Python/starter.sh");
                processBuilder.redirectErrorStream(true); // 捕获所有输出（标准输出+错误输出）
                Process process = processBuilder.start();

                // 读取并打印脚本输出，看看有没有报错
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println("[Starter Output] " + line);
                    }
                }

                int exitCode = process.waitFor();
                System.out.println("Starter.sh exited with code: " + exitCode);
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        });

        thread.setDaemon(true);
        thread.start();
    }
//
//    public static void main(String[] args) {
//        PyStarter executor = new PyStarter();
//        executor.executeScriptAsync();
//
//        System.out.println("Script execution started asynchronously.");
//    }
    public static void main(String[] args) {
        PyStarter pyStarter = new PyStarter();
        pyStarter.runScript2();
    }
//        try {
//            // 创建 ProcessBuilder 运行 bash 脚本
//            ProcessBuilder processBuilder = new ProcessBuilder("bash", "/root/workspace/wbh/Python/starter.sh");
//
//            // 获取 Java 进程的环境变量
//            Map<String, String> env = processBuilder.environment();
//
//            // 手动添加 conda 目录，确保可用
//            env.put("PATH", "/root/miniconda3/bin:" + env.get("PATH"));
//
//            // 合并标准输出和错误输出
//            processBuilder.redirectErrorStream(true);
//
//            System.out.println("Starting script execution...");
//            Process process = processBuilder.start();
//
//            // 读取脚本的输出
//            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
//            String line;
//            while ((line = reader.readLine()) != null) {
//                System.out.println(line);
//            }
//
//            // 等待脚本执行完毕
//            int exitCode = process.waitFor();
//            System.out.println("Script exited with code: " + exitCode);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}
