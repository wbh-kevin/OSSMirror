package org.example;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

public class BotAuthorFilter2 {

    // 文件路径
    private static final String BOT_BASE_FILE = "/root/workspace/wbh/BotDetect/data/botBase";
    private static final String BOT_NAME_FILE = "/root/workspace/wbh/BotDetect/data/botName";
    private static final String BOT_EMAIL_FILE = "/root/workspace/wbh/BotDetect/data/botEmail";
    private static final String BOT_LIST_FILE = "/root/workspace/wbh/BotDetect/data/botlist";
    private String GIT_LOG_FILE = "/git_log.csv";  // git_log.csv 文件路径
    private String OUTPUT_FILE = "/filtered_git_log.csv";  // 输出的过滤后的新文件路径
    private String BOTS_FILE = "/bots.txt";  // 输出机器人作者的文件路径

    // 模式匹配
    private static final Pattern BOT_PATTERN = Pattern.compile("([\\W0-9_]robot$)|(^robot[\\W0-9_])|([\\W0-9_]robot[\\W0-9_])", Pattern.CASE_INSENSITIVE);

    private Set<String> botBaseSet = new HashSet<>();
    private Set<String> botNameSet = new HashSet<>();
    private Set<String> botEmailSet = new HashSet<>();
    private Set<String> botListSet = new HashSet<>();
    private static final Set<String> botAuthors = new HashSet<>();

    private Set<String> processedBotAuthors = new HashSet<>();  // 用于去重记录

    public BotAuthorFilter2() {
    }

    public void detectBotAuthor(String repo) {
        GIT_LOG_FILE = "/root/workspace/wbh/BotDetect/data/" + repo + GIT_LOG_FILE;
        OUTPUT_FILE = "/root/workspace/wbh/BotDetect/data/" + repo + OUTPUT_FILE;
        BOTS_FILE = "/root/workspace/wbh/BotDetect/data/" + repo + BOTS_FILE;
        loadBotData();  // 加载机器人数据
        processGitLog();  // 处理 git_log.csv 文件中的作者数据
    }

    // 加载机器人数据文件
    private void loadBotData() {
        loadFileIntoSet(BOT_BASE_FILE, botBaseSet);
        loadFileIntoSet(BOT_NAME_FILE, botNameSet);
        loadFileIntoSet(BOT_EMAIL_FILE, botEmailSet);
        loadFileIntoSet(BOT_LIST_FILE, botListSet);
    }

    private void loadFileIntoSet(String filePath, Set<String> set) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                set.add(line.trim());
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + filePath);
            e.printStackTrace();
        }
    }

    // 处理 git_log.csv 文件中的提交作者数据
    private void processGitLog() {
        try (BufferedReader br = new BufferedReader(new FileReader(GIT_LOG_FILE));
             BufferedWriter bw = new BufferedWriter(new FileWriter(OUTPUT_FILE));
             BufferedWriter botWriter = new BufferedWriter(new FileWriter(BOTS_FILE))) {

            String line;
            int count = 0;

            // 读取并写入表头
            String header = br.readLine();
            bw.write(header);
            bw.newLine();

            // 处理每一行数据
            while ((line = br.readLine()) != null) {
                // 使用自定义的 parseCsvLine 处理 CSV 字符串
                String[] parts = parseCsvLine(line);
                if (parts.length < 4) {
                    continue; // 如果某行数据格式不正确，跳过
                }

                String authorName = parts[2];
                String authorEmail = parts[3];

                // 检查是否为机器人作者
                int botType = isBotAuthor(authorName, authorEmail);
                if (botType == 0) {
                    // 如果不是机器人作者，写入到新的文件
                    bw.write(line);
                    bw.newLine();
                } else {
                    // 如果是机器人作者，跳过此行并记录到 bots.txt 文件中
                    String botInfo = "Bot Author Detected: " + authorName + " <" + authorEmail + ">, Type: " + botType;

                    // 去重：如果该作者信息没有被记录过，则写入 bots.txt
                    if (!processedBotAuthors.contains(botInfo)) {
                        botWriter.write(botInfo);
                        botWriter.newLine();
                        processedBotAuthors.add(botInfo);  // 将该信息加入 Set 以实现去重
                    }
                }

                // 输出进度信息
                count++;
                if (count % 10000 == 0) {
                    System.out.println("Processed " + count + " authors.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 判断提交者是否是机器人
    private int isBotAuthor(String authorName, String authorEmail) {
        if (authorName == null || authorEmail == null) {
            return 0;
        }

        String authorEmailName = authorEmail.split("@")[0];

        // 根据不同文件和模式进行判断
        if (botBaseSet.contains(authorEmail) || botBaseSet.contains(authorEmailName) || botBaseSet.contains(authorName)) {
            return 1;
        }
        if (botNameSet.contains(authorName)) {
            return 2;
        }
        if (botEmailSet.contains(authorEmail)) {
            return 3;
        }
        if (botListSet.contains(authorName) || botListSet.contains(authorEmailName)) {
            return 4;
        }
        if (BOT_PATTERN.matcher(authorName).find() || BOT_PATTERN.matcher(authorEmailName).find()) {
            return 5;
        }

        return 0;
    }

    public static void main(String[] args) {
        BotAuthorFilter2 filter = new BotAuthorFilter2();
        filter.detectBotAuthor("gitdata");  // 检测并处理机器人作者
    }

    private static String[] parseCsvLine(String line) {
        // 处理 CSV 字符串，确保不被字段内的逗号干扰，且还原转义的双引号
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean inQuotes = false;
        boolean escaping = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (escaping) {
                // 处理转义字符，双引号被转义为两个双引号
                currentField.append(c);
                escaping = false;
            } else if (c == '\"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '\"') {
                    // 双引号转义，添加一个双引号
                    currentField.append('\"');
                    i++; // 跳过下一个双引号
                } else {
                    // 切换引号状态
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                // 字段分隔符，且不在引号中
                fields.add(currentField.toString());
                currentField.setLength(0);  // 清空当前字段
            } else {
                // 普通字符，直接追加到当前字段
                currentField.append(c);
            }
        }

        // 最后一列字段
        fields.add(currentField.toString());

        // 返回分割后的字段数组
        return fields.toArray(new String[0]);
    }

}
