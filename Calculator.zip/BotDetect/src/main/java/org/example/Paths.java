package org.example;

import java.util.HashSet;
import java.util.Set;

public class Paths {
    public Set<String> path3 = new HashSet<>();
    public Set<String> path2 = new HashSet<>();
    public Set<String> path1 = new HashSet<>();

    public Paths(Set<String> path3, Set<String> path2, Set<String> path1) {
        this.path1 = path1;
        this.path2 = path2;
        this.path3 = path3;
    }

    public Paths() {

    }
}
