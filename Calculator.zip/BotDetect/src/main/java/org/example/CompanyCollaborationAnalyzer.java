package org.example;

import java.io.*;
import java.util.*;

public class CompanyCollaborationAnalyzer {

    public void collabCal(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_rev_output.csv"; // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/company_collaboration_analysis.csv"; // 输出文件路径

        try {
            analyzeCompanyCollaboration(inputFilePath, outputFilePath);
            System.out.println("Analysis complete. Output written to " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error processing the files: " + e.getMessage());
        }
    }

    private void analyzeCompanyCollaboration(String inputFilePath, String outputFilePath) throws IOException {
        // 使用 Map 仅存储公司与文件的修改记录
        Map<String, Map<String, Integer>> companyFileModifications = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {

            // 写入表头
            writer.write("Company1,FileName,ModificationCount");
            writer.newLine();

            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false; // 跳过表头
                    continue;
                }

                String[] fields = line.split(",", -1);
                if (fields.length < 8) {
                    continue; // 跳过格式错误的行
                }

                String mailCompany = fields[5]; // 公司名
                String filePath = fields[6];   // 文件路径
                int addedLines = parseInteger(fields[7]); // 增加的行数
                int deletedLines = parseInteger(fields[8]); // 删除的行数

                int modificationCount = addedLines + deletedLines;

                // 更新当前公司与文件的修改数据
                companyFileModifications
                        .computeIfAbsent(mailCompany, k -> new HashMap<>())
                        .merge(filePath, modificationCount, Integer::sum);
            }

            // 写出所有公司与文件的修改结果
            for (Map.Entry<String, Map<String, Integer>> companyEntry : companyFileModifications.entrySet()) {
                String company = companyEntry.getKey();
                for (Map.Entry<String, Integer> fileEntry : companyEntry.getValue().entrySet()) {
                    String filePath = fileEntry.getKey();
                    int modificationCount = fileEntry.getValue();

                    writer.write(String.format("%s,%s,%d", company, filePath, modificationCount));
                    writer.newLine();
                }
            }
        }
    }

    /**
     * 将字符串转换为整数，若失败则返回 0。
     */
    private int parseInteger(String value) {
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
