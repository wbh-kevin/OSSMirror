#!/bin/bash

# 检查参数数量
if [ "$#" -ne 2 ]; then
    echo "用法: $0 <repo> <dir>"
    exit 1
fi

# 读取参数
REPO=$1
DIR=$2

# 设定目标路径
TARGET_PATH="/root/workspace/wbh/BotDetect/$DIR"

# 如果目标路径存在且不为空，则清空
if [ -d "$TARGET_PATH" ]; then
    if [ "$(ls -A "$TARGET_PATH")" ]; then
        echo "目标路径 $TARGET_PATH 非空，正在清空..."
        rm -rf "$TARGET_PATH"/*
    fi
fi

# 执行 git clone
git clone "$REPO" "$TARGET_PATH"
