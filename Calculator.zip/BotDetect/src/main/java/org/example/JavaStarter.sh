#!/bin/bash

/root/.jdks/corretto-19.0.2/bin/java \
-javaagent:/root/.cache/JetBrains/RemoteDev/dist/d0f87de73f699_ideaIU-2022.3.3/lib/idea_rt.jar=32839:/root/.cache/JetBrains/RemoteDev/dist/d0f87de73f699_ideaIU-2022.3.3/bin \
-Dfile.encoding=UTF-8 \
-Dsun.stdout.encoding=UTF-8 \
-Dsun.stderr.encoding=UTF-8 \
-classpath "/root/workspace/wbh/BotDetect/target/classes:/root/.m2/repository/org/apache/commons/commons-csv/1.10.0/commons-csv-1.10.0.jar:/root/.m2/repository/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar:/root/.m2/repository/com/google/protobuf/protobuf-java/3.21.9/protobuf-java-3.21.9.jar:/root/.m2/repository/com/google/code/gson/gson/2.8.8/gson-2.8.8.jar:/root/.m2/repository/org/eclipse/jgit/org.eclipse.jgit/6.7.0.202309050840-r/org.eclipse.jgit-6.7.0.202309050840-r.jar:/root/.m2/repository/com/googlecode/javaewah/JavaEWAH/1.2.3/JavaEWAH-1.2.3.jar:/root/.m2/repository/org/slf4j/slf4j-api/1.7.36/slf4j-api-1.7.36.jar:/root/.m2/repository/commons-codec/commons-codec/1.16.0/commons-codec-1.16.0.jar:/root/.m2/repository/dnsjava/dnsjava/3.4.0/dnsjava-3.4.0.jar" \
org.example.Main "$@"
