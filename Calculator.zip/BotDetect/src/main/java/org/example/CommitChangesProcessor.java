package org.example;

import java.io.*;
import java.util.*;

public class CommitChangesProcessor {
    public static void main(String[] args) {
        CommitChangesProcessor commitChangesProcessor = new CommitChangesProcessor();
        commitChangesProcessor.processCommit("OPENHarmonydev-openharmony");
    }

    public void processCommit(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/commit_changes.csv"; // 输入文件路径
        String outputFilePathThree = "/root/workspace/wbh/BotDetect/data/" + repo + "/processed_commit_changes_three.csv"; // 三层输出文件
        String outputFilePathTwo = "/root/workspace/wbh/BotDetect/data/" + repo + "/processed_commit_changes_two.csv"; // 二层输出文件
        String outputFilePathOne = "/root/workspace/wbh/BotDetect/data/" + repo + "/processed_commit_changes_one.csv"; // 一层输出文件

        try {
            processCsvAndWrite(inputFilePath, outputFilePathThree, outputFilePathTwo, outputFilePathOne);
            System.out.println("Processing complete. Outputs written to:");
            System.out.println("Three layers: " + outputFilePathThree);
            System.out.println("Two layers: " + outputFilePathTwo);
            System.out.println("One layer: " + outputFilePathOne);
        } catch (IOException e) {
            System.err.println("Error processing the file: " + e.getMessage());
        }
    }

    /**
     * 流式处理CSV文件，逐行读取并实时写出结果。
     */
    private void processCsvAndWrite(String inputFilePath, String outputFilePathThree, String outputFilePathTwo, String outputFilePathOne) throws IOException {
        Map<String, Map<String, int[]>> resultThree = new HashMap<>();
        Map<String, Map<String, int[]>> resultTwo = new HashMap<>();
        Map<String, Map<String, int[]>> resultOne = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(inputFilePath));
             BufferedWriter bwThree = new BufferedWriter(new FileWriter(outputFilePathThree));
             BufferedWriter bwTwo = new BufferedWriter(new FileWriter(outputFilePathTwo));
             BufferedWriter bwOne = new BufferedWriter(new FileWriter(outputFilePathOne))) {

            // 写入CSV表头
            bwThree.write("commit_sha,file_path,added_lines,deleted_lines,merge_count");
            bwThree.newLine();
            bwTwo.write("commit_sha,file_path,added_lines,deleted_lines,merge_count");
            bwTwo.newLine();
            bwOne.write("commit_sha,file_path,added_lines,deleted_lines,merge_count");
            bwOne.newLine();

            String line;
            int counter = 0; // 记录处理的行数
            String header = br.readLine();
            if (header == null) {
                throw new IOException("Input file is empty or invalid.");
            }

            while ((line = br.readLine()) != null) {
                counter++;
                if (counter % 100000 == 0) {
                    System.out.println("Processed " + counter + " lines...");
                }

                // 解析行并处理记录
                String[] fields = splitLine(line);
                processRecord(fields, resultThree, 3);
                processRecord(fields, resultTwo, 2);
                processRecord(fields, resultOne, 1);

                // 写出中间结果并清空内存中的结果（根据需求可调整）
                if (counter % 1000000 == 0) {
                    flushResults(resultThree, bwThree);
                    flushResults(resultTwo, bwTwo);
                    flushResults(resultOne, bwOne);
                    resultThree.clear();
                    resultTwo.clear();
                    resultOne.clear();
                }
            }

            // 最后一次写出剩余结果
            flushResults(resultThree, bwThree);
            flushResults(resultTwo, bwTwo);
            flushResults(resultOne, bwOne);
        }
    }

    /**
     * 处理单条记录并更新结果。
     */
    private void processRecord(String[] record, Map<String, Map<String, int[]>> result, int depth) {
        if (record.length != 4) {
            System.err.println("Invalid record skipped: " + Arrays.toString(record));
            return;
        }

        String commitSha = record[0];
        String filePath = normalizeFilePath(record[1], depth);
        int addedLines = Integer.parseInt(record[2]);
        int deletedLines = Integer.parseInt(record[3]);

        result.computeIfAbsent(commitSha, k -> new HashMap<>())
                .merge(filePath, new int[]{addedLines, deletedLines, 1}, (oldVal, newVal) -> new int[]{
                        oldVal[0] + newVal[0],
                        oldVal[1] + newVal[1],
                        oldVal[2] + newVal[2] // 合并行数计数
                });
    }

    /**
     * 将内存中的结果写入文件并清空。
     */
    private void flushResults(Map<String, Map<String, int[]>> result, BufferedWriter bw) throws IOException {
        for (Map.Entry<String, Map<String, int[]>> entry : result.entrySet()) {
            String commitSha = entry.getKey();
            for (Map.Entry<String, int[]> pathEntry : entry.getValue().entrySet()) {
                String path = pathEntry.getKey();
                int[] lines = pathEntry.getValue();
                bw.write(String.format("%s,%s,%d,%d,%d", commitSha, path, lines[0], lines[1], lines[2]));
                bw.newLine();
            }
        }
    }

    /**
     * 将行字符串拆分为字段数组。
     */
    private String[] splitLine(String line) {
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean insideQuotes = false;

        for (char c : line.toCharArray()) {
            if (c == ',' && !insideQuotes) {
                fields.add(currentField.toString());
                currentField.setLength(0);
            } else if (c == '"') {
                insideQuotes = !insideQuotes;
            } else {
                currentField.append(c);
            }
        }
        fields.add(currentField.toString()); // Add the last field
        return handleVariableLength(fields);
    }

    private String[] handleVariableLength(List<String> fields) {
        if (fields.size() <= 4) {
            return fields.toArray(new String[0]);
        }
        String commitSha = fields.get(0);
        StringBuilder filePathBuilder = new StringBuilder();
        for (int i = 1; i < fields.size() - 2; i++) {
            if (i > 1) {
                filePathBuilder.append(",");
            }
            filePathBuilder.append(fields.get(i));
        }
        String addedLines = fields.get(fields.size() - 2);
        String deletedLines = fields.get(fields.size() - 1);
        return new String[]{commitSha, filePathBuilder.toString(), addedLines, deletedLines};
    }

    /**
     * 标准化文件路径，去除文件名并保留最多三层、两层、一层目录。
     */
    private String normalizeFilePath(String filePath, int levels) {
        // 移除文件名，仅保留目录
        String normalizedPath = filePath.contains("/") ? filePath.substring(0, filePath.lastIndexOf('/')) : "/";

        // 按目录层级分割路径
        String[] parts = normalizedPath.split("/");
        if (parts.length > levels) {
            normalizedPath = String.join("/", Arrays.copyOf(parts, levels));
        }

        return normalizedPath.isEmpty() ? "/" : normalizedPath;
    }
}
