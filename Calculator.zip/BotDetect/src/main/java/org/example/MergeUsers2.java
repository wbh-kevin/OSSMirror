package org.example;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class MergeUsers2 {
    private static Map<String, Set<String>> emailNames = new HashMap<>();
    private static Map<String, Set<String>> nameEmails = new HashMap<>();
    private static Map<Integer, List<Set<String>>> idEmailsNames = new HashMap<>();

    public static void main(String[] args) throws IOException {
        MergeUsers2 mergeUsers2 = new MergeUsers2();
        mergeUsers2.merge("gitdata");
    }

    public void merge(String repo) throws IOException {
        // 读取 CSV 文件中的提交记录并填充 emailNames 和 nameEmails
        String log = "/root/workspace/wbh/BotDetect/data/" + repo + "/filtered_git_log.csv";
        readFromCsv(log);
        String rs1 = "/root/workspace/wbh/BotDetect/data/" + repo + "/rs1.txt";
        String rs2 = "/root/workspace/wbh/BotDetect/data/" + repo + "/rs2.txt";
        // 写入 rs1.txt 文件并构建 idEmailsNames
        writeRs1(rs1);

        // 合并重复的用户
        mergeUsers();

        // 写入 rs2.txt 文件
        writeRs2(rs2);
    }

    private static void readFromCsv(String filePath) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(filePath), StandardCharsets.UTF_8)) {
            String line;
            // 读取表头（假设第一行为表头）
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                String[] parts = parseCsvLine(line);
                if (parts.length < 11) { // 需要至少 11 列数据
                    continue;
                }

                String sha = parts[0];           // 提交哈希，未使用
                String authorName = parts[2];   // 作者名字
                String authorEmail = parts[3];  // 作者邮件
                String committerName = parts[8]; // 提交者名字
                String committerEmail = parts[9]; // 提交者邮件

                if (committerEmail != null && !committerEmail.isEmpty()) {
                    emailNames.putIfAbsent(committerEmail, new HashSet<>());
                    if (committerName != null && !committerName.isEmpty()) {
                        emailNames.get(committerEmail).add(committerName);
                    }
                }
                if (authorEmail != null && !authorEmail.isEmpty()) {
                    emailNames.putIfAbsent(authorEmail, new HashSet<>());
                    if (authorName != null && !authorName.isEmpty()) {
                        emailNames.get(authorEmail).add(authorName);
                    }
                }
                if (committerName != null && !committerName.isEmpty()) {
                    nameEmails.putIfAbsent(committerName, new HashSet<>());
                    if (committerEmail != null && !committerEmail.isEmpty()) {
                        nameEmails.get(committerName).add(committerEmail);
                    }
                }
                if (authorName != null && !authorName.isEmpty()) {
                    nameEmails.putIfAbsent(authorName, new HashSet<>());
                    if (authorEmail != null && !authorEmail.isEmpty()) {
                        nameEmails.get(authorName).add(authorEmail);
                    }
                }
            }
        }
    }

    private static void writeRs1(String filePath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath), StandardCharsets.UTF_8)) {
            int id = 1;
            for (Map.Entry<String, Set<String>> entry : emailNames.entrySet()) {
                String email = entry.getKey();
                Set<String> names = entry.getValue();
                writer.write(id + ":" + email + ":" + String.join(";", names) + "\n");
                idEmailsNames.put(id, Arrays.asList(new HashSet<>(Collections.singleton(email)), names));
                id++;
            }

            for (Map.Entry<String, Set<String>> entry : nameEmails.entrySet()) {
                String name = entry.getKey();
                Set<String> emails = entry.getValue();
                idEmailsNames.put(id, Arrays.asList(emails, new HashSet<>(Collections.singleton(name))));
                id++;
            }
        }
    }

    private static void mergeUsers() {
        boolean stop;
        int upid = idEmailsNames.size() + 1;
        int time = 0;
        do {
            stop = true;
            for (int i = 1; i < upid; i++) {
                if (idEmailsNames.containsKey(i)) {
                    for (int j = i + 1; j < upid; j++) {
                        if (idEmailsNames.containsKey(j)) {
                            Set<String> emailsI = idEmailsNames.get(i).get(0);
                            Set<String> namesI = idEmailsNames.get(i).get(1);
                            Set<String> emailsJ = idEmailsNames.get(j).get(0);
                            Set<String> namesJ = idEmailsNames.get(j).get(1);
                            time++;
                            if (time % 10000000 == 0) {
                                System.out.println(time / 10000000);
                            }
                            if (!Collections.disjoint(emailsI, emailsJ) || !Collections.disjoint(namesI, namesJ)) {
                                stop = false;
                                emailsI.addAll(emailsJ);
                                namesI.addAll(namesJ);
                                idEmailsNames.remove(j);
                            }
                        }
                    }
                }
            }
        } while (!stop);
    }

    private static void writeRs2(String filePath) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath), StandardCharsets.UTF_8)) {
            int id = 1;
            for (Map.Entry<Integer, List<Set<String>>> entry : idEmailsNames.entrySet()) {
                Set<String> emails = entry.getValue().get(0);
                Set<String> names = entry.getValue().get(1);
                writer.write(id + "#" + String.join(";", emails) + "#" + String.join(";", names) + "\n");
                id++;
            }
        }
    }

    private static String[] parseCsvLine(String line) {
        // 解析 CSV 字符串，处理引号和转义字符
        List<String> fields = new ArrayList<>();
        StringBuilder currentField = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '\"') {
                inQuotes = !inQuotes;
            } else if (c == ',' && !inQuotes) {
                fields.add(currentField.toString());
                currentField.setLength(0);
            } else {
                currentField.append(c);
            }
        }
        fields.add(currentField.toString());
        return fields.toArray(new String[0]);
    }
}
