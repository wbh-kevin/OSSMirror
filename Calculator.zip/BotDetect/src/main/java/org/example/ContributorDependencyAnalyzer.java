package org.example;

import java.io.*;
import java.util.*;

public class ContributorDependencyAnalyzer {

    public static void main(String[] args) {
        ContributorDependencyAnalyzer contributorDependencyAnalyzer = new ContributorDependencyAnalyzer();
        contributorDependencyAnalyzer.dependencyAnalyze("openharmony-kernel_liteos_m");
    }

    public void dependencyAnalyze(String repo) {
        String inputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/merged_rev_output.csv"; // 输入文件路径
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/single_contributor_dependency.csv"; // 输出文件路径

        try {
            analyzeSingleContributorDependency(inputFilePath, outputFilePath);
            System.out.println("Analysis complete. Output written to " + outputFilePath);
        } catch (IOException e) {
            System.err.println("Error processing the files: " + e.getMessage());
        }
    }

    /**
     * 分析单一贡献者依赖性。
     */
    private void analyzeSingleContributorDependency(String inputFilePath, String outputFilePath) throws IOException {
        Map<String, Map<String, Integer>> companyContributions = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFilePath))) {
            String line;
            boolean isFirstLine = true;

            while ((line = reader.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue; // 跳过表头
                }

                String[] fields = line.split(",", -1);
                if (fields.length < 6) {
                    continue; // 跳过格式不正确的行
                }

                String mailCompany = fields[5]; // mailcompany 列
                String userID = fields[4]; // UserID 列

                // 更新公司和用户提交计数
                companyContributions
                        .computeIfAbsent(mailCompany, k -> new HashMap<>())
                        .merge(userID, 1, Integer::sum);
            }
        }

        // 写入分析结果
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath))) {
            writer.write("Company,HasSingleContributorDependency,UserID,ContributionPercentage");
            writer.newLine();

            for (Map.Entry<String, Map<String, Integer>> entry : companyContributions.entrySet()) {
                String company = entry.getKey();
                Map<String, Integer> userContributions = entry.getValue();

                // 计算总提交数
                int totalContributions = userContributions.values().stream().mapToInt(Integer::intValue).sum();

                // 找出最大的贡献者
                String topUserID = null;
                int maxContributions = 0;
                for (Map.Entry<String, Integer> userEntry : userContributions.entrySet()) {
                    if (userEntry.getValue() > maxContributions) {
                        maxContributions = userEntry.getValue();
                        topUserID = userEntry.getKey();
                    }
                }

                // 判断是否存在单一贡献者依赖性
                double contributionPercentage = (double) maxContributions / totalContributions * 100;
                boolean hasDependency = contributionPercentage > 50;
                if (company.equals("public")){
                    continue;
                }
                // 写入结果
                writer.write(String.format("%s,%s,%s,%.2f%%",
                        company,
                        hasDependency ? "Yes" : "No",
                        hasDependency ? topUserID : "N/A",
                        hasDependency ? contributionPercentage : contributionPercentage));
                writer.newLine();
            }
        }
    }
}
