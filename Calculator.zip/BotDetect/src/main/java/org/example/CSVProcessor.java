package org.example;

import java.io.*;
import java.util.*;

public class CSVProcessor {

    public void csvProcess(String repo) {
        // 定义输入和输出文件路径
        String useridFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid.csv";
        String outputFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/output.csv";
        String outputProcessedFilePath = "/root/workspace/wbh/BotDetect/data/" + repo + "/userid_processed.csv";

        // 加载 output.csv 数据到 Map 中
        Map<String, String> emailSuffixMap = loadEmailSuffixMap(outputFilePath);

        // 处理 userid.csv 文件并写入到新的文件
        processUserIdFile(useridFilePath, emailSuffixMap, outputProcessedFilePath);
    }

    // 加载 output.csv 数据到 Map 中
    private Map<String, String> loadEmailSuffixMap(String filePath) {
        Map<String, String> emailSuffixMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true;

            while ((line = br.readLine()) != null) {
                // 跳过表头
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }

                // 按逗号分隔字段
                String[] fields = line.split(",");
                if (fields.length >= 2) {
                    String emailSuffix = fields[0].trim();
                    String simpleCompanyName = fields[1].trim();
                    emailSuffixMap.put(emailSuffix, simpleCompanyName);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return emailSuffixMap;
    }

    // 处理 userid.csv 文件
    private void processUserIdFile(String filePath, Map<String, String> emailSuffixMap, String outputFilePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath));
             BufferedWriter bw = new BufferedWriter(new FileWriter(outputFilePath))) {

            String line;
            boolean isFirstLine = true;

            // 读取和处理每行数据
            while ((line = br.readLine()) != null) {
                // 写入表头
                if (isFirstLine) {
                    bw.write(line);  // 写入表头行
                    bw.newLine();
                    isFirstLine = false;
                    continue;
                }

                // 按逗号分隔字段
                String[] fields = line.split(",");
                if (fields.length >= 6) {
                    String mailCompany = fields[5].trim();

                    // 查找替换项
                    String simpleCompanyName = emailSuffixMap.getOrDefault(mailCompany, "public");

                    // 替换 mailcompany 字段
                    fields[5] = simpleCompanyName;

                    // 将处理后的行写入新文件
                    bw.write(String.join(",", fields));
                    bw.newLine();
                }
            }

            System.out.println("数据已成功处理并保存到 " + outputFilePath);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
