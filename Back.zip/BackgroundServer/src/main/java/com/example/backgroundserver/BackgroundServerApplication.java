package com.example.backgroundserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackgroundServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackgroundServerApplication.class, args);
	}

}
