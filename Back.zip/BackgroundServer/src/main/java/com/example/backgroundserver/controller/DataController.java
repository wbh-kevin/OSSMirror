package com.example.backgroundserver.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/getData")
public class DataController {
    String dataDir = "/root/workspace/wbh/BotDetect/data/";
    String localDir = dataDir;
    @RequestMapping("/test")
    public String testController(){
        return "Success";
    }

    @RequestMapping("/calRepo")
    public String calRepo(@RequestParam String repo) {
        try {
            // 还原 URL 编码的 repo 字符串
            String decodedRepo = URLDecoder.decode(repo, StandardCharsets.UTF_8.name());
//            System.out.println("解码后的 repo URL: " + decodedRepo);

            // 调用 check_repo_exists.sh 脚本
            ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "/root/workspace/wbh/BackgroundServer/src/main/java/com/example/backgroundserver/calculator/check.sh", decodedRepo);
            processBuilder.redirectErrorStream(true); // 合并标准输出和错误输出

            Process process = processBuilder.start();

            // 读取脚本输出
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String output = reader.readLine(); // 只需要第一行输出（true / false）

            int exitCode = process.waitFor();

            if (exitCode == 0 && "true".equalsIgnoreCase(output)) {
                // 开启新线程执行 startJava(repo)，并将输出写入 out.log
                new Thread(() -> {
                    try (PrintStream out = new PrintStream(new FileOutputStream("out.log", true))) {
                        // 重定向 System.out 和 System.err
                        System.setOut(out);
                        System.setErr(out);

                        startJava(repo);

                    } catch (IOException e) {
                        e.printStackTrace(); // 打印到默认标准错误输出
                    }
                }).start();

                return "success";
            } else {
                return "fail";
            }


        } catch (Exception e) {
            e.printStackTrace();
            return "Error executing shell script";
        }
    }

    public void startJava(String repo) {
        String oldDir = System.getProperty("user.dir");
        try {
            // 设置脚本路径
            String scriptPath = "/root/workspace/wbh/BotDetect/src/main/java/org/example/JavaStarter.sh";
            // 创建命令，传入 repo 作为参数
            System.setProperty("user.dir", "/root/workspace/wbh/BotDetect/src/main/java/org/example");
            ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", scriptPath, repo);

            // 合并标准输出和错误输出
            processBuilder.redirectErrorStream(true);

            // 启动进程
            Process process = processBuilder.start();

            // 读取输出（可选）
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);  // 打印脚本输出
                }
            }

            // 等待脚本执行完成
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                System.out.println("JavaStarter.sh 脚本执行成功!");
            } else {
                System.out.println("JavaStarter.sh 脚本执行失败, 退出码: " + exitCode);
            }

        } catch (IOException | InterruptedException e) {
            System.setProperty("user.dir", oldDir);
            e.printStackTrace();
            System.out.println("执行脚本时出错: " + e.getMessage());
        }
        System.setProperty("user.dir", oldDir);
    }

    private String[] extractOwnerAndRepo(String url) {
        try {
            // 处理 GitHub 仓库 URL，如 "https://github.com/torvalds/linux.git"
            if (url.startsWith("https://github.com/")) {
                String path = url.replace("https://github.com/", "");

                // 去掉 .git 结尾（如果存在）
                if (path.endsWith(".git")) {
                    path = path.substring(0, path.length() - 4);
                }

                String[] parts = path.split("/");
                if (parts.length >= 2) {
                    return new String[]{parts[0], parts[1]};
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    private boolean checkGitHubRepoExists(String repoUrl) {
        try {
            // 发送 HEAD 请求
            HttpURLConnection connection = (HttpURLConnection) new URL(repoUrl).openConnection();
            connection.setRequestMethod("HEAD");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);
            connection.connect();

            int responseCode = connection.getResponseCode();
            System.out.println("GitHub API 响应码: " + responseCode);

            return responseCode == 200; // 200 表示仓库存在
        } catch (IOException e) {
            System.out.println("GitHub 仓库检查失败: " + e.getMessage());
            return false;
        }
    }

    private final ExecutorService executorService = Executors.newCachedThreadPool(); // 线程池

    //    @RequestMapping("/cal")
    public Boolean cal(String repo) {
        System.out.println("收到请求参数: " + repo);

        executorService.submit(() -> {
            try {
                // 需要使用完整的类路径，并指定 target/classes 作为 CLASSPATH
                ProcessBuilder processBuilder = new ProcessBuilder(
                        "java", "-cp", "target/classes/", "com.example.backgroundserver.calculator.Calculate", repo
                );
                processBuilder.redirectErrorStream(true); // 合并标准输出和错误输出

                // 启动子进程
                Process process = processBuilder.start();
                System.out.println("Calculate 进程已异步启动");

                // 读取子进程的输出
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        System.out.println("Calculate 输出: " + line); // 这里可以换成写入日志文件
                    }
                }

                System.out.println("Calculate 进程完成");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


        return true; // 立即返回，不等待子进程
    }


    @RequestMapping("/getCompanyList")
    public String getCompanyList(@RequestParam(required = false) String repo) {
        // 如果repo参数不是"torvalds-linux"，则返回"Empty repo"
//        if (repo != null && !repo.equals("torvalds-linux")) {
//            return "Empty repo";
//        }

        Set<String> companyNames = new HashSet<>(); // 使用Set代替List来自动去重
        // 获取项目根目录路径
        String rootPath = System.getProperty("user.dir");
        // 拼接文件路径
        String filePath = localDir + repo + "/output.csv"; // CSV文件路径

        try (Reader reader = new FileReader(filePath)) {
            // 使用Apache Commons CSV解析CSV文件
            CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT);

            // 遍历每一行，提取第二列（index 1）
            for (CSVRecord record : csvParser) {
                String companyName = record.get(1); // 第二列数据
                companyNames.add(companyName); // Set会自动去重
            }

            // 对公司名称进行字典顺序排序
            List<String> sortedCompanyNames = new ArrayList<>(companyNames); // 将Set转回List，以便排序
            Collections.sort(sortedCompanyNames);

            // 使用Jackson库将List转为JSON格式字符串
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(sortedCompanyNames);

        } catch (IOException e) {
            e.printStackTrace();
            return "Error reading CSV file.";
        }
    }



    @RequestMapping("/getTotalCount")
    public String getTotalCount(@RequestParam(required = false) String repo) {
        // 如果repo参数不是"torvalds-linux"，则返回"Empty repo"
//        if (repo != null && !repo.equals("torvalds-linux")) {
//            return "Empty repo";
//        }
        String rootPath = System.getProperty("user.dir");
        // 拼接文件路径
        String filePath = localDir + repo + "/total.txt"; // CSV文件路径
        Map<String, Integer> companyCounts = new HashMap<>();
//        String filePath = "total.txt"; // 假设 total.txt 文件位于项目根目录

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // 去掉每行的空白字符，并确保有效数据
                line = line.trim();
                if (!line.isEmpty()) {
                    // 处理每行，提取公司名和计数
                    // 格式为："公司名": 数量
                    int colonIndex = line.indexOf(":");
                    if (colonIndex != -1) {
                        String companyName = line.substring(1, colonIndex - 1).trim(); // 提取公司名
                        if (companyName.equals("public")){
                            companyName="volunteers";
                        }
                        int count = Integer.parseInt(line.substring(colonIndex + 1, line.length() - 1).trim()); // 提取行数

                        companyCounts.put(companyName, count);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "{\"error\": \"Error reading total.txt file\"}";
        }

        // 使用 ObjectMapper 将 Map 转换为 JSON 格式
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(companyCounts);
        } catch (IOException e) {
            e.printStackTrace();
            return "{\"error\": \"Error converting data to JSON\"}";
        }
    }

    @RequestMapping("/getRepoList")
    public String getRepoList() {
        // 创建一个List并加入"torvalds-linux"和"other"
        List<String> repoList = new ArrayList<>();
        repoList.add("torvalds-linux");
        repoList.add("other");

        // 使用Jackson库将List转为JSON格式字符串
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(repoList);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return "Error processing JSON.";
        }
    }
    @RequestMapping("/getRepoList2")
    public String getRepoList2() {
        List<Map<String, Object>> repoList = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper();
        String rootPath = System.getProperty("user.dir");
        // 拼接文件路径
        String filePath = rootPath + "/src/main/java/com/example/backgroundserver/datas/repoList.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3) {
                        Map<String, Object> repo = new HashMap<>();
                        repo.put("name", parts[0]);
                        repo.put("id", Integer.parseInt(parts[1]));
                        repo.put("date", parts[2]);  // 你可以按需要将字符串解析为 LocalDate
                        repoList.add(repo);
                    }
                }
            }
            return objectMapper.writeValueAsString(repoList);
        } catch (IOException e) {
            e.printStackTrace();
            return "Error reading file or processing JSON.";
        }
    }

    @RequestMapping("/getCommitCount")
    public String getCommitCount(@RequestParam(required = false) String repo, @RequestParam(required = false) String time) {
        // 如果repo参数不是"torvalds-linux"，则返回"Empty repo"
//        if (repo != null && !repo.equals("torvalds-linux")) {
//            return "Empty repo";
//        }

        // 获取当前项目的根目录路径
        String rootPath = System.getProperty("user.dir");
        // 默认读取 year_count.csv
        String filePath = localDir + repo + "/year_count.csv";

        // 根据 time 参数来选择文件
        if ("1".equals(time)) {
            filePath = localDir + repo + "/month_count.csv"; // 如果 time 为 1，则读取 month_count.csv
        }

        List<Map<String, Object>> resultList = new ArrayList<>();
        ObjectMapper objectMapper = new ObjectMapper(); // 用于转换 JSON

        try (Reader reader = new FileReader(filePath);
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT.withFirstRecordAsHeader())) {

            // 读取 CSV 文件并将数据提取到 resultList 中
            for (CSVRecord record : csvParser) {
                Map<String, Object> data = new HashMap<>();
                // 第一列作为时间列，不管表头是什么
                String timeValue = record.get(0).trim(); // 获取第一列的值（时间列）
                if (!"1".equals(time) && Integer.parseInt(timeValue)>2025){
                    continue;
                }
                data.put("time", timeValue); // 设置时间字段
                data.put("count", Integer.parseInt(record.get("Count").trim())); // 提取提交次数

                resultList.add(data);
            }

        } catch (IOException e) {
            return "{\"error\":\"无法读取 " + filePath + "\"}"; // 失败返回 JSON 格式错误信息
        }

        try {
            return objectMapper.writeValueAsString(resultList); // 转换 List 为 JSON 字符串
        } catch (JsonProcessingException e) {
            return "{\"error\":\"JSON 处理失败\"}"; // JSON 解析失败
        }
    }


    @GetMapping("getFileStru")
    public String getFileStru(@RequestParam(required = false) String repo) throws IOException {
        // 假设文件路径为 "NewTS.txt"
        String rootPath = System.getProperty("user.dir");
        String filePath = localDir + repo + "/NewTS.txt";  // 如果repo有值，你可以根据repo设置不同的路径

        List<String> resultList = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;

        // 逐行读取文件
        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length > 1) {
                // 去掉第一个字段，并构造一个JSON格式字符串
                String json = "{\"name\":\"" + parts[1] + "\", \"start\":\"" + parts[2] + "\", \"end\":\"" + parts[3] + "\"}";
                resultList.add(json);
            }
        }
        br.close();

        // 手动构造最终的JSON字符串
        StringBuilder jsonResponse = new StringBuilder();
        jsonResponse.append("[");
        for (int i = 0; i < resultList.size(); i++) {
            jsonResponse.append(resultList.get(i));
            if (i < resultList.size() - 1) {
                jsonResponse.append(", ");
            }
        }
        jsonResponse.append("]");

        return jsonResponse.toString();
    }

    public class Decoder {
        public static String decode(String input) {
//            System.out.println(input);
            // 先替换%0为%，然后再替换%1为/
            String decoded = input.replace("\\0", "\\").replace("\\1", "/");
//            System.out.println(input);
//            System.out.println(decoded);
            return decoded;
        }
    }

    @RequestMapping("/getModule")
    public String getModule(@RequestParam(required = false) String repo,
                            @RequestParam(required = false) String prefix,
                            @RequestParam(required = false) int type) throws IOException {
//        System.out.println(type);
        // Decode prefix if provided
//        System.out.println("Called");
        prefix = Decoder.decode(prefix);
//        System.out.println(prefix);
        // Use TreeMap to store statistics, which automatically sorts by dateKey in ascending order
        Map<String, Integer> statistics = new TreeMap<>();

        String rootPath = System.getProperty("user.dir");
        String filePatt = rootPath;

        // Set the appropriate file path based on the type
        if (type % 3 == 1) {
            filePatt = localDir + repo + "/merged_one.csv";
        }
        if (type % 3 == 2) {
            filePatt = localDir + repo + "/merged_two.csv";
        }
        if (type % 3 == 0) {
            filePatt = localDir + repo + "/merged_three.csv";
        }
//        System.out.println(filePatt);
        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePatt))) {
            String line;

            // Skip header
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split CSV line
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String filePath = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);
                // If 'prefix' is provided, filter by it
                if (prefix != null && !filePath.startsWith(prefix)) {
                    continue;
                }
//                System.out.println(prefix);

                // Extract year and month from the date string (Mon Dec 09 06:03:39 CST 2024)
                String[] dateParts = authorDateStr.split(" ");  // ["Mon", "Dec", "09", "06:03:39", "CST", "2024"]
                String year = dateParts[5];  // The year is the last part of the string
                String month = String.format("%02d", getMonthIndex(dateParts[1]));  // Convert month name to number (Dec -> 12)

                // Determine the grouping format (Year or Year-Month)
                String dateKey;
                if (type > 3) {  // Group by year
                    dateKey = year;
                } else {  // Group by year-month
                    dateKey = year + "-" + month;
                }

                // Initialize the statistics map if not already present
                statistics.putIfAbsent(dateKey, 0);

                // Accumulate the added and deleted lines into the existing value for the dateKey
                statistics.put(dateKey, statistics.get(dateKey) + mergeCount);
            }
        }

        // Return the result in the desired format (string representation of the sorted map)
        return statistics.toString();
    }

    // Helper function to map month name to month number
    private int getMonthIndex(String month) {
        Map<String, Integer> monthMap = new HashMap<>();
        monthMap.put("Jan", 1);
        monthMap.put("Feb", 2);
        monthMap.put("Mar", 3);
        monthMap.put("Apr", 4);
        monthMap.put("May", 5);
        monthMap.put("Jun", 6);
        monthMap.put("Jul", 7);
        monthMap.put("Aug", 8);
        monthMap.put("Sep", 9);
        monthMap.put("Oct", 10);
        monthMap.put("Nov", 11);
        monthMap.put("Dec", 12);

        return monthMap.getOrDefault(month, 1);  // Default to 1 if month is invalid
    }

    @RequestMapping("/getModuleC")
    public String getModuleC(@RequestParam(required = false) String repo,
                             @RequestParam(required = false) String prefix,
                             @RequestParam(required = false) int type) throws IOException {
        // Decode prefix if provided
        prefix = Decoder.decode(prefix);

        // Initialize the result map to store the merge counts for each mailcompany
        Map<String, Integer> mergeCounts = new HashMap<>();

        // Define the path to the merged_one.csv file
        String rootPath = System.getProperty("user.dir");
        String filePatt = rootPath;

        // Set the appropriate file path based on the type
        if (type % 3 == 1) {
            filePatt = localDir + repo + "/merged_one.csv";
        }
        if (type % 3 == 2) {
            filePatt = localDir + repo + "/merged_two.csv";
        }
        if (type % 3 == 0) {
            filePatt = localDir + repo + "/merged_three.csv";
        }
        String filePath = filePatt;

        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip header
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split CSV line
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String file = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);

                // If 'prefix' is provided, filter by it (i.e., file_path should start with prefix)
                if (prefix != null && !file.startsWith(prefix)) {
                    continue;
                }

                // Accumulate the merge count for the corresponding mailcompany
                mergeCounts.put(mailCompany, mergeCounts.getOrDefault(mailCompany, 0) + mergeCount);
            }
        }

        // Build the result in the desired format (e.g., JSON-like format)
        StringBuilder result = new StringBuilder("{\n");

        for (Map.Entry<String, Integer> entry : mergeCounts.entrySet()) {
            // Wrap mailCompany (key) with double quotes
            result.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (result.length() > 1) {
            result.setLength(result.length() - 2);
        }

        result.append("\n}");

        // Return the formatted result
        return result.toString();
    }
    @RequestMapping("/getModuleCL")
    public String getModuleCL(@RequestParam(required = false) String repo,
                              @RequestParam(required = false) String prefix,
                              @RequestParam(required = false) int type) throws IOException {
        // Decode prefix if provided
        prefix = Decoder.decode(prefix);

        // Initialize the result map to store the merge counts for each mailcompany
        Map<String, Integer> mergeCounts = new HashMap<>();

        // Define the path to the merged_one.csv file
        String rootPath = System.getProperty("user.dir");
        String filePatt = rootPath;

        // Set the appropriate file path based on the type
        if (type % 3 == 1) {
            filePatt = localDir + repo + "/merged_one.csv";
        }
        if (type % 3 == 2) {
            filePatt = localDir + repo + "/merged_two.csv";
        }
        if (type % 3 == 0) {
            filePatt = localDir + repo + "/merged_three.csv";
        }
        String filePath = filePatt;

        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip header
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split CSV line
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String file = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);

                // If 'prefix' is provided, filter by it (i.e., file_path should start with prefix)
                if (prefix != null && !file.startsWith(prefix)) {
                    continue;
                }

                // Accumulate the merge count for the corresponding mailcompany
                mergeCounts.put(mailCompany, mergeCounts.getOrDefault(mailCompany, 0) +
                        addedLines + deletedLines);
            }
        }

        // Build the result in the desired format (e.g., JSON-like format)
        StringBuilder result = new StringBuilder("{\n");

        for (Map.Entry<String, Integer> entry : mergeCounts.entrySet()) {
            // Wrap mailCompany (key) with double quotes
            result.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (result.length() > 1) {
            result.setLength(result.length() - 2);
        }

        result.append("\n}");

        // Return the formatted result
        return result.toString();
    }

    @RequestMapping("/getCI")
    public String getCI(@RequestParam(required = false) String repo,
                        @RequestParam(required = false) String company,
                        @RequestParam(required = false) int type) throws IOException {
        // Decode the company if needed (assuming you may have a decode method)
        company = Decoder.decode(company);

        // Initialize the result map to store the merge counts grouped by year or year-month
        Map<String, Integer> mergeCounts = new TreeMap<>();  // TreeMap to automatically sort by dateKey

        // Define the path to the merged_one.csv file
        String rootPath = System.getProperty("user.dir");
        String filePath = localDir + repo + "/merged_one.csv";

        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip the header row
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split the line into fields
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String filePathFromCSV = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);

                // Filter by company if provided
                if (company != null && !mailCompany.equals(company)) {
                    continue;
                }

                // Parse the date and extract year and month
                String[] dateParts = authorDateStr.split(" ");  // Example: ["Mon", "Dec", "09", "06:03:39", "CST", "2024"]
                String year = dateParts[5];  // The year is the last part of the string
                String month = String.format("%02d", getMonthIndex(dateParts[1]));  // Convert month name to number (Dec -> 12)

                String dateKey;
                if (type == 1) {  // Group by year
                    dateKey = year;
                } else {  // Group by year-month (type == 0)
                    dateKey = year + "-" + month;
                }

                // Accumulate the merge count for the corresponding dateKey
                mergeCounts.put(dateKey, mergeCounts.getOrDefault(dateKey, 0) + mergeCount);
            }
        }

        // Build the result in the desired format
        StringBuilder result = new StringBuilder("{\n");

        for (Map.Entry<String, Integer> entry : mergeCounts.entrySet()) {
            result.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (result.length() > 1) {
            result.setLength(result.length() - 2);
        }

        result.append("\n}");

        // Return the formatted result
        return result.toString();
    }

    @RequestMapping("/getCE")
    public String getCE(@RequestParam(required = false) String repo,
                        @RequestParam(required = false) String company,
                        @RequestParam(required = false) int type) throws IOException {
        // Decode the company name if necessary
        company = Decoder.decode(company);

        // Use a map to store sets of file paths, grouped by year or year-month
        Map<String, Set<String>> filePathSets = new TreeMap<>();

        // Define the CSV file path
        String rootPath = System.getProperty("user.dir");
        String filePath = localDir + repo + "/merged_one.csv";

        // Read the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip the header row
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split the line into fields
                String[] fields = line.split(",");

                String authorDateStr = fields[3];  // Example: Mon Dec 09 06:03:39 CST 2024
                String mailCompany = fields[5];
                String filePathFromCSV = fields[6];  // The file path we need to count

                // Filter by company if provided
                if (company != null && !mailCompany.equals(company)) {
                    continue;
                }

                // Parse the date and extract year and month
                String[] dateParts = authorDateStr.split(" ");
                String year = dateParts[5];  // The year is the last part
                String month = String.format("%02d", getMonthIndex(dateParts[1]));  // Convert month name to number (Dec -> 12)

                String dateKey = (type == 1) ? year : year + "-" + month;  // Group by year or year-month

                // Store file paths in a set to ensure uniqueness
                filePathSets.computeIfAbsent(dateKey, k -> new HashSet<>()).add(filePathFromCSV);
            }
        }

        // Build the result in JSON format
        StringBuilder result = new StringBuilder("{\n");

        for (Map.Entry<String, Set<String>> entry : filePathSets.entrySet()) {
            result.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue().size()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (result.length() > 1) {
            result.setLength(result.length() - 2);
        }

        result.append("\n}");

        return result.toString();
    }


    @RequestMapping("/getDep")
    public String getDep(@RequestParam(required = false) String repo,
                         @RequestParam(required = false) String company,
                         @RequestParam(required = false) int type) throws IOException {
        // Decode the company if needed (assuming you may have a decode method)
        company = Decoder.decode(company);

        // Initialize the result map to store the merge counts for each UserID
        Map<String, Integer> userMergeCounts = new HashMap<>();

        // Define the path to the merged_one.csv file
        String rootPath = System.getProperty("user.dir");
        String filePath = localDir + repo + "/merged_one.csv";

        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip the header row
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split the line into fields
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String filePathFromCSV = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);

                // Filter by company if provided
                if (company != null && !mailCompany.equals(company)) {
                    continue;
                }

                // Accumulate the merge count for the corresponding UserID
                userMergeCounts.put(userID, userMergeCounts.getOrDefault(userID, 0) + mergeCount);
            }
        }

        // Sort the map by mergeCount in descending order
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(userMergeCounts.entrySet());
        sortedEntries.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));

        // Prepare the result map with "first" and "others"
        Map<String, Integer> result = new LinkedHashMap<>();

        if (!sortedEntries.isEmpty()) {
            // The first entry will be the one with the highest merge_count
            Map.Entry<String, Integer> firstEntry = sortedEntries.get(0);
            result.put("Contributed most", firstEntry.getValue());

            // Merge the rest into "others"
            int othersCount = 0;
            for (int i = 1; i < sortedEntries.size(); i++) {
                othersCount += sortedEntries.get(i).getValue();
            }
            if (othersCount > 0) {
                result.put("others", othersCount);
            }
        }

        // Build the result in the desired format
        StringBuilder resultJson = new StringBuilder("{\n");
        for (Map.Entry<String, Integer> entry : result.entrySet()) {
            resultJson.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (resultJson.length() > 1) {
            resultJson.setLength(resultJson.length() - 2);
        }

        resultJson.append("\n}");

        // Return the formatted result
        return resultJson.toString();
    }

    @RequestMapping("/getMF")
    public String getMF(@RequestParam(required = false) String repo,
                        @RequestParam(required = false) String company,
                        @RequestParam(required = false) int type) throws IOException {
        // Decode the company if needed (assuming you may have a decode method)
        company = Decoder.decode(company);

        // Initialize the result map to store merge counts for each file_path
        Map<String, Integer> fileMergeCounts = new HashMap<>();

        // Define the path to the merged_one.csv file
        String rootPath = System.getProperty("user.dir");
        String filePath = localDir + repo + "/merged_one.csv";

        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip the header row
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split the line into fields
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String filePathFromCSV = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);

                // Filter by company if provided
                if (company != null && !mailCompany.equals(company)) {
                    continue;
                }

                // Accumulate the merge count for the corresponding file_path
                fileMergeCounts.put(filePathFromCSV, fileMergeCounts.getOrDefault(filePathFromCSV, 0) + mergeCount);
            }
        }

        // Build the result in the desired format
        StringBuilder resultJson = new StringBuilder("{\n");

        for (Map.Entry<String, Integer> entry : fileMergeCounts.entrySet()) {
            resultJson.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (resultJson.length() > 1) {
            resultJson.setLength(resultJson.length() - 2);
        }

        resultJson.append("\n}");

        // Return the formatted result
        return resultJson.toString();
    }


    @RequestMapping("/getCF")
    public String getCF(@RequestParam(required = false) String repo,
                        @RequestParam(required = false) String company,
                        @RequestParam(required = false) String prefix,
                        @RequestParam(required = false) int type) throws IOException {
//        System.out.println(company+" "+prefix+" "+type);

        // Decode the company and prefix if needed (assuming you may have a decode method)
        company = Decoder.decode(company);
        prefix = Decoder.decode(prefix);
        // Initialize a TreeMap to store merge counts by date, ensuring the dateKeys are sorted in ascending order
        Map<String, Integer> dateMergeCounts = new TreeMap<>();

        // Define the path to the merged_one.csv file
        String rootPath = System.getProperty("user.dir");
        String filePatt = rootPath;

        // Set the appropriate file path based on the type
        if (type % 3 == 1) {
            filePatt = localDir + repo + "/merged_one.csv";
        }
        if (type % 3 == 2) {
            filePatt = localDir + repo + "/merged_two.csv";
        }
        if (type % 3 == 0) {
            filePatt = localDir + repo + "/merged_three.csv";
        }
        String filePath = filePatt;
        // Reading the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;

            // Skip the header row
            reader.readLine();

            while ((line = reader.readLine()) != null) {
                // Split the line into fields
                String[] fields = line.split(",");

                String rev = fields[0];
                String authorName = fields[1];
                String authorEmail = fields[2];
                String authorDateStr = fields[3];  // Date in the form: Mon Dec 09 06:03:39 CST 2024
                String userID = fields[4];
                String mailCompany = fields[5];
                String filePathFromCSV = fields[6];
                int addedLines = Integer.parseInt(fields[7]);
                int deletedLines = Integer.parseInt(fields[8]);
                int mergeCount = Integer.parseInt(fields[9]);

                // Filter by company and file_path (prefix)
                if (company != null && !mailCompany.equals(company)) {
                    continue;
                }
                if (prefix != null && !filePathFromCSV.startsWith(prefix)) {
                    continue;
                }

                // Extract year and month from the author_date string (Mon Dec 09 06:03:39 CST 2024)
                String[] dateParts = authorDateStr.split(" ");  // ["Mon", "Dec", "09", "06:03:39", "CST", "2024"]
                String year = dateParts[5];  // The year is the last part of the string
                String month = String.format("%02d", getMonthIndex(dateParts[1]));  // Convert month name to number (Dec -> 12)

                // Determine the grouping format based on the 'type' parameter
                String dateKey;
                if (type%2 == 0) {  // Group by year
                    dateKey = year;
                } else {  // Group by year-month
                    dateKey = year + "-" + month;
                }

                // Accumulate the merge_count for the corresponding date
                dateMergeCounts.put(dateKey, dateMergeCounts.getOrDefault(dateKey, 0) + mergeCount);
            }
        }

        // Build the result in the desired format
        StringBuilder resultJson = new StringBuilder("{\n");

        for (Map.Entry<String, Integer> entry : dateMergeCounts.entrySet()) {
            resultJson.append("    \"").append(entry.getKey()).append("\": ").append(entry.getValue()).append(",\n");
        }

        // Remove the last comma and newline if any
        if (resultJson.length() > 1) {
            resultJson.setLength(resultJson.length() - 2);
        }

        resultJson.append("\n}");

        // Return the formatted result
//        System.out.println(resultJson.toString());
        return resultJson.toString();
    }


    @RequestMapping("/getRisk")
    public String getRisk(@RequestParam(required = false) String repo) throws IOException {

        // Initialize the result map to store company -> (depend, predict)
        Map<String, Map<String, Double>> companyRiskData = new HashMap<>();

        // Define the paths to the CSV files
        String rootPath = System.getProperty("user.dir");
        String dependFilePath = localDir + repo + "/test_depend.csv";
        String predictFilePath = localDir + repo + "/test_predict.csv";

        // Read the test_depend.csv file
        try (BufferedReader reader = new BufferedReader(new FileReader(dependFilePath))) {
            String line;
//            reader.readLine(); // Skip the header row

            while ((line = reader.readLine()) != null) {
                // Split the line into company and percent (depend)
                String[] fields = line.split(",");
                String companyName = fields[0].trim();
                double depend = Double.parseDouble(fields[1].trim());

                // Store depend data in the map
                companyRiskData.putIfAbsent(companyName, new HashMap<>());
                companyRiskData.get(companyName).put("depend", depend);
            }
        }

        // Read the test_predict.csv file
        try (BufferedReader reader = new BufferedReader(new FileReader(predictFilePath))) {
            String line;
            reader.readLine(); // Skip the header row

            while ((line = reader.readLine()) != null) {
                // Split the line into company and percent (predict)
                String[] fields = line.split(",");
                String companyName = fields[0].trim();
                double predict = Double.parseDouble(fields[1].trim());

                // If the company already exists in the depend data, update the predict value
                companyRiskData.putIfAbsent(companyName, new HashMap<>());
                companyRiskData.get(companyName).put("predict", predict);
            }
        }

        // Build the result in the desired format
        StringBuilder resultJson = new StringBuilder("{\n");

        for (Map.Entry<String, Map<String, Double>> entry : companyRiskData.entrySet()) {
            String companyName = entry.getKey();
            Map<String, Double> companyData = entry.getValue();
            double depend = companyData.getOrDefault("depend", 0.0);
            double predict = companyData.getOrDefault("predict", 0.0);

            resultJson.append("    \"").append(companyName).append("\": {\n");
            resultJson.append("        \"depend\": ").append(depend).append(",\n");
            resultJson.append("        \"predict\": ").append(predict).append("\n");
            resultJson.append("    },\n");
        }

        // Remove the last comma and newline if any
        if (resultJson.length() > 1) {
            resultJson.setLength(resultJson.length() - 2);
        }

        resultJson.append("\n}");

        // Return the formatted result
        return resultJson.toString();
    }
    @RequestMapping("/getDiv")
    public String getDiv(@RequestParam(required = false) String repo,
                         @RequestParam(required = false) String company) throws IOException {

        // 需要检查的 word 列表
        List<String> wordsToCheck = Arrays.asList("fix", "style", "ci", "perf", "refactor", "feat", "docs", "test", "chore", "build");

        // 用于存储每个 word 对应的 count
        Map<String, Integer> wordCountMap = new HashMap<>();

        // 初始化所有 word 的 count 为 0
        for (String word : wordsToCheck) {
            wordCountMap.put(word, 0);
        }

        // 读取 word_count_output.csv 文件
        String rootPath = System.getProperty("user.dir");
        String csvFile = localDir + repo + "/word_count_output.csv";
//        String csvFile = "word_count_output.csv"; // 假设文件路径
        try (BufferedReader reader = new BufferedReader(new FileReader(csvFile))) {
            String line;
            reader.readLine(); // 跳过表头

            // 逐行读取文件并筛选出 mailcompany 为指定 company 的行
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 3) {
                    String mailcompany = fields[0].trim();
                    String word = fields[1].trim();
                    int count = Integer.parseInt(fields[2].trim());

                    // 如果 mailcompany 匹配，检查 word 是否在我们关心的列表中
                    if (mailcompany.equals(company) && wordsToCheck.contains(word)) {
                        wordCountMap.put(word, count);  // 更新对应 word 的 count
                    }
                }
            }

            // 将结果转换为字符串，方便返回
            StringBuilder result = new StringBuilder();
            for (String word : wordsToCheck) {
                result.append(wordCountMap.get(word)).append("\n"); // 只输出 count
            }

            return result.toString(); // 返回统计结果

        } catch (IOException e) {
            e.printStackTrace();
            return "Error reading the file!";
        }
    }

    @RequestMapping("/getDominate")
    public String getDominate(@RequestParam(required = false) String repo) throws IOException {
        Map<String, List<ContributionInfo>> moduleContributions = new HashMap<>();
        // 读取 company_dominated_module.csv 文件
        String rootPath = System.getProperty("user.dir");
        String csvFile = localDir + repo + "/company_dominated_modules.csv";
        try (BufferedReader reader = new BufferedReader(new FileReader(csvFile))) {
            String line;
            reader.readLine(); // 跳过表头

            // 逐行读取文件
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 5) {
                    String module = fields[0].trim();
                    String company = fields[1].trim();
                    String totalContributions = fields[2].trim();
                    String companyContributions = fields[3].trim();
                    String contributionPercentageStr = fields[4].trim();

                    // 处理 ContributionPercentage 字段（转化为数值）
                    double contributionPercentage = Double.parseDouble(contributionPercentageStr.replace("%", "").trim());


                    // 将数据存入 Map，按 Module 分组
                    moduleContributions
                            .computeIfAbsent(module, k -> new ArrayList<>())
                            .add(new ContributionInfo(company, contributionPercentage));
//                    System.out.println(companyContributions);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
            return "Error reading the file!";
        }
        // 存储结果
        StringBuilder result = new StringBuilder();

        // 遍历每个 Module
        for (Map.Entry<String, List<ContributionInfo>> entry : moduleContributions.entrySet()) {
            String module = entry.getKey();
            List<ContributionInfo> contributions = entry.getValue();

            // 按 ContributionPercentage 排序，降序
            contributions.sort((a, b) -> Double.compare(b.getContributionPercentage(), a.getContributionPercentage()));

            // 提取前三名数据
            result.append("Module: ").append(module).append("\n");
            int count = 0;
            for (ContributionInfo info : contributions) {
                if (count >= 3) break;
                result.append("").append(info.getCompany())
                        .append("-").append(info.getContributionPercentage())
                        .append("%\n");
                count++;
            }
            result.append("\n");
        }

        return result.toString();
    }

    // 创建一个类来存储公司和贡献百分比的信息
    class ContributionInfo {
        private String company;
        private double contributionPercentage;

        public ContributionInfo(String company, double contributionPercentage) {
            this.company = company;
            this.contributionPercentage = contributionPercentage;
        }

        public String getCompany() {
            return company;
        }

        public double getContributionPercentage() {
            return contributionPercentage;
        }
    }


}
