#!/bin/bash

# 检查参数数量
if [ "$#" -ne 1 ]; then
    echo "用法: $0 <repo-url>"
    exit 1
fi

REPO=$1

# 使用 git ls-remote 检查仓库是否存在
if git ls-remote "$REPO" &> /dev/null; then
    echo "true"
else
    echo "false"
fi
